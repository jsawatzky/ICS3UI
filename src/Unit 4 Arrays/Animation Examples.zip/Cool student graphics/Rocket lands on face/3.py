#Imports
from tkinter import *
from time import *
from random import *

#Canvas
screenHeight = 800
screenWidth = 800
root = Tk()
screen = Canvas( root, width=screenWidth, height=screenHeight, background = "blue" )
screen.pack()

#Fuctions

#animate rocket
def animateRocket(height):
    rocket [0] = screen.create_polygon( 350, 750 - height, 450, 750- height, 500, 800- height, 300, 800- height, fill="red" )
    rocket [1] = screen.create_polygon( 350, 600 - height, 450, 600 - height, 450, 750- height, 350, 750- height, fill="grey" )
    rocket [2] = screen.create_polygon( 400, 450 - height, 450, 600- height, 350, 600- height, fill="red" )
    rocket [3] = screen.create_oval( 375, 700 - height, 425, 650- height, fill="light blue" )
    rocket [4] = screen.create_image( 585, 930 - height, image=astronautImage )

#animate smoke
def animateSmoke(height, colorSmoke, smoke, sizeSmoke, xSmoke, ySmoke):
    for smokeNum in range (10):
        sizeSmoke [smokeNum] = randint(10,60)
        xSmoke [smokeNum] = randint(350, 400)
        ySmoke [smokeNum] = 800 - height

    for smokeNum in range(len (smoke)):
        smoke[smokeNum] = screen.create_oval( xSmoke[smokeNum], ySmoke[smokeNum], xSmoke[smokeNum] +sizeSmoke[smokeNum], ySmoke[smokeNum] +sizeSmoke[smokeNum], fill= colorSmoke[smokeNum % len(colorSmoke)])

#cleans screen of unused images
def clearScreen (smoke, rocket, star):
    for clear in range (len(smoke)):      
        screen.delete(smoke[clear])
    
    for clear in range (len(rocket)):   
        screen.delete(rocket[clear])
        
    for starNum in range (len(star)):
        screen.delete (star [starNum])


#Defining variables
rocket = [0,0,0,0,0]
planet = 0
countdown = 3
height = 50
colorSmoke = ["red", "orange", "yellow", "grey"]
smoke = [0,0,0,0,0,0,0,0,0,0,0]
sizeSmoke = [0,0,0,0,0,0,0,0,0,0,0]
xSmoke = [0,0,0,0,0,0,0,0,0,0,0]
ySmoke = [0,0,0,0,0,0,0,0,0,0,0]
space = 0
spaceHeight = 0
sizeStar = []
xStar = []
yStar = []
star = []
rocketSpeed = 1
numFrames = 1000
astronautImage = PhotoImage(file = "Astronaut.gif")
planetImage = PhotoImage(file = "Planet.gif")

#Creating grass
grass = screen.create_rectangle( 0, 750, 800, 800, fill= "green" )

#creating rocket
animateRocket(height)

#Countdown
for time in range (countdown, 0, -1):
    text = screen.create_text( 50, 50, text = time , font = ("TimesNewRoman", 50), fill = "red")
    screen.update()
    sleep(1)
    screen.delete(text)


#Animation of rocket flying   
for frames in range (numFrames):

    #clearing screen      
    clearScreen (smoke, rocket, star)
      
    #adjusting rocket
    if height < 350:
        height += rocketSpeed

    else:
        #Space
        if spaceHeight < 800:
            spaceHeight += rocketSpeed
            screen.delete(space)
            space = screen.create_rectangle( 0, -1000 + spaceHeight, 800, 0 + spaceHeight, fill="dark blue" )


        #creating and deleting star variables
        for starNum in range (int (rocketSpeed / 10) + 1):
            newSizeStar = randint(2,5)
            newXstar  = randint(0, 800)
            newYstar  = randint(0, rocketSpeed)

            sizeStar.append (newSizeStar)
            xStar.append (newXstar)
            yStar.append (newYstar)
            star.append (0)

            #deleting old stars
            if spaceHeight >= 800:
                screen.delete (star [0])
                sizeStar.pop (0)
                xStar.pop (0)
                yStar.pop (0)
                star.pop (0)

    #animating stars
    for starNum in range (len(star)):
        star [starNum] = screen.create_oval( xStar [starNum], yStar [starNum], xStar [starNum] + sizeStar [starNum], yStar [starNum] + sizeStar [starNum], fill="white" )
        yStar [starNum] += rocketSpeed

    #animating rocket
    animateRocket(height)

    #animating smoke
    animateSmoke(height, colorSmoke, smoke, sizeSmoke, xSmoke, ySmoke)

    #animating grass
    if frames < 25:
        screen.delete (grass)
        grass = screen.create_rectangle( 0, 750 + frames*3, 800, 800 + frames*3, fill= "green" )
        
    #crashland on planet
    elif numFrames - frames < 20:
        screen.delete (planet)
        planet = screen.create_image( 420, -100 + (frames % 20 * 10), image = planetImage )
       
    #increases speed of flying as the program runs
    if 0 == frames % 100:
        rocketSpeed += 3

    #updates after all the animations    
    screen.update()

#clearing smoke after animation ends
for clear in range (len(smoke)):      
    screen.delete(smoke[clear])
