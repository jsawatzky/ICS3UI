'''
Created on Mar 31, 2014

@author: JONATHAN SCHUMACHER
'''

#===============================================================================
# Imports
#===============================================================================
from tkinter import *
from time import *
import random

#===============================================================================
# Window Creation
#===============================================================================
window = Tk()
panel = Canvas(window, width = 800, height = 800, background = "#000000")
panel.pack()

#===============================================================================
# Variables
#===============================================================================
crowdImage1 = PhotoImage(file = "crowd1.gif")
crowdImage2 = PhotoImage(file = "crowd2.gif")
fire = [PhotoImage(file = "fire1.gif"), PhotoImage(file = "fire2.gif"), PhotoImage(file = "fire3.gif"), PhotoImage(file = "fire2.gif")]
band = [PhotoImage(file = "MECB1.gif"), PhotoImage(file = "MECB2.gif"), PhotoImage(file = "MECB3.gif"), PhotoImage(file = "MECB4.gif")]
# These lines import all the images being used and arranges how they will be called in their respective loops

crowdYPosition = [680, 690, 670, 700]

laserColour = ["#ff1111", "#11ff11", "#1111ff", "#ffb900", "#11ff11"]

squareXUL = 400 
squareYUL = 400
squareXLR = 400
squareYLR = 400

#===============================================================================
# Logic
#===============================================================================
for i in range(0, 130):
    xPosStars = random.randint(1, 800)
    yPosStars = random.randint(1, 800)
    starSize = random.randint(0, 10)
    panel.create_oval(xPosStars, yPosStars, xPosStars+starSize, yPosStars+starSize, fill = "#ffffff")
    # Creates random stars in the background
    
panel.update()

panel.create_rectangle(0, 280, 810, 810, fill = "#4f5c3c")
panel.create_rectangle(100, 400, 700, 700, fill = "#d7691c")
# Creates the stage

for j in range(0, 40):
    for i in range(0, 4):
        imageFire1 = panel.create_image(175, 367, image = fire[i])
        imageFire2 = panel.create_image(625, 367, image = fire[i])
        # Creates the fire animation
        
        panel.create_polygon(150, 401, 200, 401, 190, 390, 160, 390, fill = "#991111")
        panel.create_polygon(600, 401, 650, 401, 640, 390, 610, 390, fill = "#991111")
        # Creates the polygons from where the fire comes
        
        crowd3 = panel.create_image(400, crowdYPosition[i] - 160, image = crowdImage1)
        crowd2 = panel.create_image(400 + i*5, crowdYPosition[i] - 80, image = crowdImage2)
        crowd1 = panel.create_image(400, crowdYPosition[i], image = crowdImage1)
        # Creates the crowd dancing animation
        
        imageBand = panel.create_image(400, 290, image = band[i])
        # Creates the band
        
        laser1 = panel.create_line(40, 0, random.randint(-50, 850), 900, fill = laserColour[i])
        laser2 = panel.create_line(40, 0, random.randint(-50, 850), 900, fill = laserColour[i+1])
        laser3 = panel.create_line(760, 0, random.randint(-50, 850), 900, fill = laserColour[i])
        laser4 = panel.create_line(760, 0, random.randint(-50, 850), 900, fill = laserColour[i+1])
        # Creates the lasers and generates random x-coordinates
        
        panel.update()
        sleep(0.06)
        panel.delete(imageFire1, imageFire2, crowd1, crowd2, crowd3, imageBand, laser1, laser2, laser3, laser4)
        # Places everything on screen then removes it for the next frame

for i in range(0, 1000):
    square = panel.create_rectangle(squareXUL, squareYUL, squareXLR, squareYLR, fill = "#000000")
    panel.update()
    squareXUL = squareXUL - 5 
    squareYUL = squareYUL - 5
    squareXLR = squareXLR + 5
    squareYLR = squareYLR + 5
    panel.delete(square)
    # Generates the growing square at the end of the animation

#============================================================================
# Window Management
#============================================================================
window.destroy() # .destroy() deletes the everything as well as the window for program close
window.mainloop() # Prevents the tk window from closing at launch in IDE's other than IDLE
