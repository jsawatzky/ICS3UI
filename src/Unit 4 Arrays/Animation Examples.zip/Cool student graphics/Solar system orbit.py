#Planet Simulation by Ian Fox

#Initial stuff:
from tkinter import *
from time import *
from math import *
from random import *


#######################################################################################################################################################################
##### ENTER VALUES BELOW ##############################################################################################################################################
#######################################################################################################################################################################

#Initial values:
#Each entry is a planet, and has values as follows:
#[x position, y position, x velocity, y velocity, mass, radius, colour]
#For coordinates, a regular cartesian coordinate system is used with (0,0) as the centre and with values increasing to the right and up
planets=[[0,0,0,0,500,20,"Yellow"],[-200,0,0,12,10,5,"Blue"],[-233,0,0,6,5,2,"White"],[300,0,0,-10,10,4,"Red"]]


#Stars: Number of desired background stars. Set to 0 for no stars.
stars=500


#Focus:

#Auto focus: Set Autofocus to 1 and Focus to the index of the planet you want the focus to be. (Keep in mind the first planet is 0)
Autofocus=1
Focus=0

#If not using autofocus, it is possible to manually edit the center of the screen to a fixed position.
xshift=100
yshift=0


#Constants
G=6.67*10**1 #Universal Gravitation Constant


#Window height and width
screenwidth=800
screenheight=500

#######################################################################################################################################################################
##### Nothing to change past this point, just code. ###################################################################################################################
#######################################################################################################################################################################









#Set up screen:
root=Tk()
root.wm_title("Planet Simulation")
screen=Canvas(root,width=screenwidth,height=screenheight,background="black")
screen.pack()

#Housekeeping:

#Add a placeholder value to each planet:
for i in range(0,len(planets)):
    planets[i].append("Planet")

#Adjust x and y to account for python's coordinate system
for i in range(0,len(planets)):
    planets[i][0]+=screenwidth/2
    planets[i][1]=-planets[i][1]
    planets[i][1]+=screenheight/2
    planets[i][3]=-planets[i][3]
    
    
#Invert xshift and y velocity and y position so it makes sense:
xshift=-xshift

#Stars
if stars!=0:
    for i in range(0,stars):
        x=randint(0,screenwidth)
        y=randint(0,screenheight)
        screen.create_line(x,y,x+1,y,fill="White")

#Main Loop
while True:

    #Determine shifts
    if Autofocus==1:
        xshift=(screenwidth/2)-planets[Focus][0]
        yshift=(screenheight/2)-planets[Focus][1]
    
    #Draw planet, update velocities
    for i in range(0,len(planets)):
        
        #Retrieve variables (for ease of interpreting code)
        x=planets[i][0]
        y=planets[i][1]
        xvel=planets[i][2]
        yvel=planets[i][3]
        mass=planets[i][4]
        radius=planets[i][5]
        colour=planets[i][6]
        
        #Redraw planet
        screen.delete(planets[i][7])
        planets[i][7]=screen.create_oval(x-radius+xshift,y-radius+yshift,x+radius+xshift,y+radius+yshift,fill=colour)

        #Adjust velocity
        fx=0
        fy=0
        for j in range(0,len(planets)):
            if not j==i: #Don't accelerate relative to itself
                x2=planets[j][0]
                y2=planets[j][1]
                mass2=planets[j][4]
                radius2=planets[j][5]
                r=sqrt((x-x2)**2+(y-y2)**2)
                if r!=0:
                    fnet=G*mass*mass2/(r**2)
                
                if not x==x2: #Don't accelerate in the x if x values are identical
                    fx+=fnet*(x2-x)/r

                if not y==y2: #Don't accelerate in the y if y values are identical
                    fy+=fnet*(y2-y)/r
    
        xvel+=fx/mass
        yvel+=fy/mass

        #Update variables
        planets[i][0]=x
        planets[i][1]=y
        planets[i][2]=xvel
        planets[i][3]=yvel 

    #Update positions
    for i in range(0,len(planets)):
        planets[i][0]+=planets[i][2]
        planets[i][1]+=planets[i][3]

    #Detect collisions
    for i in range(0,len(planets)):

        #Import variables
        x=planets[i][0]
        y=planets[i][1]
        xvel=planets[i][2]
        yvel=planets[i][3]
        mass=planets[i][4]
        radius=planets[i][5]
        
        for j in range(0,len(planets)):
            if not i==j:
                
                #Import variables
                x2=planets[j][0]
                y2=planets[j][1]
                xvel2=planets[j][2]
                yvel2=planets[j][3]
                mass2=planets[j][4]
                radius2=planets[j][5]
                r=sqrt((x-x2)**2+(y-y2)**2)

                #If planets are touching
                if r<radius+radius2: 

                    #Define variables of remaining planet
                    newmass=mass+mass2
                    newxvel=(mass*xvel+mass2*xvel2)/newmass
                    newyvel=(mass*yvel+mass2*yvel2)/newmass
                    newx=(x*mass+x2*mass2)/(mass+mass2)
                    newy=(y*mass+y2*mass2)/(mass+mass2)

                    #Delete the one with lower mass
                    if mass>mass2:
                        screen.delete(planets[j][7])
                        planets[j]=[0,0,0,0,0,0,0,0]
                        newplanet=i
                        if Focus==i:
                            Focus=j
                    else:
                        screen.delete(planets[i][7])
                        planets[i]=[0,0,0,0,0,0,0,0]
                        newplanet=j
                        if Focus==j:
                            Focus=i

                        
                    #Update Variables    
                    planets[newplanet][0]=newx
                    planets[newplanet][1]=newy
                    planets[newplanet][2]=newxvel
                    planets[newplanet][3]=newyvel
                    planets[newplanet][4]=newmass
                    planets[newplanet][5]=sqrt((pi*radius**2+pi*radius2**2)/pi)

    #Housekeeping: Delete nonexistant planets.
    i=0
    endplace=len(planets)
    while i<endplace:
        if planets[i]==[0,0,0,0,0,0,0,0]:
            planets.pop(i)
            i-=1
            endplace-=1
            if Focus>i:
                Focus-=1
        else:
            i+=1    

    screen.update()
    sleep(0.05)

        
        
