#LOADS PYTHON'S GRAPHICS PACKAGE
from tkinter import *
from random import *
from time import *

#SETS UP THE DRAWING SCREEN
myInterface = Tk()

s = Canvas(myInterface, width=600, height=600, background="white")
s.pack()

    
#CODE YOUR DRAWING HERE

menu1 = 0

#Grid
def grid():
    spacing = 20
    for x in range(0, 600, spacing): 
        s.create_line(x, 10, x, 800, fill="blue")
        s.create_text(x, 0, text=str(x), font="Times 8", anchor = N)

    for y in range(0, 600, spacing):
        s.create_line(20, y, 800, y, fill="blue")
        s.create_text(0, y, text=str(y), font="Times 8", anchor = W)

    s.update()

#Ground
def ground():
    s.create_rectangle(0,400,600,600, fill="white", outline="white")

#Grass
def grass():
    for i in range(0,1000):
        xr = choice(range(1,600))
        yr = choice(range(401,600))
        r = choice([1,2,3,4,5])
        s.create_line(xr,yr,xr+r,yr+r, fill="green")


#Snowman
def snowman():
    s.create_polygon(470,280,480, 275, 430, 240, 420, 230, 470, 280, fill="Saddle Brown", outline="Saddle Brown")
    s.create_polygon(530,280,520, 275, 570, 240, 580, 230, 530, 280, fill="Saddle Brown", outline="Saddle Brown")
    s.create_oval(450,315,550,415, fill="White Smoke", outline="White Smoke")
    s.create_oval(462.5,330,537.5,255, fill="White Smoke", outline="White Smoke")
    s.create_oval(475,265,525,215, fill="White Smoke", outline="White Smoke")
    s.create_oval(505,335,495,345, fill="black", outline="black")
    s.create_oval(505,305,495,315, fill="black", outline="black")
    s.create_oval(505,275,495,285, fill="black", outline="black")
    s.create_oval(505,235,495,245, fill="orange", outline="black")
    s.create_line(490, 245, 500, 250, 510, 245, smooth="true")
    s.create_oval(485, 225, 495, 235, fill="black")
    s.create_oval(505, 225, 515, 235, fill = "black")
    s.create_rectangle(460,215,540,220, fill="black")
    s.create_rectangle(480,200,520,215, fill="red", outline="red")
    s.create_rectangle(480,180,520,200, fill="black")

#Sky
def sun():
    s.create_oval(20,20,80,80, outline="yellow", fill="yellow")

def moon():
    s.create_oval(20,20,80,80, outline='#c0c0c0', fill='#c0c0c0')
    s.create_oval(30,30,50,50, outline='#808080', fill='#808080')
    s.create_oval(70,70,60,60, outline='#808080', fill='#808080')

def stars():
    for i in range(0,500):
        color = choice(['#ffff80',"white",'#ff9396'])
        x1 = randint(1,599)
        y1 = randint(1,599)
        size = randint(1,3)
        s.create_oval(x1,y1,x1+size,y1+size, outline=color, fill=color)
    

#Cloud
def cloud():
    for i in range(0,10):
        xr = randint(200,360)
        yr = randint(40,120)
        yrc = randint(30,40)
        xrc = randint(60,100)
        s.create_oval(xr,yr,xr+xrc,yr+yrc, fill="white", outline="white")

#Snowman
def snowman2():
    s.create_polygon(470,280,480, 275, 430, 240, 420, 230, 470, 280, fill="Saddle Brown", outline="Saddle Brown")
    s.create_polygon(530,280,520, 275, 570, 240, 580, 230, 530, 280, fill="Saddle Brown", outline="Saddle Brown")
    s.create_oval(450,315,550,415, fill="White Smoke", outline="White Smoke")
    s.create_oval(462.5,330,537.5,255, fill="White Smoke", outline="White Smoke")
    s.create_oval(475,265,525,215, fill="White Smoke", outline="White Smoke")
    s.create_oval(505,335,495,345, fill="black", outline="black")
    s.create_oval(505,305,495,315, fill="black", outline="black")
    s.create_oval(505,275,495,285, fill="black", outline="black")
    s.create_oval(505,235,495,245, fill="orange", outline="black")
    s.create_line(490, 245, 500, 250, 510, 245, smooth="true")
    s.create_oval(485, 225, 495, 235, fill="black")
    s.create_oval(505, 225, 515, 235, fill = "black")
    

#Person
def person():
    s.create_oval(60,280,100,360, fill="Navy Blue", outline="Navy Blue")
    s.create_oval(55,235,105,285, fill="Light Salmon", outline="Light Salmon")        
    s.create_polygon(50,245,80,250,110,245,80,220,50,245, fill="red", outline="red", smooth="true")
    s.create_oval(65,250,75,260, fill="white")
    s.create_oval(67.5,252.5,72.5,257.5, fill="blue", outline="blue")
    s.create_oval(85,250,95,260, fill="white")
    s.create_oval(87.5,252.5,92.5,257.5, fill="blue", outline="blue")
    s.create_polygon(80,260,75,265,85,265,80,260, fill="Light Salmon", outline="black")
    s.create_polygon(70,290,40,320,45,325,65,300,70,310, fill="Navy Blue")
    s.create_polygon(90,290,120,320,115,325,95,300,90,310, fill="Navy Blue")
    s.create_polygon(90,270,80,280,73,270,80,275,90,270, fill="red", outline="black", smooth="true")
    
#Fort
def fort():
    for i in range(0,1000):
        x = randint(0,180)
        y = randint(340,440)
        c = randint(10,20)
        s.create_oval(x,y,x+c,y+c, fill="white" , outline="grey")

def fort2():
    for i in range(0,1000):
        x = randint(180,220)
        y = randint(330,420)
        c = randint(10,20)
        s.create_oval(x,y,x+c,y+c, fill="white" , outline="grey")

def fort3():
    for i in range(0,1000):
        x = randint(220,260)
        y = randint(320,400)
        c = randint(10,20)
        s.create_oval(x,y,x+c,y+c, fill="white" , outline="grey")

#Snowball
def snowball():
    hx = 500
    hy = 200
    hat1 = s.create_rectangle(hx-40,hy+15,hx+40,hy+20, fill="black")
    hat2 = s.create_rectangle(hx-20,hy,hx+20,hy+15, fill="red", outline="red")
    hat3 = s.create_rectangle(hx-20,hy-20,hx+20,hy, fill="black")
    sx = 100
    
    while sx < 660:
        sx += 5
        sy1 = (sx-350)*(sx-350)
        sy4 = 1/2520
        sy3 = sy4*sy1
        sy = sy3+175
        sx2 = sx + 20
        sy2 = sy + 20
        
        if sx < 460:
            snowball = s.create_oval(sx,sy,sx2,sy2, fill="white", outline="grey")
            s.update()
            sleep(0.02)
            s.delete(snowball)

        elif sx >= 460:
            if sx == 460:
                s.delete(hat1,hat2,hat3)
            hx += 5
            hy += 0.5
            hat1 = s.create_rectangle(hx-40,hy+15,hx+40,hy+20, fill="black")
            hat2 = s.create_rectangle(hx-20,hy,hx+20,hy+15, fill="red", outline="red")
            hat3 = s.create_rectangle(hx-20,hy-20,hx+20,hy, fill="black")
            snowball = s.create_oval(sx,sy,sx2,sy2, fill="white", outline="grey")
            s.update()
            sleep(0.02)
            s.delete(snowball,hat1,hat2,hat3)

#Meteor Shower
def meteors():
    global menu1
    while menu1 != 1:
        mx1 = randint(80,420)
        my1 = randint(20,80)
        speed = 5
        for i in range(0,20):
            mx2 = mx1 - speed
            my2 = my1 + speed
            meteor = s.create_line(mx1,my1,mx2,my2, fill="white", width=2)
            s.update()
            sleep(0.01)
            s.delete(meteor)
            mx1 -= 5
            my1 += 5
            speed += 5
        s.update()
        sleep(1)

#Falling snow
def snow():
    global menu1
    numFlakes = 500
    snowFlake = []
    snowX = []
    snowY = []
    snowYstart = []
    snowSize = []
    snowSpeed = []
    times = []
    for i in range(0,numFlakes):
        snowFlake.append(0)
        snowY.append(0)
        snowYstart.append(randint(-600,0))
        snowX.append(randint(0,600))
        snowSize.append(randint(1,6))
        snowSpeed.append(randint(1,4))
        times.append(0)
    while menu1 != 1:
        for n in range(0,numFlakes):
            snowY[n] = snowSpeed[n] * times[n] + snowYstart[n]
            snowFlake[n] = s.create_oval(snowX[n],snowY[n],snowX[n] + snowSize[n],snowY[n] + snowSize[n], fill="white", outline="white")
            times[n] += 1

            if snowY[n] >= 600:
                snowYstart[n] = 0
                times[n] = 0

        s.update()
        sleep(0.01)

        for i in range(0,numFlakes):
            s.delete(snowFlake[i])

#Kill loop
def loopStop():
    global menu1
    menu1 = 1

#Menu button
def returnToMenu():
    b3 = Button(s, text = "Return to menu", command = menu, anchor = W)
    b3.configure(width = 13, activebackground = "green")
    b3w = s.create_window(20, 560, anchor=NW, window=b3)

#Part 1
def first():
    s.delete("all")
    s.configure(background="Navy")
    
    stars()
    s.create_text(20,500, text = "Winter Wonderland!", font = "Ravie 20", anchor = W)
    ground()
    grass()
    snowman()
    moon()
    cloud()
    fort()
    fort2()
    fort3()

    returnToMenu()

#Part 2
def second():
    s.delete("all")
    s.configure(background="Deep Sky Blue")

    ground()
    grass()
    snowman2()
    hx = 500
    hy = 200
    hat1 = s.create_rectangle(hx-40,hy+15,hx+40,hy+20, fill="black")
    hat2 = s.create_rectangle(hx-20,hy,hx+20,hy+15, fill="red", outline="red")
    hat3 = s.create_rectangle(hx-20,hy-20,hx+20,hy, fill="black")
    sun()
    cloud()
    person()
    fort3()
    fort2()
    fort()
    text = s.create_text(100,200, text = "What a nice day!", font = "Ravie 10", anchor = W)
    
    returnToMenu()

    #Prep scene for snowball
    def snowballprep():
        s.delete(hat1,hat2,hat3,text)
        s.create_text(100,200, text = "Oops!", font = "Ravie 10", anchor = W)
        snowball()

    b4 = Button(s, text = "Click to throw snowball!", command = snowballprep, anchor = W)
    b4.configure(activebackground = "green")
    b4z = s.create_window(60, 360, anchor=NW, window=b4)

#Third part
def third():
    global menu1
    
    s.delete("all")
    s.configure(background="Navy")
    
    stars()
    ground()
    grass()
    snowman()
    moon()
    fort()
    fort2()
    fort3()

    b7 = Button(s, text = "Return to menu", command = loopStop, anchor = W)
    b7.configure(width = 13, activebackground = "green")
    b7w = s.create_window(20, 560, anchor=NW, window=b7)

    menu1 = 0
    meteors()

    s.delete("all")
        
    menu()

#Part 4
def fourth():
    global menu1

    s.delete("all")
    s.configure(background="Navy")

    stars()
    ground()
    grass()
    snowman()
    moon()
    fort()
    fort2()
    fort3()

    b7 = Button(s, text = "Return to menu", command = loopStop, anchor = W)
    b7.configure(width = 13, activebackground = "green")
    b7w = s.create_window(20, 560, anchor=NW, window=b7)

    menu1 = 0
    snow()

    s.delete("all")

    menu()

#Menu
def menu():
    s.configure(background="white")
    s.delete("all")
    text = s.create_text(300,200, text="Please choose an Option:", font="Ravie 20")
    b1 = Button(s, text = "First Part", command = first, anchor = W)
    b1.configure(width = 10, activebackground = "green")
    b1w = s.create_window(200, 250, anchor=NW, window=b1)

    b2 = Button(s, text = "Second Part", command = second, anchor = W)
    b2.configure(width = 10, activebackground = "green")
    b2w = s.create_window(360, 250, anchor=NW, window=b2)

    b5 = Button(s, text = "Third Part", command = third, anchor = W)
    b5.configure(width = 10, activebackground = "green")
    b5w = s.create_window(200, 350, anchor=NW, window=b5)

    b6 = Button(s, text = "Fourth Part", command = fourth, anchor = W)
    b6.configure(width = 10, activebackground = "green")
    b6w = s.create_window(360, 350, anchor=NW, window=b6)

menu()
