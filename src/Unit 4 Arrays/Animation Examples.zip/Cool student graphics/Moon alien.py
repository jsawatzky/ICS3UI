from tkinter import *
from random import *
from time import *
from math import *
import time
myInterface = Tk()
screen = Canvas(myInterface, width=800, height=800, background="black")
screen.pack()

#Background
screen.create_rectangle(0,500,800,800, fill="light grey")

for craters in range(0,80):
    x = randint(0,800)
    y = randint(500,800)
    size = randint(10,50)
    screen.create_oval(x,y,x+size,y+size, fill="dim gray", outline ="dim gray")

for stars in range(0,1000):
    ccolor = choice(["floral white", "peach puff","alice blue","papaya whip", "ghost white", "lemon chiffon", "white"])
    x = randint(0,800)
    y = randint(0,480)
    size = randint(1,10)
    screen.create_oval(x,y,x+size,y+size, fill=ccolor)

screen.create_oval(200,50,400,250, fill="blue")
screen.create_polygon(205,125,225,125,275,200,300,150,260,65,250,62, fill="dark green", smooth="true")
screen.create_polygon(315,150,325,125,350,80,350,87.5,387.5,100,390,125,390,175,375,200,350,230,360,170,fill="dark green", smooth="true")

for frameCount in range(0,100):
    
    #STARSHIP PARABOLA
    xship = 600 - frameCount*10
    yship = 0.05*frameCount**2-frameCount+10
    size = 100
    flagx = 100
    flagy = 400
    flagsizex = 175
    flagsizey = 100

    #FLAG
    flag = screen.create_rectangle(flagx,flagy,flagx+flagsizex,flagy+flagsizey, fill ="white")
    strips0 = screen.create_line(flagx,flagy,flagx+flagsizex,flagy,fill="red",width="7")
    strips1 = screen.create_line(flagx,flagy+14,flagx+flagsizex,flagy+14,fill="red",width="7")
    strips2 = screen.create_line(flagx,flagy+28,flagx+flagsizex,flagy+28,fill="red",width="7")
    strips3 = screen.create_line(flagx,flagy+42,flagx+flagsizex,flagy+42,fill="red",width="7")
    strips4 = screen.create_line(flagx,flagy+56,flagx+flagsizex,flagy+56,fill="red",width="7")
    strips5 = screen.create_line(flagx,flagy+70,flagx+flagsizex,flagy+70,fill="red",width="7")
    strips6 = screen.create_line(flagx,flagy+84,flagx+flagsizex,flagy+84,fill="red",width="7")
    strips7 = screen.create_line(flagx,flagy+98,flagx+flagsizex,flagy+98,fill="red",width="7")
    bluebox = screen.create_rectangle(flagx,flagy-5,flagx+72,flagy+45,fill="blue")

    #STARS
    starx = 103
    stary = 400
    starx1 = starx + 15
    starx2 = starx + 30
    starx3 = starx + 45
    starx4 = starx + 5
    starx5 = starx + 20
    starx6 = starx + 35
    starx7 = starx + 50
    stary1 = stary + 11
    stary2 = stary + 22
    stary3 = stary + 33
    #FIRST ROW
    star1 = screen.create_polygon(starx,stary,starx+3,stary,starx+6,stary-3,starx+9,stary,starx+12,stary,starx+9,stary+3,starx+12,stary+6,starx+6,stary+4,starx,stary+6,starx+3,stary+3,starx,stary,fill="white")
    star2 = screen.create_polygon(starx1,stary,starx1+3,stary,starx1+6,stary-3,starx1+9,stary,starx1+12,stary,starx1+9,stary+3,starx1+12,stary+6,starx1+6,stary+4,starx1,stary+6,starx1+3,stary+3,starx1,stary,fill="white")
    star3 = screen.create_polygon(starx2,stary,starx2+3,stary,starx2+6,stary-3,starx2+9,stary,starx2+12,stary,starx2+9,stary+3,starx2+12,stary+6,starx2+6,stary+4,starx2,stary+6,starx2+3,stary+3,starx2,stary,fill="white")
    star4 = screen.create_polygon(starx3,stary,starx3+3,stary,starx3+6,stary-3,starx3+9,stary,starx3+12,stary,starx3+9,stary+3,starx3+12,stary+6,starx3+6,stary+4,starx3,stary+6,starx3+3,stary+3,starx3,stary,fill="white")
    #SECOND ROW
    star5 = screen.create_polygon(starx4,stary1,starx4+3,stary1,starx4+6,stary1-3,starx4+9,stary1,starx4+12,stary1,starx4+9,stary1+3,starx4+12,stary1+6,starx4+6,stary1+4,starx4,stary1+6,starx4+3,stary1+3,starx4,stary1,fill="white")
    star6 = screen.create_polygon(starx5,stary1,starx5+3,stary1,starx5+6,stary1-3,starx5+9,stary1,starx5+12,stary1,starx5+9,stary1+3,starx5+12,stary1+6,starx5+6,stary1+4,starx5,stary1+6,starx5+3,stary1+3,starx5,stary1,fill="white")
    star7 = screen.create_polygon(starx6,stary1,starx6+3,stary1,starx6+6,stary1-3,starx6+9,stary1,starx6+12,stary1,starx6+9,stary1+3,starx6+12,stary1+6,starx6+6,stary1+4,starx6,stary1+6,starx6+3,stary1+3,starx6,stary1,fill="white")
    star8 = screen.create_polygon(starx7,stary1,starx7+3,stary1,starx7+6,stary1-3,starx7+9,stary1,starx7+12,stary1,starx7+9,stary1+3,starx7+12,stary1+6,starx7+6,stary1+4,starx7,stary1+6,starx7+3,stary1+3,starx7,stary1,fill="white")
    #THIRD ROW
    star9 = screen.create_polygon(starx,stary2,starx+3,stary2,starx+6,stary2-3,starx+9,stary2,starx+12,stary2,starx+9,stary2+3,starx+12,stary2+6,starx+6,stary2+4,starx,stary2+6,starx+3,stary2+3,starx,stary2,fill="white")
    star10 = screen.create_polygon(starx1,stary2,starx1+3,stary2,starx1+6,stary2-3,starx1+9,stary2,starx1+12,stary2,starx1+9,stary2+3,starx1+12,stary2+6,starx1+6,stary2+4,starx1,stary2+6,starx1+3,stary2+3,starx1,stary2,fill="white")
    star11 = screen.create_polygon(starx2,stary2,starx2+3,stary2,starx2+6,stary2-3,starx2+9,stary2,starx2+12,stary2,starx2+9,stary2+3,starx2+12,stary2+6,starx2+6,stary2+4,starx2,stary2+6,starx2+3,stary2+3,starx2,stary2,fill="white")
    star12 = screen.create_polygon(starx3,stary2,starx3+3,stary2,starx3+6,stary2-3,starx3+9,stary2,starx3+12,stary2,starx3+9,stary2+3,starx3+12,stary2+6,starx3+6,stary2+4,starx3,stary2+6,starx3+3,stary2+3,starx3,stary2,fill="white")
    #FOURTH ROW
    star13 = screen.create_polygon(starx4,stary3,starx4+3,stary3,starx4+6,stary3-3,starx4+9,stary3,starx4+12,stary3,starx4+9,stary3+3,starx4+12,stary3+6,starx4+6,stary3+4,starx4,stary3+6,starx4+3,stary3+3,starx4,stary3,fill="white")
    star14 = screen.create_polygon(starx5,stary3,starx5+3,stary3,starx5+6,stary3-3,starx5+9,stary3,starx5+12,stary3,starx5+9,stary3+3,starx5+12,stary3+6,starx5+6,stary3+4,starx5,stary3+6,starx5+3,stary3+3,starx5,stary3,fill="white")
    star15 = screen.create_polygon(starx6,stary3,starx6+3,stary3,starx6+6,stary3-3,starx6+9,stary3,starx6+12,stary3,starx6+9,stary3+3,starx6+12,stary3+6,starx6+6,stary3+4,starx6,stary3+6,starx6+3,stary3+3,starx6,stary3,fill="white")
    star16 = screen.create_polygon(starx7,stary3,starx7+3,stary3,starx7+6,stary3-3,starx7+9,stary3,starx7+12,stary3,starx7+9,stary3+3,starx7+12,stary3+6,starx7+6,stary3+4,starx7,stary3+6,starx7+3,stary3+3,starx7,stary3,fill="white")

    flagpole = screen.create_rectangle(flagx-2,flagy,flagx,flagy+250, fill="black")
##    detail = screen.create_oval(xship-80,yship+15,xship+size*2,yship+20+size*2/2, outline="turquoise")
    base = screen.create_oval(xship-85,yship+20,xship+size*2,yship+20+size*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size,yship+size/1.5, fill="sky blue")

    screen.update()
    sleep(0.01)
    screen.delete(base,dome,flag,strips0,strips1,strips2,strips3,strips4,strips5,strips6,strips7,bluebox,star1,star2,star3,star4,star5,star6,star7,star8,star9,star10,star11,star12,star13,star14,flagpole)

for frameCount in range(0,71):

    #STARSHIP WAVE
    xship = -100 + frameCount*10
    yship = 200 + 25*cos(frameCount*0.2)
    size = 100

    flagx = 100
    flagy = 400
    flagsizex = 175
    flagsizey = 100

    #FLAG
    flag = screen.create_rectangle(flagx,flagy,flagx+flagsizex,flagy+flagsizey, fill ="white")
    strips0 = screen.create_line(flagx,flagy,flagx+flagsizex,flagy,fill="red",width="7")
    strips1 = screen.create_line(flagx,flagy+14,flagx+flagsizex,flagy+14,fill="red",width="7")
    strips2 = screen.create_line(flagx,flagy+28,flagx+flagsizex,flagy+28,fill="red",width="7")
    strips3 = screen.create_line(flagx,flagy+42,flagx+flagsizex,flagy+42,fill="red",width="7")
    strips4 = screen.create_line(flagx,flagy+56,flagx+flagsizex,flagy+56,fill="red",width="7")
    strips5 = screen.create_line(flagx,flagy+70,flagx+flagsizex,flagy+70,fill="red",width="7")
    strips6 = screen.create_line(flagx,flagy+84,flagx+flagsizex,flagy+84,fill="red",width="7")
    strips7 = screen.create_line(flagx,flagy+98,flagx+flagsizex,flagy+98,fill="red",width="7")
    bluebox = screen.create_rectangle(flagx,flagy-5,flagx+72,flagy+45,fill="blue")

    #STARS
    starx = 103
    stary = 400
    starx1 = starx + 15
    starx2 = starx + 30
    starx3 = starx + 45
    starx4 = starx + 5
    starx5 = starx + 20
    starx6 = starx + 35
    starx7 = starx + 50
    stary1 = stary + 11
    stary2 = stary + 22
    stary3 = stary + 33
    #FIRST ROW
    star1 = screen.create_polygon(starx,stary,starx+3,stary,starx+6,stary-3,starx+9,stary,starx+12,stary,starx+9,stary+3,starx+12,stary+6,starx+6,stary+4,starx,stary+6,starx+3,stary+3,starx,stary,fill="white")
    star2 = screen.create_polygon(starx1,stary,starx1+3,stary,starx1+6,stary-3,starx1+9,stary,starx1+12,stary,starx1+9,stary+3,starx1+12,stary+6,starx1+6,stary+4,starx1,stary+6,starx1+3,stary+3,starx1,stary,fill="white")
    star3 = screen.create_polygon(starx2,stary,starx2+3,stary,starx2+6,stary-3,starx2+9,stary,starx2+12,stary,starx2+9,stary+3,starx2+12,stary+6,starx2+6,stary+4,starx2,stary+6,starx2+3,stary+3,starx2,stary,fill="white")
    star4 = screen.create_polygon(starx3,stary,starx3+3,stary,starx3+6,stary-3,starx3+9,stary,starx3+12,stary,starx3+9,stary+3,starx3+12,stary+6,starx3+6,stary+4,starx3,stary+6,starx3+3,stary+3,starx3,stary,fill="white")
    #SECOND ROW
    star5 = screen.create_polygon(starx4,stary1,starx4+3,stary1,starx4+6,stary1-3,starx4+9,stary1,starx4+12,stary1,starx4+9,stary1+3,starx4+12,stary1+6,starx4+6,stary1+4,starx4,stary1+6,starx4+3,stary1+3,starx4,stary1,fill="white")
    star6 = screen.create_polygon(starx5,stary1,starx5+3,stary1,starx5+6,stary1-3,starx5+9,stary1,starx5+12,stary1,starx5+9,stary1+3,starx5+12,stary1+6,starx5+6,stary1+4,starx5,stary1+6,starx5+3,stary1+3,starx5,stary1,fill="white")
    star7 = screen.create_polygon(starx6,stary1,starx6+3,stary1,starx6+6,stary1-3,starx6+9,stary1,starx6+12,stary1,starx6+9,stary1+3,starx6+12,stary1+6,starx6+6,stary1+4,starx6,stary1+6,starx6+3,stary1+3,starx6,stary1,fill="white")
    star8 = screen.create_polygon(starx7,stary1,starx7+3,stary1,starx7+6,stary1-3,starx7+9,stary1,starx7+12,stary1,starx7+9,stary1+3,starx7+12,stary1+6,starx7+6,stary1+4,starx7,stary1+6,starx7+3,stary1+3,starx7,stary1,fill="white")
    #THIRD ROW
    star9 = screen.create_polygon(starx,stary2,starx+3,stary2,starx+6,stary2-3,starx+9,stary2,starx+12,stary2,starx+9,stary2+3,starx+12,stary2+6,starx+6,stary2+4,starx,stary2+6,starx+3,stary2+3,starx,stary2,fill="white")
    star10 = screen.create_polygon(starx1,stary2,starx1+3,stary2,starx1+6,stary2-3,starx1+9,stary2,starx1+12,stary2,starx1+9,stary2+3,starx1+12,stary2+6,starx1+6,stary2+4,starx1,stary2+6,starx1+3,stary2+3,starx1,stary2,fill="white")
    star11 = screen.create_polygon(starx2,stary2,starx2+3,stary2,starx2+6,stary2-3,starx2+9,stary2,starx2+12,stary2,starx2+9,stary2+3,starx2+12,stary2+6,starx2+6,stary2+4,starx2,stary2+6,starx2+3,stary2+3,starx2,stary2,fill="white")
    star12 = screen.create_polygon(starx3,stary2,starx3+3,stary2,starx3+6,stary2-3,starx3+9,stary2,starx3+12,stary2,starx3+9,stary2+3,starx3+12,stary2+6,starx3+6,stary2+4,starx3,stary2+6,starx3+3,stary2+3,starx3,stary2,fill="white")
    #FOURTH ROW
    star13 = screen.create_polygon(starx4,stary3,starx4+3,stary3,starx4+6,stary3-3,starx4+9,stary3,starx4+12,stary3,starx4+9,stary3+3,starx4+12,stary3+6,starx4+6,stary3+4,starx4,stary3+6,starx4+3,stary3+3,starx4,stary3,fill="white")
    star14 = screen.create_polygon(starx5,stary3,starx5+3,stary3,starx5+6,stary3-3,starx5+9,stary3,starx5+12,stary3,starx5+9,stary3+3,starx5+12,stary3+6,starx5+6,stary3+4,starx5,stary3+6,starx5+3,stary3+3,starx5,stary3,fill="white")
    star15 = screen.create_polygon(starx6,stary3,starx6+3,stary3,starx6+6,stary3-3,starx6+9,stary3,starx6+12,stary3,starx6+9,stary3+3,starx6+12,stary3+6,starx6+6,stary3+4,starx6,stary3+6,starx6+3,stary3+3,starx6,stary3,fill="white")
    star16 = screen.create_polygon(starx7,stary3,starx7+3,stary3,starx7+6,stary3-3,starx7+9,stary3,starx7+12,stary3,starx7+9,stary3+3,starx7+12,stary3+6,starx7+6,stary3+4,starx7,stary3+6,starx7+3,stary3+3,starx7,stary3,fill="white")

    flagpole = screen.create_rectangle(flagx-2,flagy,flagx,flagy+250, fill="black")
##    detail = screen.create_oval(xship-80,yship+15,xship+size*2,yship+20+size*2/2, outline="turquoise")
    base = screen.create_oval(xship-85,yship+20,xship+size*2,yship+20+size*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size,yship+size/1.5, fill="sky blue")

    screen.update()
    sleep(0.01)
    screen.delete(base,dome,flag,strips0,strips1,strips2,strips3,strips4,strips5,strips6,strips7,bluebox,star1,star2,star3,star4,star5,star6,star7,star8,star9,star10,star11,star12,star13,star14,flagpole)

for frame in range(0,50):

    #BEAMER
    
    xship = 600
    yship = 200 + 1.5*sin(frame)
    size1 = 100
    colour = choice(["azure","white","ghost white","snow"])
    size = randint(1, 5)
    beam = screen.create_rectangle(xship + 10 - size, yship + 100, xship + 90 + size, 800, fill = colour)
    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    flagx = 100
    flagy = 400
    flagsizex = 175
    flagsizey = 100

    #FLAG
    flag = screen.create_rectangle(flagx,flagy,flagx+flagsizex,flagy+flagsizey, fill ="white")
    strips0 = screen.create_line(flagx,flagy,flagx+flagsizex,flagy,fill="red",width="7")
    strips1 = screen.create_line(flagx,flagy+14,flagx+flagsizex,flagy+14,fill="red",width="7")
    strips2 = screen.create_line(flagx,flagy+28,flagx+flagsizex,flagy+28,fill="red",width="7")
    strips3 = screen.create_line(flagx,flagy+42,flagx+flagsizex,flagy+42,fill="red",width="7")
    strips4 = screen.create_line(flagx,flagy+56,flagx+flagsizex,flagy+56,fill="red",width="7")
    strips5 = screen.create_line(flagx,flagy+70,flagx+flagsizex,flagy+70,fill="red",width="7")
    strips6 = screen.create_line(flagx,flagy+84,flagx+flagsizex,flagy+84,fill="red",width="7")
    strips7 = screen.create_line(flagx,flagy+98,flagx+flagsizex,flagy+98,fill="red",width="7")
    bluebox = screen.create_rectangle(flagx,flagy-5,flagx+72,flagy+45,fill="blue")

    #STARS
    starx = 103
    stary = 400
    starx1 = starx + 15
    starx2 = starx + 30
    starx3 = starx + 45
    starx4 = starx + 5
    starx5 = starx + 20
    starx6 = starx + 35
    starx7 = starx + 50
    stary1 = stary + 11
    stary2 = stary + 22
    stary3 = stary + 33
    #FIRST ROW
    star1 = screen.create_polygon(starx,stary,starx+3,stary,starx+6,stary-3,starx+9,stary,starx+12,stary,starx+9,stary+3,starx+12,stary+6,starx+6,stary+4,starx,stary+6,starx+3,stary+3,starx,stary,fill="white")
    star2 = screen.create_polygon(starx1,stary,starx1+3,stary,starx1+6,stary-3,starx1+9,stary,starx1+12,stary,starx1+9,stary+3,starx1+12,stary+6,starx1+6,stary+4,starx1,stary+6,starx1+3,stary+3,starx1,stary,fill="white")
    star3 = screen.create_polygon(starx2,stary,starx2+3,stary,starx2+6,stary-3,starx2+9,stary,starx2+12,stary,starx2+9,stary+3,starx2+12,stary+6,starx2+6,stary+4,starx2,stary+6,starx2+3,stary+3,starx2,stary,fill="white")
    star4 = screen.create_polygon(starx3,stary,starx3+3,stary,starx3+6,stary-3,starx3+9,stary,starx3+12,stary,starx3+9,stary+3,starx3+12,stary+6,starx3+6,stary+4,starx3,stary+6,starx3+3,stary+3,starx3,stary,fill="white")
    #SECOND ROW
    star5 = screen.create_polygon(starx4,stary1,starx4+3,stary1,starx4+6,stary1-3,starx4+9,stary1,starx4+12,stary1,starx4+9,stary1+3,starx4+12,stary1+6,starx4+6,stary1+4,starx4,stary1+6,starx4+3,stary1+3,starx4,stary1,fill="white")
    star6 = screen.create_polygon(starx5,stary1,starx5+3,stary1,starx5+6,stary1-3,starx5+9,stary1,starx5+12,stary1,starx5+9,stary1+3,starx5+12,stary1+6,starx5+6,stary1+4,starx5,stary1+6,starx5+3,stary1+3,starx5,stary1,fill="white")
    star7 = screen.create_polygon(starx6,stary1,starx6+3,stary1,starx6+6,stary1-3,starx6+9,stary1,starx6+12,stary1,starx6+9,stary1+3,starx6+12,stary1+6,starx6+6,stary1+4,starx6,stary1+6,starx6+3,stary1+3,starx6,stary1,fill="white")
    star8 = screen.create_polygon(starx7,stary1,starx7+3,stary1,starx7+6,stary1-3,starx7+9,stary1,starx7+12,stary1,starx7+9,stary1+3,starx7+12,stary1+6,starx7+6,stary1+4,starx7,stary1+6,starx7+3,stary1+3,starx7,stary1,fill="white")
    #THIRD ROW
    star9 = screen.create_polygon(starx,stary2,starx+3,stary2,starx+6,stary2-3,starx+9,stary2,starx+12,stary2,starx+9,stary2+3,starx+12,stary2+6,starx+6,stary2+4,starx,stary2+6,starx+3,stary2+3,starx,stary2,fill="white")
    star10 = screen.create_polygon(starx1,stary2,starx1+3,stary2,starx1+6,stary2-3,starx1+9,stary2,starx1+12,stary2,starx1+9,stary2+3,starx1+12,stary2+6,starx1+6,stary2+4,starx1,stary2+6,starx1+3,stary2+3,starx1,stary2,fill="white")
    star11 = screen.create_polygon(starx2,stary2,starx2+3,stary2,starx2+6,stary2-3,starx2+9,stary2,starx2+12,stary2,starx2+9,stary2+3,starx2+12,stary2+6,starx2+6,stary2+4,starx2,stary2+6,starx2+3,stary2+3,starx2,stary2,fill="white")
    star12 = screen.create_polygon(starx3,stary2,starx3+3,stary2,starx3+6,stary2-3,starx3+9,stary2,starx3+12,stary2,starx3+9,stary2+3,starx3+12,stary2+6,starx3+6,stary2+4,starx3,stary2+6,starx3+3,stary2+3,starx3,stary2,fill="white")
    #FOURTH ROW
    star13 = screen.create_polygon(starx4,stary3,starx4+3,stary3,starx4+6,stary3-3,starx4+9,stary3,starx4+12,stary3,starx4+9,stary3+3,starx4+12,stary3+6,starx4+6,stary3+4,starx4,stary3+6,starx4+3,stary3+3,starx4,stary3,fill="white")
    star14 = screen.create_polygon(starx5,stary3,starx5+3,stary3,starx5+6,stary3-3,starx5+9,stary3,starx5+12,stary3,starx5+9,stary3+3,starx5+12,stary3+6,starx5+6,stary3+4,starx5,stary3+6,starx5+3,stary3+3,starx5,stary3,fill="white")
    star15 = screen.create_polygon(starx6,stary3,starx6+3,stary3,starx6+6,stary3-3,starx6+9,stary3,starx6+12,stary3,starx6+9,stary3+3,starx6+12,stary3+6,starx6+6,stary3+4,starx6,stary3+6,starx6+3,stary3+3,starx6,stary3,fill="white")
    star16 = screen.create_polygon(starx7,stary3,starx7+3,stary3,starx7+6,stary3-3,starx7+9,stary3,starx7+12,stary3,starx7+9,stary3+3,starx7+12,stary3+6,starx7+6,stary3+4,starx7,stary3+6,starx7+3,stary3+3,starx7,stary3,fill="white")

    flagpole = screen.create_rectangle(flagx-2,flagy,flagx,flagy+250, fill="black")

    screen.update()
    sleep(0.05)
    screen.delete(beam,base,dome,flag,strips0,strips1,strips2,strips3,strips4,strips5,strips6,strips7,bluebox,star1,star2,star3,star4,star5,star6,star7,star8,star9,star10,star11,star12,star13,star14,flagpole)
  
#Alien
for frameCount in range(0,50):
    x = 600 - 6*frameCount
    y = 500
    size = 100
    xship = 600
    yship = 200 + 1.5*sin(frameCount)
    size1 = 100

    flagx = 100
    flagy = 400
    flagsizex = 175
    flagsizey = 100

    #FLAG
    flag = screen.create_rectangle(flagx,flagy,flagx+flagsizex,flagy+flagsizey, fill ="white")
    strips0 = screen.create_line(flagx,flagy,flagx+flagsizex,flagy,fill="red",width="7")
    strips1 = screen.create_line(flagx,flagy+14,flagx+flagsizex,flagy+14,fill="red",width="7")
    strips2 = screen.create_line(flagx,flagy+28,flagx+flagsizex,flagy+28,fill="red",width="7")
    strips3 = screen.create_line(flagx,flagy+42,flagx+flagsizex,flagy+42,fill="red",width="7")
    strips4 = screen.create_line(flagx,flagy+56,flagx+flagsizex,flagy+56,fill="red",width="7")
    strips5 = screen.create_line(flagx,flagy+70,flagx+flagsizex,flagy+70,fill="red",width="7")
    strips6 = screen.create_line(flagx,flagy+84,flagx+flagsizex,flagy+84,fill="red",width="7")
    strips7 = screen.create_line(flagx,flagy+98,flagx+flagsizex,flagy+98,fill="red",width="7")
    bluebox = screen.create_rectangle(flagx,flagy-5,flagx+72,flagy+45,fill="blue")

    #STARS
    starx = 103
    stary = 400
    starx1 = starx + 15
    starx2 = starx + 30
    starx3 = starx + 45
    starx4 = starx + 5
    starx5 = starx + 20
    starx6 = starx + 35
    starx7 = starx + 50
    stary1 = stary + 11
    stary2 = stary + 22
    stary3 = stary + 33
    #FIRST ROW
    star1 = screen.create_polygon(starx,stary,starx+3,stary,starx+6,stary-3,starx+9,stary,starx+12,stary,starx+9,stary+3,starx+12,stary+6,starx+6,stary+4,starx,stary+6,starx+3,stary+3,starx,stary,fill="white")
    star2 = screen.create_polygon(starx1,stary,starx1+3,stary,starx1+6,stary-3,starx1+9,stary,starx1+12,stary,starx1+9,stary+3,starx1+12,stary+6,starx1+6,stary+4,starx1,stary+6,starx1+3,stary+3,starx1,stary,fill="white")
    star3 = screen.create_polygon(starx2,stary,starx2+3,stary,starx2+6,stary-3,starx2+9,stary,starx2+12,stary,starx2+9,stary+3,starx2+12,stary+6,starx2+6,stary+4,starx2,stary+6,starx2+3,stary+3,starx2,stary,fill="white")
    star4 = screen.create_polygon(starx3,stary,starx3+3,stary,starx3+6,stary-3,starx3+9,stary,starx3+12,stary,starx3+9,stary+3,starx3+12,stary+6,starx3+6,stary+4,starx3,stary+6,starx3+3,stary+3,starx3,stary,fill="white")
    #SECOND ROW
    star5 = screen.create_polygon(starx4,stary1,starx4+3,stary1,starx4+6,stary1-3,starx4+9,stary1,starx4+12,stary1,starx4+9,stary1+3,starx4+12,stary1+6,starx4+6,stary1+4,starx4,stary1+6,starx4+3,stary1+3,starx4,stary1,fill="white")
    star6 = screen.create_polygon(starx5,stary1,starx5+3,stary1,starx5+6,stary1-3,starx5+9,stary1,starx5+12,stary1,starx5+9,stary1+3,starx5+12,stary1+6,starx5+6,stary1+4,starx5,stary1+6,starx5+3,stary1+3,starx5,stary1,fill="white")
    star7 = screen.create_polygon(starx6,stary1,starx6+3,stary1,starx6+6,stary1-3,starx6+9,stary1,starx6+12,stary1,starx6+9,stary1+3,starx6+12,stary1+6,starx6+6,stary1+4,starx6,stary1+6,starx6+3,stary1+3,starx6,stary1,fill="white")
    star8 = screen.create_polygon(starx7,stary1,starx7+3,stary1,starx7+6,stary1-3,starx7+9,stary1,starx7+12,stary1,starx7+9,stary1+3,starx7+12,stary1+6,starx7+6,stary1+4,starx7,stary1+6,starx7+3,stary1+3,starx7,stary1,fill="white")
    #THIRD ROW
    star9 = screen.create_polygon(starx,stary2,starx+3,stary2,starx+6,stary2-3,starx+9,stary2,starx+12,stary2,starx+9,stary2+3,starx+12,stary2+6,starx+6,stary2+4,starx,stary2+6,starx+3,stary2+3,starx,stary2,fill="white")
    star10 = screen.create_polygon(starx1,stary2,starx1+3,stary2,starx1+6,stary2-3,starx1+9,stary2,starx1+12,stary2,starx1+9,stary2+3,starx1+12,stary2+6,starx1+6,stary2+4,starx1,stary2+6,starx1+3,stary2+3,starx1,stary2,fill="white")
    star11 = screen.create_polygon(starx2,stary2,starx2+3,stary2,starx2+6,stary2-3,starx2+9,stary2,starx2+12,stary2,starx2+9,stary2+3,starx2+12,stary2+6,starx2+6,stary2+4,starx2,stary2+6,starx2+3,stary2+3,starx2,stary2,fill="white")
    star12 = screen.create_polygon(starx3,stary2,starx3+3,stary2,starx3+6,stary2-3,starx3+9,stary2,starx3+12,stary2,starx3+9,stary2+3,starx3+12,stary2+6,starx3+6,stary2+4,starx3,stary2+6,starx3+3,stary2+3,starx3,stary2,fill="white")
    #FOURTH ROW
    star13 = screen.create_polygon(starx4,stary3,starx4+3,stary3,starx4+6,stary3-3,starx4+9,stary3,starx4+12,stary3,starx4+9,stary3+3,starx4+12,stary3+6,starx4+6,stary3+4,starx4,stary3+6,starx4+3,stary3+3,starx4,stary3,fill="white")
    star14 = screen.create_polygon(starx5,stary3,starx5+3,stary3,starx5+6,stary3-3,starx5+9,stary3,starx5+12,stary3,starx5+9,stary3+3,starx5+12,stary3+6,starx5+6,stary3+4,starx5,stary3+6,starx5+3,stary3+3,starx5,stary3,fill="white")
    star15 = screen.create_polygon(starx6,stary3,starx6+3,stary3,starx6+6,stary3-3,starx6+9,stary3,starx6+12,stary3,starx6+9,stary3+3,starx6+12,stary3+6,starx6+6,stary3+4,starx6,stary3+6,starx6+3,stary3+3,starx6,stary3,fill="white")
    star16 = screen.create_polygon(starx7,stary3,starx7+3,stary3,starx7+6,stary3-3,starx7+9,stary3,starx7+12,stary3,starx7+9,stary3+3,starx7+12,stary3+6,starx7+6,stary3+4,starx7,stary3+6,starx7+3,stary3+3,starx7,stary3,fill="white")

    flagpole = screen.create_rectangle(flagx-2,flagy,flagx,flagy+250, fill="black")

    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    #ALIEN
    body = screen.create_rectangle(x+15,y-10+size,x-15+size,y+size+80,fill="grey")
    ahead = screen.create_oval(x,y,x+size,y+10+size,fill="grey")
    eye = screen.create_oval(x+20,y+15,x-20+size,y-15+size,fill="white")
    pupil = screen.create_oval(x+40,y+35,x-40+size,y-35+size,fill="black")

    #RIGHT ARM
    arm1 = screen.create_line(x+15,y+25+size,x-5,y+35+size,x-30,y+10+size,width=5)
    finger1 = screen.create_line(x-30,y+10+size,x-30,y+size,width=3)
    finger2 = screen.create_line(x-30,y+10+size,x-38,y+2+size,width=3)
    finger3 = screen.create_line(x-30,y+10+size,x-40,y+10+size,width=3)

    #LEFT ARM                   
    arm2 = screen.create_line(x-15+size,y+25+size,x-15+size+20,y+25+size,x-15+size+45,y+50+size,width=5)
    finger4 = screen.create_line(x-15+size+45,y+50+size,x-15+size+45,y+60+size,width=3)
    finger5 = screen.create_line(x-15+size+45,y+50+size,x-15+size+52,y+58+size,width=3)
    finger6 = screen.create_line(x-15+size+45,y+50+size,x-15+size+55,y+50+size,width=3)

    #LEGS
    leg1 = screen.create_line(x+18,y+size+80,x-5,y+size+115,x+14,y+size+135,width=6)
    leg2 = screen.create_line(x-18+size,y+size+80,x+6+size,y+size+135,width=6)
    
    screen.update()
    sleep(0.01)
    screen.delete(flag,strips0,strips1,strips2,strips3,strips4,strips5,strips6,strips7,bluebox,star1,star2,star3,star4,star5,star6,star7,star8,star9,star10,star11,star12,star13,star14,flagpole,ahead,eye,pupil,body,base,dome,arm1,finger1,finger2,finger3,arm2,finger4,finger5,finger6,leg1,leg2)

for frameCount in range(0,70):
    x = 300
    y = 500
    size = 100

    xship = 600
    yship = 200 + 1.5*sin(frameCount)
    size1 = 100

    rx = 250 - 2*frameCount
    ry = 570 -4* frameCount
    rsize = 10

    #STARSHIP
    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    #ALIEN
    body = screen.create_rectangle(x+15,y-10+size,x-15+size,y+size+80,fill="grey")
    ahead = screen.create_oval(x,y,x+size,y+10+size,fill="grey")
    eye = screen.create_oval(x+20,y+15,x-20+size,y-15+size,fill="white")
    pupil = screen.create_oval(x+40,y+35,x-40+size,y-35+size,fill="black")

    #RIGHT ARM
    arm1 = screen.create_line(x+15,y+25+size,x-5,y+35+size,x-30,y+10+size,width=5)
    finger1 = screen.create_line(x-30,y+10+size,x-30,y+size,width=3)
    finger2 = screen.create_line(x-30,y+10+size,x-38,y+2+size,width=3)
    finger3 = screen.create_line(x-30,y+10+size,x-40,y+10+size,width=3)

    #LEFT ARM
    arm2 = screen.create_line(x-15+size,y+25+size,x-15+size+20,y+25+size,x-15+size+45,y+50+size,width=5)
    finger4 = screen.create_line(x-15+size+45,y+50+size,x-15+size+45,y+60+size,width=3)
    finger5 = screen.create_line(x-15+size+45,y+50+size,x-15+size+52,y+58+size,width=3)
    finger6 = screen.create_line(x-15+size+45,y+50+size,x-15+size+55,y+50+size,width=3)

    #RAYGUN
    ray1 = screen.create_oval(rx,ry,rx+rsize,ry+rsize,fill="#BFFF00")
    raybase = screen.create_polygon(x-30,y+10+size,x-40,y+20+size,x-45,y+15+size,x-40,y+10+size,x-45,y-10+size,x-40,y-15+size,fill="indian red")
    raygun = screen.create_polygon(x-20,y+5+size,x-45,y-20+size,x-50,y+10+size,fill="orange")
    raytip = screen.create_oval(x-50,y-30+size,x-40,y-20+size,fill="red")
    
    #LEGS
    leg1 = screen.create_line(x+18,y+size+80,x+18,y+size+135,width=6)
    leg2 = screen.create_line(x-18+size,y+size+80,x-18+size,y+size+135,width=6)

    flagx = 100
    flagy = 400
    flagsizex = 175
    flagsizey = 100

    #FLAG
    flag = screen.create_rectangle(flagx,flagy,flagx+flagsizex,flagy+flagsizey, fill ="white")
    strips0 = screen.create_line(flagx,flagy,flagx+flagsizex,flagy,fill="red",width="7")
    strips1 = screen.create_line(flagx,flagy+14,flagx+flagsizex,flagy+14,fill="red",width="7")
    strips2 = screen.create_line(flagx,flagy+28,flagx+flagsizex,flagy+28,fill="red",width="7")
    strips3 = screen.create_line(flagx,flagy+42,flagx+flagsizex,flagy+42,fill="red",width="7")
    strips4 = screen.create_line(flagx,flagy+56,flagx+flagsizex,flagy+56,fill="red",width="7")
    strips5 = screen.create_line(flagx,flagy+70,flagx+flagsizex,flagy+70,fill="red",width="7")
    strips6 = screen.create_line(flagx,flagy+84,flagx+flagsizex,flagy+84,fill="red",width="7")
    strips7 = screen.create_line(flagx,flagy+98,flagx+flagsizex,flagy+98,fill="red",width="7")
    bluebox = screen.create_rectangle(flagx,flagy-5,flagx+72,flagy+45,fill="blue")

    #STARS
    starx = 103
    stary = 400
    starx1 = starx + 15
    starx2 = starx + 30
    starx3 = starx + 45
    starx4 = starx + 5
    starx5 = starx + 20
    starx6 = starx + 35
    starx7 = starx + 50
    stary1 = stary + 11
    stary2 = stary + 22
    stary3 = stary + 33
    #FIRST ROW
    star1 = screen.create_polygon(starx,stary,starx+3,stary,starx+6,stary-3,starx+9,stary,starx+12,stary,starx+9,stary+3,starx+12,stary+6,starx+6,stary+4,starx,stary+6,starx+3,stary+3,starx,stary,fill="white")
    star2 = screen.create_polygon(starx1,stary,starx1+3,stary,starx1+6,stary-3,starx1+9,stary,starx1+12,stary,starx1+9,stary+3,starx1+12,stary+6,starx1+6,stary+4,starx1,stary+6,starx1+3,stary+3,starx1,stary,fill="white")
    star3 = screen.create_polygon(starx2,stary,starx2+3,stary,starx2+6,stary-3,starx2+9,stary,starx2+12,stary,starx2+9,stary+3,starx2+12,stary+6,starx2+6,stary+4,starx2,stary+6,starx2+3,stary+3,starx2,stary,fill="white")
    star4 = screen.create_polygon(starx3,stary,starx3+3,stary,starx3+6,stary-3,starx3+9,stary,starx3+12,stary,starx3+9,stary+3,starx3+12,stary+6,starx3+6,stary+4,starx3,stary+6,starx3+3,stary+3,starx3,stary,fill="white")
    #SECOND ROW
    star5 = screen.create_polygon(starx4,stary1,starx4+3,stary1,starx4+6,stary1-3,starx4+9,stary1,starx4+12,stary1,starx4+9,stary1+3,starx4+12,stary1+6,starx4+6,stary1+4,starx4,stary1+6,starx4+3,stary1+3,starx4,stary1,fill="white")
    star6 = screen.create_polygon(starx5,stary1,starx5+3,stary1,starx5+6,stary1-3,starx5+9,stary1,starx5+12,stary1,starx5+9,stary1+3,starx5+12,stary1+6,starx5+6,stary1+4,starx5,stary1+6,starx5+3,stary1+3,starx5,stary1,fill="white")
    star7 = screen.create_polygon(starx6,stary1,starx6+3,stary1,starx6+6,stary1-3,starx6+9,stary1,starx6+12,stary1,starx6+9,stary1+3,starx6+12,stary1+6,starx6+6,stary1+4,starx6,stary1+6,starx6+3,stary1+3,starx6,stary1,fill="white")
    star8 = screen.create_polygon(starx7,stary1,starx7+3,stary1,starx7+6,stary1-3,starx7+9,stary1,starx7+12,stary1,starx7+9,stary1+3,starx7+12,stary1+6,starx7+6,stary1+4,starx7,stary1+6,starx7+3,stary1+3,starx7,stary1,fill="white")
    #THIRD ROW
    star9 = screen.create_polygon(starx,stary2,starx+3,stary2,starx+6,stary2-3,starx+9,stary2,starx+12,stary2,starx+9,stary2+3,starx+12,stary2+6,starx+6,stary2+4,starx,stary2+6,starx+3,stary2+3,starx,stary2,fill="white")
    star10 = screen.create_polygon(starx1,stary2,starx1+3,stary2,starx1+6,stary2-3,starx1+9,stary2,starx1+12,stary2,starx1+9,stary2+3,starx1+12,stary2+6,starx1+6,stary2+4,starx1,stary2+6,starx1+3,stary2+3,starx1,stary2,fill="white")
    star11 = screen.create_polygon(starx2,stary2,starx2+3,stary2,starx2+6,stary2-3,starx2+9,stary2,starx2+12,stary2,starx2+9,stary2+3,starx2+12,stary2+6,starx2+6,stary2+4,starx2,stary2+6,starx2+3,stary2+3,starx2,stary2,fill="white")
    star12 = screen.create_polygon(starx3,stary2,starx3+3,stary2,starx3+6,stary2-3,starx3+9,stary2,starx3+12,stary2,starx3+9,stary2+3,starx3+12,stary2+6,starx3+6,stary2+4,starx3,stary2+6,starx3+3,stary2+3,starx3,stary2,fill="white")
    #FOURTH ROW
    star13 = screen.create_polygon(starx4,stary3,starx4+3,stary3,starx4+6,stary3-3,starx4+9,stary3,starx4+12,stary3,starx4+9,stary3+3,starx4+12,stary3+6,starx4+6,stary3+4,starx4,stary3+6,starx4+3,stary3+3,starx4,stary3,fill="white")
    star14 = screen.create_polygon(starx5,stary3,starx5+3,stary3,starx5+6,stary3-3,starx5+9,stary3,starx5+12,stary3,starx5+9,stary3+3,starx5+12,stary3+6,starx5+6,stary3+4,starx5,stary3+6,starx5+3,stary3+3,starx5,stary3,fill="white")
    star15 = screen.create_polygon(starx6,stary3,starx6+3,stary3,starx6+6,stary3-3,starx6+9,stary3,starx6+12,stary3,starx6+9,stary3+3,starx6+12,stary3+6,starx6+6,stary3+4,starx6,stary3+6,starx6+3,stary3+3,starx6,stary3,fill="white")
    star16 = screen.create_polygon(starx7,stary3,starx7+3,stary3,starx7+6,stary3-3,starx7+9,stary3,starx7+12,stary3,starx7+9,stary3+3,starx7+12,stary3+6,starx7+6,stary3+4,starx7,stary3+6,starx7+3,stary3+3,starx7,stary3,fill="white")

    flagpole = screen.create_rectangle(flagx-2,flagy,flagx,flagy+250, fill="black")
##    detail = screen.create_oval(xship-80,yship+15,xship+size*2,yship+20+size*2/2, outline="turquoise")
    
    screen.update()
    sleep(0.01)
    screen.delete(raytip,raygun,raybase,flag,strips0,strips1,strips2,strips3,strips4,strips5,strips6,strips7,bluebox,star1,star2,star3,star4,star5,star6,star7,star8,star9,star10,star11,star12,star13,star14,flagpole,ahead,eye,pupil,body,base,dome,arm1,finger1,finger2,finger3,arm2,finger4,finger5,finger6,leg1,leg2,ray1)

#FLAG ERASED
for frameCount in range(0,100):

    x = 300 + 3*frameCount
    y = 500
    size = 100

    xship = 600
    yship = 200 + 1.5*sin(frameCount)
    size1 = 100

    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    #ALIEN
    body = screen.create_rectangle(x+15,y-10+size,x-15+size,y+size+80,fill="grey")
    ahead = screen.create_oval(x,y,x+size,y+10+size,fill="grey")
    eye = screen.create_oval(x+20,y+15,x-20+size,y-15+size,fill="white")
    pupil = screen.create_oval(x+40,y+35,x-40+size,y-35+size,fill="black")

    #RIGHT ARM
    arm1 = screen.create_line(x+15,y+25+size,x-5,y+35+size,x-30,y+10+size,width=5)
    finger1 = screen.create_line(x-30,y+10+size,x-30,y+size,width=3)
    finger2 = screen.create_line(x-30,y+10+size,x-38,y+2+size,width=3)
    finger3 = screen.create_line(x-30,y+10+size,x-40,y+10+size,width=3)

    #LEFT ARM
    arm2 = screen.create_line(x-15+size,y+25+size,x-15+size+20,y+25+size,x-15+size+45,y+50+size,width=5)
    finger4 = screen.create_line(x-15+size+45,y+50+size,x-15+size+45,y+60+size,width=3)
    finger5 = screen.create_line(x-15+size+45,y+50+size,x-15+size+52,y+58+size,width=3)
    finger6 = screen.create_line(x-15+size+45,y+50+size,x-15+size+55,y+50+size,width=3)

    #LEGS
    leg1 = screen.create_line(x+18,y+size+80,x-5,y+size+115,x+14,y+size+135,width=6)
    leg2 = screen.create_line(x-18+size,y+size+80,x+6+size,y+size+135,width=6)
    
    screen.update()
    sleep(0.01)
    screen.delete(ahead,eye,pupil,body,base,dome,arm1,finger1,finger2,finger3,arm2,finger4,finger5,finger6,leg1,leg2)

#ALIEN GOES BACK INTO THE SHIP
for frame in range(0,50):

    #BEAMER
    
    xship = 600
    yship = 200 + 1.5*sin(frame)
    size1 = 100
    colour = choice(["azure","white","ghost white","snow"])
    size = randint(1, 5)
    beam = screen.create_rectangle(xship + 10 - size, yship + 100, xship + 90 + size, 800, fill = colour)
    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    screen.update()
    sleep(0.01)
    screen.delete(beam,base,dome)

#STARSHIP FLIES AWAY
for frameCount in range(0,50):
    xship = 600 - frameCount*10
    yship = 0.05*frameCount**2+frameCount+200
    size1 = 100
    base = screen.create_oval(xship-85,yship+20,xship+size1*2,yship+20+size1*2/2, fill="deep pink")
    dome = screen.create_oval(xship,yship,xship+size1,yship+size1/1.5, fill="sky blue")

    screen.update()
    sleep(0.01)
    screen.delete(base,dome)

#AIN'T YO MOON
screen.create_rectangle(0,0,800,800,fill="black")
screen.create_text(400,400,text="It's not your moon, America. D:",fill="chartreuse",font="comic 18")
