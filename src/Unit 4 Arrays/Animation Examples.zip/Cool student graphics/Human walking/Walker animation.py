from tkinter import *
from time import *

root = Tk()
screen = Canvas( root, width=1199, height=800, background = "white" )
screen.pack()

#RACERS
image1 = PhotoImage( file = "walker1.gif" )
image2 = PhotoImage( file = "walker2.gif" )
image3 = PhotoImage( file = "walker3.gif" )
image4 = PhotoImage( file = "walker4.gif" )
image5 = PhotoImage( file = "walker5.gif" )
image6 = PhotoImage( file = "walker6.gif" )

walkerFiles = [ image1, image2, image3, image4, image5, image6]

for i in range(1,200):
      x = 400 + i*10
      walker = screen.create_image( x, 400, image = walkerFiles[ i % 6 ])
      screen.update()
      sleep(0.05)
      screen.delete( walker )
