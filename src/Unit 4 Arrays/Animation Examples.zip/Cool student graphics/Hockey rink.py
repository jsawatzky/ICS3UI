
from tkinter import *
from random import *
from time import *
from math import *
myInterface = Tk()
screen = Canvas(myInterface, width=1000, height=1000, background="white")
screen.pack()


##### PART 1

#Creating Stands and Snow

snow = screen.create_rectangle(0,0, 1500,1500, fill = "snow2",outline = "white")
stand1 = screen.create_rectangle(0,0, 1500,185, fill = "snow3", outline = "snow3")
stand2 = screen.create_rectangle (945,0, 1500,675, fill = "snow3", outline = "snow3")
stand3 = screen.create_rectangle (0,0, 55,675, fill = "snow3", outline = "snow3")
stand4 = screen.create_rectangle(0,515, 1500,675, fill = "snow3", outline = "snow3")


screen.create_line(0,50, 1500,50)
screen.create_line(0,90, 1500,90)
screen.create_line(0,130, 1500,130)
screen.create_line(0,170, 1500,170)
screen.create_line(0,525, 1500,525)
screen.create_line(0,565, 1500,565)
screen.create_line(0,605, 1500,605)
screen.create_line(0,645, 1500,645)
screen.create_line(0,675, 1500,675)
screen.create_line(15,170, 15,525)
screen.create_line(1,170, 1,525)
screen.create_line(55,170, 55,525)
screen.create_line(945,170, 945,525)
screen.create_line(985,170, 985,525)


#Creating the outline of the rink

screen.create_line( 300,200, 700, 200, fill = "black", width = 3)

screen.create_line (700,200, 900, 205, 950, 350, 900, 500, 700, 500, fill = "black", width = 3, smooth ="true")

screen.create_line( 300,500, 700, 500, fill = "black", width = 3)

screen.create_line (300, 200, 100, 205, 50, 350, 100, 500, 300, 500, fill = "black", width = 3, smooth = "true")

#Creating the blue lines

screen.create_line (350, 200, 350, 500, fill = "blue", width = 30)

screen.create_line(650, 200, 650, 500, fill = "blue", width = 30)

#Creating the red lines

screen.create_line(500, 200, 500, 500, fill = "red", width = 30)

#Creating the two nets
xNet = 835

screen.create_line(825,330, xNet,330.5, xNet,369.5, 825,370, fill = "red", width = 5, smooth = "true")
xNet2 = 165
screen.create_line(xNet2+10,330, xNet2,330.5, xNet2,369.5, xNet2+10,370, fill = "red", width = 5, smooth = "true")

#Creating the people

for pplNum in range(1, 100):
    x = randint(25,975)
    y = randint(50,150)
    faceSize = randint(22,28)

    screen.create_oval( x, y, x+faceSize,y+faceSize,fill="peachpuff3")
    screen.update()

#Creating more people
    
for pplNum in range(1, 100):
    x = randint(25,975)
    y = randint(525,650)
    faceSize = randint(22,28)

    screen.create_oval( x, y, x+faceSize,y+faceSize,fill="peachpuff3")
    screen.update()

for pplNum in range(1, 25):
    x = randint(0,35)
    y = randint(175,550)
    faceSize = randint(22,28)

    screen.create_oval( x, y, x+faceSize,y+faceSize,fill="peachpuff3")
    screen.update()
    
for pplNum in range(1, 25):
    x = randint(935,1000)
    y = randint(175,550)
    faceSize = randint(22,28)

    screen.create_oval( x, y, x+faceSize,y+faceSize,fill="peachpuff3")
    screen.update()
#Creating road and parkinglot

roadlot = screen.create_polygon(340,1000, 340,820, 200,820, 200,675, 650,675, 650,820, 400,820, 400,1000,  fill = "snow4", outline = "black")

##lot = screen.create_polygon(200,820, 650,820, 650,675, 200,675, fill = "snow4")

yellowline = screen.create_line(372,1000, 372,820, fill = "yellow", width = 10, smooth = "true")

yline1 = screen.create_line(200,780, 250,780, fill = "yellow", width = 10)
yline2 = screen.create_line(200,725, 250,725, fill = "yellow", width = 10)
yline3 = screen.create_line(600,725, 650,725, fill = "yellow", width = 10)
yline4 = screen.create_line(600,780, 650,780, fill = "yellow", width = 10)
yline5 = screen.create_line(300,780, 350,780, fill = "yellow", width = 10)
yline6 = screen.create_line(300,725, 400,725, fill = "yellow", width = 10)
yline7 = screen.create_line(300,780, 400,780, fill = "yellow", width = 10)
yline8 = screen.create_line(450,725, 550,725, fill = "yellow", width = 10)
yline9 = screen.create_line(450,780, 550,780, fill = "yellow", width = 10)
yline10 = screen.create_line(350,675, 350,785, fill = "yellow", width = 10)
yline10 = screen.create_line(500,675, 500,785, fill = "yellow", width = 10)

#Cobble stone road/lot
for stoneNum in range (0,100):
    x = randint(343, 395)
    y = randint (820,1000)
    stoneSize = randint(1,3)

    screen.create_oval( x, y, x+stoneSize,y+stoneSize, fill ="honeydew4")
    
for stoneNum in range (0,375):
    x = randint(203, 647)
    y = randint (677,817)
    stoneSize = randint(1,3)

    screen.create_oval( x, y, x+stoneSize,y+stoneSize, fill ="honeydew4")

#creating the cars
x1 = 205 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "black")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)




x1 = 205 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "yellow")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)



x1 = 300 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "orange")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)


x1 = 355 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "red")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)

x1 = 505 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "blue")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)



x1 = 505 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "blue")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)


x1 = 445 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "white")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)

x1 = 445 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


goodcarframe = screen.create_rectangle (x1,y1, x2,y2, fill = "peachpuff3")
goodwheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
goodwheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)

x1 = 505 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "snow3")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)



x1 = 300 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "darkslategray")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)



x1 = 355 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "deepskyblue")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)


x1 = 600 
y1 = 735
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "green")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)


x1 = 600 
y1 = 682
carWidth = 45 
carHeight = 30
wheelSize = carWidth/4

x2= x1+carWidth
y2 = y1 + carHeight
x1wheelA = x1-wheelSize/2
x2wheelA = x1 + wheelSize/2
x1wheelB = x2 - wheelSize/2
x2wheelB = x2 + wheelSize/2
ywheelTop = y2 - wheelSize/2
ywheelBottom = y2 + wheelSize/2


carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "darkgoldenrod")
wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)
#Creating text
screen.create_text( 500, 250, text="Outdoor Hockey Rink", font="Times 25 italic bold", fill = "black")




#####  PART 2

#Hockey Player and Hockey Stick

x = 430
y = 275
headSize = 19
frameCount = 1
x1 = 500
while x< 700:
    frameCount = frameCount + 1
    x = 440 + 7*frameCount
    y = 275
    hstickp1 = screen.create_line(x+37,y+33, x+48, y+63, width = 6)
    hstickp2 = screen.create_line(x+48,y+63, x+60,y+68, width = 6)
    head = screen.create_oval( x, y, x+headSize,y+headSize,fill="peachpuff3")
    body = screen.create_oval(x+10,y + 19, x+10, y+52)
    arm1 = screen.create_line(x+13,y+25, x-22, y+33, width = 3)
    arm2 = screen.create_line(x+13, y+25, x+37,y+33, width = 3)
    leg1 = screen.create_line(x+11,y+52, x-10, y+80, width = 3)
    leg2 = screen.create_line(x+11,y+52, x+27, y+80, width = 3)
    x1 = 500 + 7*frameCount
    y1 = 350
    
    puckSize = 14

    x1puck = x1 - puckSize/2
    x2puck = x1 + puckSize/2
    yTop = y1 - puckSize/2
    yBottom = y1 + puckSize/2
    puck = screen.create_oval(x1puck,yTop, x2puck, yBottom, fill = "black")
    screen.update()
    sleep(0.05)
    screen.delete(hstickp1,hstickp2,head,body,arm1,arm2,leg1,leg2,puck)



head = screen.create_oval( x, y, x+headSize,y+headSize,fill="peachpuff3")
body = screen.create_oval(x+10,y + 19, x+10, y+52)
arm1 = screen.create_line(x+13,y+25, x-22, y+33, width = 3)
arm2 = screen.create_line(x+13, y+25, x+37,y+33, width = 3)
leg1 = screen.create_line(x+11,y+52, x-10, y+80, width = 3)
leg2 = screen.create_line(x+11,y+52, x+27, y+80, width = 3)
hstickp1 = screen.create_line(x+37,y+33, x+48, y+63, width = 6)
hstickp2 = screen.create_line(x+48,y+63, x+60,y+68, width = 6)

x1 = 700
frameCount = 1
while x1< xNet:
    frameCount = frameCount + 1
    x1 = 760 + 7*frameCount
    y1 = 350
    puckSize = 14

    x1puck = x1 - puckSize/2
    x2puck = x1 + puckSize/2
    yTop = y1 - puckSize/2
    yBottom = y1 + puckSize/2
    puck = screen.create_oval(x1puck,yTop, x2puck, yBottom, fill = "black")

    screen.update()
    sleep(0.05)
    screen.delete(puck)

x1 = xNet
y1 = 350
puckSize = 14

x1puck = x1 - puckSize/2
x2puck = x1 + puckSize/2
yTop = y1 - puckSize/2
yBottom = y1 + puckSize/2
puck = screen.create_oval(x1puck,yTop, x2puck, yBottom, fill = "black")
    

#Creating text
x=1
y=350
for frameCount in range(1,150
                        ):
    frameCount = frameCount + 1
    x=1  + 8*frameCount +sin(frameCount)
    y = 350 + 8*sin(frameCount)
    colour = choice(["red", "black", "blue", "green"])
    goal = screen.create_text( x, y, text="Goal!!!", font="Times 72 italic bold", fill = colour )
    screen.update()
    sleep(0.05)
    screen.delete(goal)




##Making car move

for frameCount in range (1,15):
    x1 = 445 - 8*(frameCount) 
    y1 = 735 + 5*(frameCount)
    carWidth = 45 
    carHeight = 30
    wheelSize = carWidth/4

    x2= x1+carWidth
    y2 = y1 + carHeight
    x1wheelA = x1-wheelSize/2
    x2wheelA = x1 + wheelSize/2
    x1wheelB = x2 - wheelSize/2
    x2wheelB = x2 + wheelSize/2
    ywheelTop = y2 - wheelSize/2
    ywheelBottom = y2 + wheelSize/2


    carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "peachpuff3")
    wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
    wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)

    screen.update()
    sleep(0.05)
    screen.delete(carframe, wheelA, wheelB,goodcarframe, goodwheelA,goodwheelB)



for frameCount in range (1,200):
    x1 = 325
    y1 = 805 + 5*(frameCount)
    carWidth = 45 
    carHeight = 30
    wheelSize = carWidth/4

    x2= x1+carWidth
    y2 = y1 + carHeight
    x1wheelA = x1-wheelSize/2
    x2wheelA = x1 + wheelSize/2
    x1wheelB = x2 - wheelSize/2
    x2wheelB = x2 + wheelSize/2
    ywheelTop = y2 - wheelSize/2
    ywheelBottom = y2 + wheelSize/2


    carframe = screen.create_rectangle (x1,y1, x2,y2, fill = "peachpuff3")
    wheelA = screen.create_oval (x1wheelA,ywheelTop, x2wheelA,ywheelBottom)
    wheelB = screen.create_oval (x1wheelB,ywheelTop, x2wheelB,ywheelBottom)

    

    x1 = 400
    y1 = 742
    x2 = x1+5
    y2 = y1 + 10
    x3 = x2 + 10
    x4 = x2 + 5
    y3 = y2 + 10
    x5 = x4+5
    y4 = y3 + 10
    x6 = x1
    y5 = y3 +4
    x7 = x1 - 15
    x8 = x1-10
    x9 = x1-15
    x10 = x1 - 5

    colour = choice(["red", "white", "orange", "blue"])
    star = screen.create_polygon(x1,y1, x2,y2, x3,y2, x4,y3, x5,y4, x6,y5, x7,y4, x8,y3, x9,y2, x10,y2, x1,y1, fill = colour)

    screen.update()
    sleep(0.05)
    screen.delete(star,carframe,wheelA,wheelB)






###DRAWS A GRID OVERLAY TO HELP YOU PLAN THE SCENE
##spacing = 100
##for x in range(0, 1500, spacing): 
##    screen.create_line(x, 10, x, 1500, fill="blue")
##    screen.create_text(x, 0, text=str(x), font="Times 8", anchor = N)
##
##for y in range(0, 1500, spacing):
##    screen.create_line(20, y, 1500, y, fill="blue")
##    screen.create_text(0, y, text=str(y), font="Times 8", anchor = W)
##
##screen.update()
##

