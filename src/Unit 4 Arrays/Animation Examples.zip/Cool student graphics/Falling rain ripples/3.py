
from tkinter import *
from math import *
from time import *
from random import *


master = Tk()
screen = Canvas( master, width = 1024, height = 650, background = "skyblue")
screen.pack()

pond = PhotoImage (file="ponf.gif")

screen.create_image(525,325,image=pond)


numdrops = 100

size = []
x = []
y = []
Speed = []
drop = []
radius=[]
appearsAfter=[]
for i in range(0,numdrops):
    newSize = randint(5,25)
    newX = randint(0,700)
    newY = randint(50,570)
    newSpeed = randint(1,3)
    newappearsAfter = randint(1,200)
    


    size.append( newSize )
    x.append( newX )
    y.append( newY )
    Speed.append( newSpeed)
    drop.append ( 0 )
    radius.append(0)
    appearsAfter.append(newappearsAfter )
    



for frameCount in range( 0, 200 ):
    
    for i in range(0,numdrops):
        if frameCount >=  appearsAfter[i]:
            drop[i] = screen.create_oval( x[i]-radius[i]*2, y[i]-radius[i],x[i]+radius[i]*2,y[i]+radius[i], outline="skyblue",width="2")
            if radius[i] < size[i]:
                radius[i]= radius[i] + Speed[i]
            else:
                screen.delete(drop[i])
                
                
    screen.update()  
    sleep(0.1)
    for k in range( 0, numdrops ):
        screen.delete(drop[k])




