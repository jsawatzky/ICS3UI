#import necessary files
from tkinter import *
from math import *
from time import *
from random import *


#create the canvas
root= Tk()
myscreen = Canvas(root,width=800,height=800,background="light blue")
myscreen.pack()

#create background
myscreen.create_rectangle(0,350,800,800,fill="green")
myscreen.create_oval(500,50,650,200,fill="yellow")

#importing and creating oil barrel
barrelImageFile=PhotoImage(file="ezimba.gif")
barrel=myscreen.create_image(400,300,image=barrelImageFile)
myscreen.update()

#importing missile
missileImageFile=PhotoImage(file="missile.gif")

#animating missile
for a in range(0,100):
    missile=myscreen.create_image(100+3*a,600-3*a,image=missileImageFile)
    myscreen.update()
    sleep(0.015)
    myscreen.delete(missile)
explosionImageFile=PhotoImage(file="explosion.gif")
explosion=myscreen.create_image(400,300,image=explosionImageFile)

#makes barrel dissapear
myscreen.delete(barrel)

#create necessary arrays for animation
size=[]
x=[]
y=[]
speedoil=[]
speedrain=[]
rain=[]
drop=[]
oil=[]
fire=[]
flame=[]
#import fire images
for b in range(0,3):
    fire.append(PhotoImage(file="fire"+str(b+1)+".gif"))
#add appropriate speeds and starting points for animation into array
for i in range(0,350):
    size.append(randint(10,17))
    x.append(randint(300,500))
    y.append(randint(-800,450))
    speedoil.append(randint(-6,6))
    speedrain.append(randint(4,10))
    flame.append(0)
    oil.append(0)
    rain.append(0)
    drop.append(0)

for i in range(0,40):
    #removal of explosion
    if i==5:
        myscreen.delete(explosion)
        
    #creation of fire
    for m in range(0,15):
        firex=randint(0,800)
        firey=randint(250,300)+m%3*100
        flame[m]=myscreen.create_image(firex,firey,image=fire[randint(0,2)])
        myscreen.delete(flame[m-1])
    #animate oil flying up
    for h in range(0,250):
        x[h]=x[h]+1.5*speedoil[h]
        y[h]=y[h]-1.5*speedrain[h]
        oil[h]=myscreen.create_oval(x[h]-size[h],y[h]+size[h]-speedrain[h],x[h]+size[h]+speedoil[h],y[h]-size[h]-speedrain[h],fill="black")
    myscreen.update()
    sleep(0.005)
    for j in range(0,250):
        myscreen.delete(oil[j])
    for n in range(0,14):
        myscreen.delete(flame[n])    

#animate falling droplets of oil
for j in range(1,500):
    for m in range(0,15):
        
        firex=randint(0,800)
        firey=randint(250,300)+m%3*100
        if j>=80:
            firey=firey-150    
        flame[m]=myscreen.create_image(firex,firey,image=fire[randint(0,2)])
        myscreen.delete(flame[m-1])
    for k in range(0,250):
        y[k]=y[k]+speedrain[k]
        colorrand=randint(0,1)
        rain[k]=myscreen.create_oval(x[k]-size[k],y[k]+size[k],x[k]+size[k],y[k]-size[k],fill="black")
        drop[k]=myscreen.create_polygon(x[k]-size[k],y[k],x[k]+size[k],y[k],x[k],y[k]-(3*size[k]),fill="black")

    myscreen.update()

    for m in range(0,250):
        myscreen.delete(rain[m])
        myscreen.delete(drop[m])
    
