from tkinter import *
from math import *
from time import *
from random import *

#window 
root = Tk()
WIDTH = 600
HEIGHT = 600
canvas = Canvas(root, width = WIDTH, height = HEIGHT, bg = "black")
canvas.pack()

#frames
FPS = 60
targetTime = 1 / FPS

#setup
running = True

def init():
    global menu, play, gameOver

    menu = menuState()
    play = playState()

def run():
    ticks = 0
    ticker = 0

    init()
    
    #game loop
    while(running):
        
        start = time()
        
        update()
        draw()
        
        elapsed = time() - start
        wait = targetTime - elapsed
        if wait < 0: wait = 0
        
        canvas.update()
        sleep(wait)
        canvas.delete(ALL)

#sets the current state of the game
def setState(state):
    global currentState
    currentState = state

#gets a grid reference and returns the actual screen position
def posFromIndex(x, y):
    x = (gridx + separator) + x * (separator + size)
    y = (gridy + separator) + y * (separator + size)  
    return [x, y]

#creates the grid for the game, and gets positions 
def initGrid():
    global gridSize, gridx, gridy, gridWidth, size, separator, grid
    gridSize = 6

    #make empty array of grid
    grid = []
    
    for i in range(gridSize):
        newLine = []
        for j in range(gridSize):
            newLine.append(None)
        grid.append(newLine)

    gridx = 75
    gridy = 125
    gridWidth = 450
    
    separator = (gridWidth / len(grid)) / 8
    size = (gridWidth - (separator * (len(grid) + 1))) / len(grid)

''' ------------------------ OBJECTS  ------------------------'''
class BasicButton:

    def __init__(self, x, y, width, height, hoverColour, baseColour, text):
        self.x = x
        self.y = y
        self.height = height
        self.width = width
        self.hoverColour = hoverColour
        self.baseColour = baseColour
        self.colour = self.baseColour
        self.mouseOver = False
        self.text = text
        self.clicked = False

    def update(self):

        #update colour of button and state
        if (mousex < self.x + self.width / 2 and mousex > self.x - self.width / 2 and
            mousey < self.y + self.height / 2 and mousey > self.y - self.height / 2):
            self.colour = self.hoverColour
            self.mouseOver = True
        else:
            self.mouseOver = False
            self.colour = self.baseColour

        #if the user clicked on the button
        if mouseClicked and self.mouseOver:
            self.clicked = True
        else:
            self.clicked = False

    def draw(self):
        canvas.create_rectangle(self.x - self.width / 2 + 7, self.y - self.height / 2 + 7,
                                self.x + self.width / 2 - 7, self.y + self.height / 2 - 7,
                                fill = self.colour, outline = "white")
        canvas.create_text(self.x, self.y, text = self.text, fill = "white", font = ("Arial Black", int(self.height / 2)))

    def isClicked(self):
        return True if self.clicked else False

''' ------------------------GAME UPDATING ------------------------ '''
def update():

    #update which ever state is active
    if currentState == MENU:
        menu.update()
    elif currentState == PLAY:
        play.update()

    #update the current state of input
    updateKeys()

''' ------------------------GAME DRAWING ------------------------'''
def draw():

    #draw which ever state is active
    if currentState == MENU:
        menu.draw()
    elif currentState == PLAY:
        play.draw()

'''  ------------------------ GAME STATES  ------------------------'''
#menu
class menuState:

    def __init__(self):

        self.startButton = BasicButton(WIDTH / 2, HEIGHT / 2, 120, 40, "#B59982", "#DBBBA0", "START")
        self.quitButton = BasicButton(WIDTH / 2, HEIGHT / 2 + 50, 120, 40, "#B59982", "#DBBBA0", "QUIT")

    def update(self):

        #update the menu buttons
        self.startButton.update()
        self.quitButton.update()

        #if the user presses escape quit the game
        if isPressed(ESCAPE) or self.quitButton.isClicked():
            root.destroy()

        #for getting to the play state
        if isPressed(ENTER) or self.startButton.isClicked():
            setState(PLAY)
            play.restart()
            return
        

    def draw(self):

        #draw bg
        canvas.create_rectangle(0, 0, WIDTH + 10, HEIGHT + 10, fill = "#FAE4D2")

        #title
        canvas.create_text(WIDTH / 2, HEIGHT / 3, fill = "#B59982", font = ("Aharoni", 100), text = "1 7 7 1 4 7")

        #how to play
        canvas.create_text(20, HEIGHT * 3 / 4, fill = "#B59982", font = ("Arial Black", 30), anchor = W, text = "HOW TO PLAY: ")
        canvas.create_text(50, HEIGHT * 4 / 5, fill = "#B59982", font = ("Arial Black", 15), anchor = NW,
            text = "Use your arrow keys to move the tiles. \nWhen three tiles with the same number touch, \nthey merge into one!")

        #draw credits
        canvas.create_text(WIDTH - 10, HEIGHT - 10, fill = "#B59982", font = ("Times", 15), anchor = SE, text = "Credits to Gabriele Cirulli")

        #draw menu buttons
        self.startButton.draw()
        self.quitButton.draw()

#playing 

#game tile
class Tile:

    def __init__(self, pos, value):
        
        self.colours = {
            
            3: '#eee4da', 9: '#ede0c8', 27: '#f2b179',
            81: '#f59563', 243: '#f67c5f', 729: '#f65e3b',
            2187: '#edcf72', 6561: '#edcc61', 19683: '#edc850',
            59049: '#edc53f', 177147: '#edc22e'}
        
        self.pos = pos
        self.value= value
        self.x = posFromIndex(self.pos[0], self.pos[1])[0]
        self.y = posFromIndex(self.pos[0], self.pos[1])[1]
        
        self.moving = False
        self.destroy = False
        self.frameSpeed = 4

    def update(self):
        
        if self.moving:
            
            self.moveHorizontal(self.heading)
            self.moveVertical(self.heading)

    def goto(self, pos, destroy, direction):
        if self.pos == pos:
            return
        
        self.heading = direction
        
        if self.heading == RIGHT: self.speed = (pos[0] - self.x) / self.frameSpeed
        if self.heading == LEFT: self.speed = (self.x - pos[0]) / self.frameSpeed
        if self.heading == UP: self.speed = (pos[1] - self.y) / self.frameSpeed
        if self.heading == DOWN: self.speed = (self.y - pos[1]) / self.frameSpeed
            
        
        #set moving vars
        self.moving = True
        self.newPos = pos
        self.willDestroy = destroy     
    
    def draw(self):
        
        #draw tile bg
        canvas.create_rectangle(self.x, self.y, self.x + size, self.y + size,
                                fill = self.colours[self.value], outline = self.colours[self.value])
        
        #draw value
        font = 30
        canvas.create_text(self.x + size / 2, self.y + size / 2, fill = "black", font = ("Aharoni", int(font)), text = self.getValue())
    
    #gets certain values from the tile
    def getValue(self): return self.value
    def setValue(self, value): self.value = value
    def getPos(self): return self.pos
    def getAbsPos(self): return [self.x, self.y]
    def shouldDestroy(self): return self.destroy
    def isMoving(self): return self.moving
    def getFrameSpeed(self): return self.frameSpeed
    
    
    def moveHorizontal(self, heading):
        
        if heading not in [RIGHT, LEFT]: return
        
        self.x += self.speed if heading == RIGHT else -self.speed
        
        if heading == RIGHT and self.x == self.newPos[0] or heading == LEFT and self.x == self.newPos[0]:
            self.x = self.newPos[0]
            self.moving = False
    
    def moveVertical(self, heading):
        
        if heading not in [UP, DOWN]: return
        
        self.y += self.speed if heading == UP else -self.speed
        
        if heading == UP and self.y == self.newPos[1] or heading == DOWN and self.y == self.newPos[1]:
            self.y = self.newPos[1]
            self.moving = False
            
class playState:

    def __init__(self):

        #for returning back to menu
        self.menuButton = BasicButton(130, 30, 120, 40, "#B59982", "#DBBBA0", "MENU")
        self.newGameButton = BasicButton(400, 100, 200, 40, "#B59982", "#DBBBA0", "NEW GAME")

        self.restart()
        self.gameOverImage = PhotoImage(file = "bush-gameover.gif")
        
    def update(self):

        #update menuButton and newgame button
        self.menuButton.update()
        self.newGameButton.update()

        #go back to main menu if menu button is clicked
        if self.menuButton.isClicked() or isPressed(ESCAPE):
            setState(MENU)
        
        #restart game
        if self.newGameButton.isClicked():
            self.restart()

        #if the player cannot move any more go to game over state
        if self.gameOver():
            return
        
        #handle input into the game
        if isPressed(RIGHT):
            self.horizontal(True)
        elif isPressed(LEFT):
            self.horizontal(False)
        elif isPressed(UP):
            self.vertical(True)
        elif isPressed(DOWN):
            self.vertical(False)
        
        #update tiles
        for row, col in self.getTiles():
            tile = grid[row][col]
            tile.update()
        
        #when tiles are done moving across screen spawn a tile
        if self.moved:
            self.timer += 1
            if self.timer > 4:
                self.spawnTile()
                self.moved = False
                self.timer = 0
   
    def draw(self):

        #draw bg
        canvas.create_rectangle(0, 0, WIDTH + 10, HEIGHT + 10, fill = "#FAE4D2")

        #draw logo
        canvas.create_text(WIDTH / 4, HEIGHT / 7, fill = "#B59982", font = ("Aharoni", 40), text = "1 7 7 1 4 7")

        #draw menu button and new game button
        self.menuButton.draw()
        self.newGameButton.draw()

        #draw grid bg
        canvas.create_rectangle(gridx, gridy, gridx + gridWidth, gridy + gridWidth,
                                fill = "#B59982", outline = "#B59982")

        #draw grid boxes
        for x in range(len(grid)):
            for y in range(len(grid)):

                pos = posFromIndex(x, y)
                canvas.create_rectangle(pos[0], pos[1], pos[0] + size, pos[1] + size,
                                        fill = "#DBBBA0", outline = "#DBBBA0")
        
        #draw tiles
        for row, col in self.getTiles():
            grid[row][col].draw()

        #draw score
        canvas.create_text(WIDTH - 50, 50, text = "SCORE: " + str(self.score), fill = "#B59982", font = ("Aharoni", 20), anchor = E)

        if self.gameOver():

            #draw george bush game over
            canvas.create_image(WIDTH / 2, HEIGHT / 2 + 50, image = self.gameOverImage)
            
    def horizontal(self, right):
        
        if self.moved: # if tiles are currently moving do not move again
            return
        
        #change direction of loop indexing depending on what way to move
        if right:
            gridRange = range(len(grid) - 1, -1, -1)
        else:
            gridRange = range(0, len(grid))
        
        #self.moved = False

        for col in range(0, len(grid)):
            tiles = []
            for row in gridRange:
                
                #get all tiles on the grid in the current row
                tile = grid[row][col]
                if tile != None:
                    tiles.append(tile)

            # merge the tiles together if possible
            direction = RIGHT if right else LEFT
            self.merge(tiles, direction)
            
            for row in gridRange:
                
                tile = tiles.pop(0) if tiles else None
                
                if grid[row][col] != tile:
                    self.moved = True
                
                grid[row][col] = tile #sets tiles to grid
                
                if not tile: #if the current tile is nothing then dont move it
                    continue
                
                #moves tiles to new pos
                pos = posFromIndex(row, col)
                if tile.getAbsPos() != pos:
                    tile.goto(pos, False, direction)        
    
    def vertical(self, up):
        
        if self.moved: # if tiles are currently moving do not move again
            return
        
        #change direction of loop indexing depending on what way to move
        if not up:
            gridRange = range(len(grid) - 1, -1, -1)
        else:
            gridRange = range(0, len(grid))
        
        #self.moved = False

        for row in range(0, len(grid)):
            tiles = []
            for col in gridRange:
                
                #get all tiles on the grid in the current column
                tile = grid[row][col]
                if tile != None:
                    tiles.append(tile)

            # merge the tiles together if possible
            direction = UP if up else DOWN
            self.merge(tiles, direction)
            
            for col in gridRange:
                
                tile = tiles.pop(0) if tiles else None
                
                if grid[row][col] != tile: #checks if tile has moved
                    self.moved = True
                    
                grid[row][col] = tile #sets tiles to grid
                
                if not tile: #if the current tile is null then dont move it
                    continue
                
                #moves tiles to new pos
                pos = posFromIndex(row, col)
                if tile.getAbsPos() != pos:
                    tile.goto(pos, False, direction)                  
        
    def spawnTile(self):
        #gets a list of all empty tile spaces
        
        empty = list(self.getEmptyTiles())
        if not empty: return

        value = 3 if randint(0, 10) < 9 else 9
        
        for i in range(0, 1 if randint(0, 10) < 8 else 2):
            x, y = choice(empty)
            tile = Tile([x, y], value)
            grid[x][y] = tile

    def merge(self, tiles, direction):
        if len(tiles) <= 2:
            return tiles

        i = 0
        while i < len(tiles) - 2:
            tile1 = tiles[i]
            tile2 = tiles[i + 1]
            tile3 = tiles[i + 2]
            
            if tile1.getValue() == tile2.getValue() == tile3.getValue(): # if the 2 tiles have the same value then merge
                
                #move tiles together
                tile1.setValue(tile1.getValue() * 3)
                tile2.goto(tile1.getPos(), True, direction)
                tile3.goto(tile1.getPos(), True, direction)
                
                self.moved = True
                
                del tiles[i + 1]
                del tiles[i + 1]
                
                #increase score
                self.score += tile1.getValue()
                
            i += 1
            
    def getEmptyTiles(self):
        for row in range(0, len(grid)):
            for col in range(0, len(grid)):
                if not grid[row][col]:
                    yield row, col
    
    def getTiles(self):
        for row in range(0, len(grid)):
            for col in range(0, len(grid)):
                if grid[row][col]:
                    yield row, col
    
    def gameOver(self):

        #determines if the game is over by checking if there are empty tiles or you can merge tiles
        if any(self.getEmptyTiles()) or self.canMove():
            return False

        return True
    
    def canMove(self):
        
        #determines if player can merge tiles
        for row in range(len(grid)): # vertical columns
            for col in range(len(grid) - 2):
                tile1 = grid[row][col]
                tile2 = grid[row][col + 1]
                tile3 = grid[row][col + 2]
                if tile1.getValue() == tile2.getValue() == tile3.getValue():
                    return True
                
        for col in range(len(grid)): # horizontal rows
            for row in range(len(grid) - 2):
                tile1 = grid[row][col]
                tile2 = grid[row + 1][col]
                tile3 = grid[row + 2][col]
                if tile1.getValue() == tile2.getValue() == tile3.getValue():
                    return True
    
    def restart(self):
        
        initGrid()
        
        self.spawnTile()
        self.spawnTile() 
        self.spawnTile()
        
        self.score = 0
        self.moved = False
        self.timer = 0
        
''' GAME HANDLERS''' 

#game keys
NUM_KEYS = 7
LEFT = 0
RIGHT = 1
UP = 2
DOWN = 3
ENTER = 4
ESCAPE = 5
F2 = 6

#mouse
mousex = 0
mousey = 0
mouseClicked = False

#game states
MENU = 0
PLAY = 1
currentState = MENU

#arrays for keeping track of which keys are active or not
keys = [False] * NUM_KEYS
pkeys = [False] * NUM_KEYS

#game key functions
def setKey(k, b):
    keys[k] = b

def isPressed(k):
    if pkeys[k]: return
    return keys[k]

def updateKeys():
    for k in range(0, NUM_KEYS):
        pkeys[k] = keys[k]

#key events
def keyDown(e):
    global LEFT, RIGHT, UP, DOWN, ENTER, ESCAPE
    if e.keysym == "Left": setKey(LEFT, True)
    if e.keysym == "Right": setKey(RIGHT, True)
    if e.keysym == "Up": setKey(UP, True)
    if e.keysym == "Down": setKey(DOWN, True)
    if e.keysym == "Return": setKey(ENTER, True)
    if e.keysym == "Escape": setKey(ESCAPE, True)
    if e.keysym == "F2": setKey(F2, True)

def keyUp(e):
    global LEFT, RIGHT, UP, DOWN, ENTER, ESCAPE
    if e.keysym == "Left": setKey(LEFT, False)
    if e.keysym == "Right": setKey(RIGHT, False)
    if e.keysym == "Up": setKey(UP, False)
    if e.keysym == "Down": setKey(DOWN, False)
    if e.keysym == "Return": setKey(ENTER, False)
    if e.keysym == "Escape": setKey(ESCAPE, False)
    if e.keysym == "F2": setKey(F2, False)

#mouse events
def mouseDown(e):
    global mouseClicked
    mouseClicked = True

def mouseUp(e):
    global mouseClicked
    mouseClicked = False

def mouseMotion(e):
    global mousex, mousey
    mousex = e.x
    mousey = e.y
    
root.after(100, run)
root.resizable(False, False)
root.bind("<Key>", keyDown)
root.bind("<KeyRelease>", keyUp)
root.bind("<Motion>", mouseMotion)
root.bind("<Button-1>", mouseDown)
root.bind("<ButtonRelease-1>", mouseUp)
root.title("177147")
