
#Imports
from tkinter import *
from math import *
from time import *
from random import *

#Canvas
master = Tk()
screen = Canvas( master, width = 800, height = 800, background = "black")
screen.pack()

#Import .gif Photo Files
UFOImageFile = PhotoImage(file = "UFO.gif")
Walking_SoldierImageFile = PhotoImage(file = "Walking.gif")
WalkingBack_SoldierImageFile = PhotoImage(file = "WalkingBack.gif")
Shooting_SoldierImageFile = PhotoImage(file = "Shooting.gif")
flashImageFile = PhotoImage(file = "flash.gif")
grassImageFile = PhotoImage(file = "grass.gif")
BoomImageFile = PhotoImage(file = "Boom.gif")

#Ground
screen.create_rectangle(0,400,800,800,fill="#006B24")

#Crab Grass
for grassNum in range(0,27):
    xgrass = randint(0, 800)
    ygrass = randint(450, 800)
    grassImage = screen.create_image(xgrass, ygrass, image =grassImageFile )

#Stars below 320
for starNum in range(0, 400):
    
    xStar = randint(0, 800)
    yStar = randint(0, 320)
    starSize = randint(1,4)
    screen.create_oval(xStar, yStar, xStar+starSize, yStar+starSize, fill="white")

#Stars from 320 to 395 (Close to Horizon)
for starNum in range(0, 200):
    
    xStar = randint(0, 800)
    yStar = randint(320, 395)
    starSize = randint(1,3)
    screen.create_oval(xStar, yStar, xStar+starSize, yStar+starSize, fill="white")

#Variables for Moving Objects
ExplodedUFO = [PhotoImage(file = "UFO_Chunk1.gif"),
    PhotoImage(file = "UFO_Chunk2.gif"),
    PhotoImage(file = "UFO_Chunk3.gif"),
    PhotoImage(file = "UFO_Chunk4.gif"),
    PhotoImage(file = "UFO_Chunk5.gif"),
    PhotoImage(file = "UFO_Chunk6.gif"),
    PhotoImage(file = "UFO_Chunk7.gif")]
x_Explosion = []
y_Explosion = []
x_shrapnel = []
y_shrapnel = []
flightspeed = 7
walkspeed = 3
walkBackspeed = -3
xSoldier = 0
xUFO = 0
Shrapnel = []
BoomImage = 0
muzzelFlashedYet = False
UFOExplodedYet = False

#Adding Values to Shrapnel start location
for Explosion in range(0,len(ExplodedUFO)):
    x_Explosion.append(650)
    y_Explosion.append(100)
    xUFOspeed = randint(-4,10)
    yUFOspeed = randint(1,10)
    x_shrapnel.append( xUFOspeed )
    y_shrapnel.append( yUFOspeed )
    Shrapnel.append(0)
    
#UFO and Soldier
for i in range(0, 250):
    if xUFO > 650: #Deletes Ufo after its shot
        UFO = 0
#Explosion Effect
        if UFOExplodedYet == False:
            BoomImage = screen.create_image( 650, 100, image = BoomImageFile )
            UFOExplodedYet = True
            
#Shrapnel
        for k in range (0,len(ExplodedUFO)):
            Shrapnel[k] = screen.create_image(x_Explosion[k], y_Explosion[k], image = ExplodedUFO[k])
            x_Explosion[k] = x_Explosion[k] + x_shrapnel[k]
            y_Explosion[k] = y_Explosion[k] + y_shrapnel[k]
                
#Draws soldier
    else:
        xUFO = flightspeed*i - 250
        UFO = screen.create_image( xUFO, 100, image = UFOImageFile )

    if xSoldier < 200: #Delets Walking soldier at (200,600)
        xSoldier = walkspeed*i - 150
        SoldierImage = screen.create_image( xSoldier, 600, image = Walking_SoldierImageFile )
        
    else:
        SoldierImage = screen.create_image( 200 , 600, image = Shooting_SoldierImageFile )
#Draws Muzzel Flash
        if muzzelFlashedYet == False:
            flashImage = screen.create_image( 295 , 555, image = flashImageFile )
            muzzelFlashedYet = True

    screen.update()
    sleep(0.04)
    if muzzelFlashedYet == True:
        screen.delete( flashImage )
    screen.delete(UFO, SoldierImage, BoomImage )
    for k in range (0,len(ExplodedUFO)):
        screen.delete( Shrapnel[k] )
    


#Soldier Walks Away
for m in range (0,100):
    xSoldier = walkBackspeed*m + 200
    WalkingBack = screen.create_image( xSoldier, 600, image = WalkingBack_SoldierImageFile )
    screen.update()
    sleep(0.04)
    screen.delete( WalkingBack )


''' @End '''
