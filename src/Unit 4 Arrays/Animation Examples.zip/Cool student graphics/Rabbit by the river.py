#TITLE: Forest Scene
#PROGRAMMER: Madeleine Lee
#LAST MODIFIED: DECEMBER 17, 2013
#----------------------------------------------------------------------

from tkinter import *
from random import *
from time import *
from math import *
myInterface = Tk()
screen = Canvas(myInterface, width=1500, height=1500, background="sky blue")
screen.pack()

#BACKGROUND

#Mountains
Mx=-100
Mx1=300
Mx2=100
Px=50
Px1=100
Px2=150
for mountains in range(1, 10):
    #Mountain Body
    screen.create_polygon(Mx, 650, Mx1, 650, Mx2, 250, Mx, 650, fill= "grey")
    Mx=Mx+200
    Mx1=Mx1+200
    Mx2=Mx2+200
    #Snowcape
    screen.create_polygon(Px, 350, Px1, 330, Px2, 350, Px1, 250, Px, 350, fill="white")
    Px=Px+200
    Px1=Px1+200
    Px2=Px2+200
#Grass
screen.create_polygon(-150, 600, 250, 500, 550, 600, 850, 500, 1110, 600, 1500, 500, 1500, 1500, 0, 1500, -150, 600, fill= "Lawn Green", smooth = "true")

#SUN
screen.create_oval(-100, -100, 200, 200, fill="yellow")



#Trees
bottomX=700
bottomY=700
bottomX2=900
sideX=850
sideY=650
sideY2=250
sideX2=750
for trees in range(1, 7):
    #Trunks
    screen.create_polygon(bottomX, bottomY, bottomX2, bottomY, sideX, sideY, sideX, sideY2, sideX2, sideY2, sideX2, sideY, bottomX, bottomY, fill = "Saddle Brown", outline = "black")
    bottomX=bottomX+130
    bottomX2=bottomX2+130
    sideX=sideX+130
    sideX2=sideX2+130
    #Leaves
    for leaves in range(1, 50):
        leaveBundleWidth=150
        lx1=randint(650, 1500)
        ly1=randint(100, 300)
        lx2=lx1+leaveBundleWidth
        ly2=ly1+leaveBundleWidth
        screen.create_oval(lx1, ly1, lx2, ly2, fill= "Forest Green", outline="Forest Green",)
        #APPLES
        for apples in range (1, 4):
            appleWidth=leaveBundleWidth/5
            ax1=randint(675, 1475)
            ay1=randint(125, 400)
            ax2=ax1+appleWidth
            ay2=ay1+appleWidth
            screen.create_oval(ax1, ay1, ax2, ay2, fill="red")

#River
screen.create_polygon(-100, 650, 100, 800, 200, 775, 300, 775, 400, 850, 450, 875, 600, 875, 700, 900, 800, 900, 900, 950, 1000, 900, 1100, 1100, 1200, 900, 1500, 1500, 1500, 900, 1200, 850, 1100, 800, 1000, 800, 900, 800, 800, 800, 700, 740, 600, 725, 450, 675, 400, 675, 300, 625, 200, 600, 100, 650, 100, 650, fill="Medium Turquoise", outline="black", smooth="true")

#MINI HOUSE

#PARAMETERS
roofWidth=200
roofHeight=roofWidth/3

doorWidth=80
doorHeight=100

houseWidth=200
houseHeight=200

signWidth=150
signHeight=40

#CALCULATED VALUES
hX1=1000
hY1=550
hX2=hX1+houseWidth
hY2=hY1+houseWidth

rX1=hX1
rY1=hY1
rX2=rX1+roofWidth
rY2=rY1
rX3=rX2-(roofWidth/4)
rY3=rY1-roofHeight
rX4=rX1+(roofWidth/4)
rY4=rY3

dX1=hX1+10
dY1=hY2
dX2=dX1+doorWidth
dY2=dY1
dX3=dX2
dY3=dY2-doorHeight
dX4=dX3-(doorWidth/3)
dY4=dY2-doorHeight
dX5=dX4-(doorWidth/3)
dY5=dY4
dX6=dX1
dY6=dY3

tx=hX1+(5*(houseWidth/8))
ty=hY1+(houseHeight/4)

sX1=tx-(signWidth/2)
sY1=ty-(signHeight/2)
sX2=sX1+signWidth
sY2=sY1+signHeight

#DRAWING
screen.create_rectangle(hX1, hY1, hX2, hY2, fill = "orange")
screen.create_polygon(rX1, rY1, rX2, rY2, rX3, rY3, rX4, rY4, rX1, rY1, fill="blue")
screen.create_polygon(dX1, dY1, dX2, dY2, dX3, dY3, dX4, dY4, dX5, dY5, dX6, dY6, dX1, dY1, fill="black", )
screen.create_rectangle(sX1, sY1, sX2, sY2, fill="purple")
screen.create_text(tx, ty, text="Mr. R. Rabbit", font="Times 16 bold")

##BOAT
##Parameters
t=0

boatWidth=100
boatHeight=40
lineHeight=70

for framecount in range(1, 950):

        
#Calculated Values


#BODY OF THE BOAT
    boatx1=(framecount*1.5)
    boatx2=boatx1+(boatWidth/4)
    boatx3=boatx1+2*(boatWidth/4)
    boatx4=boatx1+3*(boatWidth/4)
    boatx5=boatx1+boatWidth   
    boaty1=650+(framecount*.3)
    boaty2=boaty1+3*(boatHeight/4)
    boaty3=boaty1+boatHeight
    boaty4=boaty2
    boaty5=boaty1

#SAIL
    sailWidth=boatWidth
    sailHeight=boatHeight
    sailx1=boatx1+(boatWidth/2)
    saily1=boaty1-lineHeight
    sailx2=sailx1+sailWidth
    saily2=saily1+sailHeight

#MAST
    linex1=boatx1+(boatWidth/2)
    linex2=linex1
    liney1=boaty1-lineHeight
    liney2=liney1+lineHeight


#TEXT
    textX=sailx1+(sailWidth/2)
    textY=saily1+(sailHeight/2)

#Drawing
    boat=screen.create_polygon(boatx1, boaty1, boatx2, boaty2, boatx3, boaty3, boatx4, boaty4, boatx5, boaty5, fill="Purple", smooth="true", outline="black")
    sail=screen.create_rectangle(sailx1, saily1, sailx2, saily2, fill="Red")
    line=screen.create_line(linex1, liney1, linex2, liney2, width="5")
    text=screen.create_text(textX, textY, text="S.S. Lee", font ="Times 20 italic")
    screen.update()
    sleep(0.005)
    screen.delete(boat, sail, line, text)


##Bunny an BIRDS
##PARAMETERS

birdWing=8
WingAngle=5
birdxDistance=12
birdyDistance=5

bunnyXstart=-100
bunnyYstart=800
bunnyXspeed=6
bunnyYspeed=-10

bodyWidth=60

headWidth=40

tailWidth=10

feetWidth=14
feetHeight=12

earWidth=5
earHeight=20
earDistance=10

eyeWidth=10
pupilWidth=eyeWidth/3

noseWidth=5

t=0


##CALCULATED VALUES
for bunnyBird in range(1, 250):

    #Bird 1
    B1pointaX= (bunnyBird*5)
    B1pointaY= randint(5, 10)
    B1pointbX= B1pointaX+birdWing
    B1pointbY= B1pointaY+(WingAngle/2)
    B1pointcX= B1pointaX
    B1pointcY= B1pointaY+WingAngle

    #Bird 2
    B2pointaX= B1pointaX+birdxDistance
    B2pointaY= B1pointaY+birdyDistance
    B2pointbX= B1pointbX+birdxDistance
    B2pointbY= B1pointbY+birdyDistance
    B2pointcX= B1pointcX+birdxDistance
    B2pointcY= B1pointcY+birdyDistance

    #Bird 3
    B3pointaX= B2pointaX+birdxDistance
    B3pointaY= B2pointaY+birdyDistance
    B3pointbX= B2pointbX+birdxDistance
    B3pointbY= B2pointbY+birdyDistance
    B3pointcX= B2pointcX+birdxDistance
    B3pointcY= B2pointcY+birdyDistance

    #Bird 4
    B4pointaX= B3pointaX+birdxDistance
    B4pointaY= B3pointaY+birdyDistance
    B4pointbX= B3pointbX+birdxDistance
    B4pointbY= B3pointbY+birdyDistance
    B4pointcX= B3pointcX+birdxDistance
    B4pointcY= B3pointcY+birdyDistance

    #Bird 5
    B5pointaX= B4pointaX+birdxDistance
    B5pointaY= B4pointaY+birdyDistance
    B5pointbX= B4pointbX+birdxDistance
    B5pointbY= B4pointbY+birdyDistance
    B5pointcX= B4pointcX+birdxDistance
    B5pointcY= B4pointcY+birdyDistance

    #Bird 6
    B6pointaX= B5pointaX+birdxDistance
    B6pointaY= B5pointaY+birdyDistance
    B6pointbX= B5pointbX+birdxDistance
    B6pointbY= B5pointbY+birdyDistance
    B6pointcX= B5pointcX+birdxDistance
    B6pointcY= B5pointcY+birdyDistance

    #Bird 7
    B7pointaX= B6pointaX-birdxDistance
    B7pointaY= B6pointaY+birdyDistance
    B7pointbX= B6pointbX-birdxDistance
    B7pointbY= B6pointbY+birdyDistance
    B7pointcX= B6pointcX-birdxDistance
    B7pointcY= B6pointcY+birdyDistance

    #Bird 8
    B8pointaX= B7pointaX-birdxDistance
    B8pointaY= B7pointaY+birdyDistance
    B8pointbX= B7pointbX-birdxDistance
    B8pointbY= B7pointbY+birdyDistance
    B8pointcX= B7pointcX-birdxDistance
    B8pointcY= B7pointcY+birdyDistance

    #Bird 9
    B9pointaX= B8pointaX-birdxDistance
    B9pointaY= B8pointaY+birdyDistance
    B9pointbX= B8pointbX-birdxDistance
    B9pointbY= B8pointbY+birdyDistance
    B9pointcX= B8pointcX-birdxDistance
    B9pointcY= B8pointcY+birdyDistance
    
    #Bird 10
    B10pointaX= B9pointaX-birdxDistance
    B10pointaY= B9pointaY+birdyDistance
    B10pointbX= B9pointbX-birdxDistance
    B10pointbY= B9pointbY+birdyDistance
    B10pointcX= B9pointcX-birdxDistance
    B10pointcY= B9pointcY+birdyDistance

    
    t=t+1
#BODY   
    bodyHeight=bodyWidth/1.5
    bBodyX1=bunnyXspeed*bunnyBird+bunnyXstart
    bBodyY1=.5*t**2+bunnyYspeed*t+bunnyYstart
    bBodyX2=bBodyX1+bodyWidth
    bBodyY2=bBodyY1+bodyHeight
#Head

    headX1=bBodyX1+bodyWidth-(headWidth/2)
    headX2=bBodyX2+(headWidth/2)
    headY1=bBodyY1-headWidth+10
    headY2=bBodyY1+10

#Tail
    tailX1=bBodyX1-(tailWidth*1.5)
    tailX2=bBodyX2-bodyWidth
    tailY1=bBodyY1+13
    tailY2=bBodyY2-13

#Feet
    footaX1=bBodyX1+5
    footaX2=bBodyX1+(feetWidth+5)
    footaY1=bBodyY2-5
    footaY2=bBodyY2+(feetHeight-5)
    footbX1=bBodyX2-(feetWidth+5)
    footbX2=bBodyX2-5
    footbY1=bBodyY2-5
    footbY2=bBodyY2+(feetHeight-5)

#Ear
    earaX1=headX1+(headWidth/4)
    earaX2=headX1+(2*(headWidth/4))
    earaY1=headY1-earHeight
    earaY2=headY1+2
    earbX1=earaX1+earDistance
    earbX2=earaX2+earDistance
    earbY1=earaY1
    earbY2=earaY2

#Eye
    eyeX1=earbX1
    eyeX2=earbX1+eyeWidth
    eyeY1=headY1+5
    eyeY2=eyeY1+eyeWidth
    pupilX1=eyeX1+(2*(eyeWidth/3))
    pupilX2=eyeX2
    pupilY1=eyeY1+(eyeWidth/3)
    pupilY2=pupilY1+pupilWidth

#Nose
    noseX1=eyeX2+noseWidth
    noseX2=headX2
    noseY1=eyeY2+4
    noseY2=noseY1+noseWidth


##DRAWING
    if bBodyY2>bunnyYstart+bodyWidth:
        
        t=0

#BUNNY
        bunnyYstart=bBodyY1                

        body=screen.create_oval(bBodyX1, bBodyY1, bBodyX2, bBodyY2, fill="Tan", )

        head=screen.create_oval(headX1, headY1, headX2, headY2, fill="Tan", )

        tail=screen.create_oval(tailX1, tailY1, tailX2, tailY2, fill="white", )

        foot1=screen.create_oval(footaX1, footaY1, footaX2, footaY2, fill="Tan", ) 
        foot2=screen.create_oval(footbX1, footbY1, footbX2, footbY2, fill="Tan", )

        ear1=screen.create_oval(earaX1, earaY1, earaX2, earaY2, fill="Tan", )
        ear2=screen.create_oval(earbX1, earbY1, earbX2, earbY2, fill="Tan", )

        eye=screen.create_oval(eyeX1, eyeY1, eyeX2, eyeY2, fill="white")
        pupil=screen.create_oval(pupilX1, pupilY1, pupilX2, pupilY2, fill="black")

        nose=screen.create_oval(noseX1, noseY1, noseX2, noseY2, fill="pink")

#BIRDS
        b1=screen.create_line(B1pointaX, B1pointaY, B1pointbX, B1pointbY, B1pointcX, B1pointcY, width="2")
        b2=screen.create_line(B2pointaX, B2pointaY, B2pointbX, B2pointbY, B2pointcX, B2pointcY, width="2")
        b3=screen.create_line(B3pointaX, B3pointaY, B3pointbX, B3pointbY, B3pointcX, B3pointcY, width="2")
        b4=screen.create_line(B4pointaX, B4pointaY, B4pointbX, B4pointbY, B4pointcX, B4pointcY, width="2")
        b5=screen.create_line(B5pointaX, B5pointaY, B5pointbX, B5pointbY, B5pointcX, B5pointcY, width="2")
        b6=screen.create_line(B6pointaX, B6pointaY, B6pointbX, B6pointbY, B6pointcX, B6pointcY, width="2")
        b7=screen.create_line(B7pointaX, B7pointaY, B7pointbX, B7pointbY, B7pointcX, B7pointcY, width="2")
        b8=screen.create_line(B8pointaX, B8pointaY, B8pointbX, B8pointbY, B8pointcX, B8pointcY, width="2")
        b9=screen.create_line(B9pointaX, B9pointaY, B9pointbX, B9pointbY, B9pointcX, B9pointcY, width="2")
        b10=screen.create_line(B10pointaX, B10pointaY, B10pointbX, B10pointbY, B10pointcX, B10pointcY, width="2") 

        screen.update()
        sleep(0.005)
        screen.delete(body, head, tail, foot1, foot2, ear1, ear2, eye, pupil, nose, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10)

#BIRDS
    b1=screen.create_line(B1pointaX, B1pointaY, B1pointbX, B1pointbY, B1pointcX, B1pointcY, width="2")
    b2=screen.create_line(B2pointaX, B2pointaY, B2pointbX, B2pointbY, B2pointcX, B2pointcY, width="2")
    b3=screen.create_line(B3pointaX, B3pointaY, B3pointbX, B3pointbY, B3pointcX, B3pointcY, width="2")
    b4=screen.create_line(B4pointaX, B4pointaY, B4pointbX, B4pointbY, B4pointcX, B4pointcY, width="2")
    b5=screen.create_line(B5pointaX, B5pointaY, B5pointbX, B5pointbY, B5pointcX, B5pointcY, width="2")
    b6=screen.create_line(B6pointaX, B6pointaY, B6pointbX, B6pointbY, B6pointcX, B6pointcY, width="2")
    b7=screen.create_line(B7pointaX, B7pointaY, B7pointbX, B7pointbY, B7pointcX, B7pointcY, width="2")
    b8=screen.create_line(B8pointaX, B8pointaY, B8pointbX, B8pointbY, B8pointcX, B8pointcY, width="2")
    b9=screen.create_line(B9pointaX, B9pointaY, B9pointbX, B9pointbY, B9pointcX, B9pointcY, width="2")
    b10=screen.create_line(B10pointaX, B10pointaY, B10pointbX, B10pointbY, B10pointcX, B10pointcY, width="2")        

#BUNNY
    body=screen.create_oval(bBodyX1, bBodyY1, bBodyX2, bBodyY2, fill="Tan", )

    head=screen.create_oval(headX1, headY1, headX2, headY2, fill="Tan", )

    tail=screen.create_oval(tailX1, tailY1, tailX2, tailY2, fill="white", outline="black")

    foot1=screen.create_oval(footaX1, footaY1, footaX2, footaY2, fill="Tan", ) 
    foot2=screen.create_oval(footbX1, footbY1, footbX2, footbY2, fill="Tan", )

    ear1=screen.create_oval(earaX1, earaY1, earaX2, earaY2, fill="Tan", )
    ear2=screen.create_oval(earbX1, earbY1, earbX2, earbY2, fill="Tan", )

    eye=screen.create_oval(eyeX1, eyeY1, eyeX2, eyeY2, fill="white")
    pupil=screen.create_oval(pupilX1, pupilY1, pupilX2, pupilY2, fill="black")

    nose=screen.create_oval(noseX1, noseY1, noseX2, noseY2, fill="pink")

    screen.update()
    sleep(0.05)
    screen.delete(body, head, tail, foot1, foot2, ear1, ear2, eye, pupil, nose, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10)



#APPLE DROP

#PARAMETERS
appleStartX = 725
appleStartY = 500
appleSpeedX = 0
appleSpeedY = -20
ground=710
appleWidth = 40
t = 0

for frameCount in range(0,70):

    #CALCULATED VALUES
    t = t + 1
    x1apple = appleSpeedX * frameCount + appleStartX
    y1apple = 7*t**2 + appleSpeedY * t + appleStartY
    
    x2apple = x1apple + appleWidth
    y2apple = y1apple + appleWidth
    appleSpeedY = appleSpeedY + 0.5
    appleSpeedX = appleSpeedX + 0.4

    if y2apple > ground + appleWidth:
       t = 0
       appleStartY = y1apple

    #DRAWING
    apple = screen.create_oval(  x1apple,  y1apple,  x2apple,  y2apple,  fill="red",  outline="black")


    screen.update()
    sleep(0.05)
    screen.delete(apple)

#BUNNY COMES BACK

#PARAMETERS
bunnyXstart=1300
bunnyYstart=700
bunnyXspeed=-6
bunnyYspeed=-10

bodyWidth=60

headWidth=40

tailWidth=15

feetWidth=14
feetHeight=12

earWidth=10
earHeight=20
earDistance=10

eyeWidth=10
pupilWidth=eyeWidth/3

noseWidth=5

t=0
for bunny in range(1, 42):

#CALCULATED VALUES
    t=t+1
    bodyHeight=bodyWidth/1.5
    bBodyX1=bunnyXspeed*bunny+bunnyXstart
    bBodyY1=.5*t**2+bunnyYspeed*t+bunnyYstart
    bBodyX2=bBodyX1+bodyWidth
    bBodyY2=bBodyY1+bodyHeight
#Head

    headX1=bBodyX1-20
    headX2=bBodyX1+(headWidth/2)
    headY1=bBodyY1-headWidth+10
    headY2=bBodyY1+10

#Tail
    tailX1=bBodyX2-3
    tailX2=tailX1+tailWidth
    tailY1=bBodyY1+13
    tailY2=bBodyY2-13

#Feet
    footaX1=bBodyX1+5
    footaX2=bBodyX1+(feetWidth+5)
    footaY1=bBodyY2-5
    footaY2=bBodyY2+(feetHeight-5)
    footbX1=bBodyX2-(feetWidth+5)
    footbX2=bBodyX2-5
    footbY1=bBodyY2-5
    footbY2=bBodyY2+(feetHeight-5)

#Ear
    earaX1=headX1+(headWidth/4)-5
    earaX2=earaX1+earWidth
    earaY1=headY1-earHeight
    earaY2=headY1+2
    earbX1=earaX1+earDistance
    earbX2=earaX2+earDistance
    earbY1=earaY1
    earbY2=earaY2

#Eye
    eyeX1=headX1+4
    eyeX2=eyeX1+eyeWidth
    eyeY1=headY1+10
    eyeY2=eyeY1+eyeWidth
    
    pupilX1=eyeX1
    pupilX2=pupilX1+pupilWidth
    pupilY1=eyeY1+(eyeWidth/3)
    pupilY2=pupilY1+pupilWidth

#Nose
    noseX1=eyeX1
    noseX2=noseX1+noseWidth
    noseY1=eyeY2+4
    noseY2=noseY1+noseWidth


##DRAWING
    if bBodyY2>bunnyYstart+bodyWidth:
        
        t=0

        bunnyYstart=bBodyY1                

        body=screen.create_oval(bBodyX1, bBodyY1, bBodyX2, bBodyY2, fill="Tan", )

        head=screen.create_oval(headX1, headY1, headX2, headY2, fill="Tan", )

        tail=screen.create_oval(tailX1, tailY1, tailX2, tailY2, fill="white", )

        foot1=screen.create_oval(footaX1, footaY1, footaX2, footaY2, fill="Tan", ) 
        foot2=screen.create_oval(footbX1, footbY1, footbX2, footbY2, fill="Tan", )

        ear1=screen.create_oval(earaX1, earaY1, earaX2, earaY2, fill="Tan", )
        ear2=screen.create_oval(earbX1, earbY1, earbX2, earbY2, fill="Tan", )

        eye=screen.create_oval(eyeX1, eyeY1, eyeX2, eyeY2, fill="white")
        pupil=screen.create_oval(pupilX1, pupilY1, pupilX2, pupilY2, fill="black")

        nose=screen.create_oval(noseX1, noseY1, noseX2, noseY2, fill="pink")

        screen.update()
        sleep(0.05)
        screen.delete(body, head, tail, foot1, foot2, ear1, ear2, eye, pupil, nose)



    body=screen.create_oval(bBodyX1, bBodyY1, bBodyX2, bBodyY2, fill="Tan", )

    head=screen.create_oval(headX1, headY1, headX2, headY2, fill="Tan", )

    tail=screen.create_oval(tailX1, tailY1, tailX2, tailY2, fill="white", outline="black")

    foot1=screen.create_oval(footaX1, footaY1, footaX2, footaY2, fill="Tan", ) 
    foot2=screen.create_oval(footbX1, footbY1, footbX2, footbY2, fill="Tan", )

    ear1=screen.create_oval(earaX1, earaY1, earaX2, earaY2, fill="Tan", )
    ear2=screen.create_oval(earbX1, earbY1, earbX2, earbY2, fill="Tan", )

    eye=screen.create_oval(eyeX1, eyeY1, eyeX2, eyeY2, fill="white")
    pupil=screen.create_oval(pupilX1, pupilY1, pupilX2, pupilY2, fill="black")

    nose=screen.create_oval(noseX1, noseY1, noseX2, noseY2, fill="pink")

    screen.update()
    sleep(0.05)
    screen.delete(body, head, tail, foot1, foot2, ear1, ear2, eye, pupil, nose)

sleep(1)


#WIND

#PARAMETERS
windWidth=250
windHeight=100
windxStart=-100
windyStart=350
for wind in range (1, 75):

    #CALCULATED VALUES
    wx1=windxStart+(wind*7)
    wx2=wx1+(4*(windWidth/5))
    wx3=wx2+(windWidth/5)
    wx4=wx3
    wx5=wx3
    wx6=wx1+(3*(windWidth/5))
    wx7=wx6
    wx8=wx2
    wx9=wx1+(9*(windWidth/10))
    wx10=wx9
    wx11=wx2
    wx12=wx1+(7*(windWidth/10))
    wx13=wx2
    
    wy1=(windyStart)
    wy2=wy1
    wy3=wy2-(windHeight/4)
    wy4=wy2-(3*(windHeight/4))
    wy5=wy1-windHeight
    wy6=wy4
    wy7=wy1-(windHeight/2)
    wy8=wy3
    wy9=wy7
    wy10=wy4
    wy11=wy10-10
    wy12=wy6+10
    wy13=wy12+10

    #DRAWING
    windBlow=screen.create_line(wx1, wy1, wx2, wy2, wx3, wy3, wx4, wy4, wx5, wy5, wx6, wy6, wx7, wy7, wx8, wy8, wx9, wy9, wx10, wy10, wx11, wy11, wx12, wy12, wx13, wy13, fill="black", smooth="true", width=3)
    screen.update()
    sleep(0.05)
    screen.delete(windBlow)



#LEAVES BLOWING IN THE WIND

#PARAMETERS
xstart=600
ystart=300
size=65
xspeed=30
yspeed=60
leaveWidth=70
leaveHeight=leaveWidth/2.5
leaveDistance=leaveWidth + 50
t=0

for frameCount in range(0,500):

    #CALCULATED VALUES

    #Leave 1
    x1 = xstart + (4*frameCount)
    y1 = ystart + 50*sin( .06*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave1=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")

    #Leave 2
    x1 = xstart + leaveDistance + (6*frameCount)
    y1 = ystart + 50*cos( .05*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave2=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 3
    x1 = x1 + leaveDistance + (4*frameCount)
    y1 = ystart + 50*sin( .06*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave3=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    
   
    #Leave 4
    x1 = x1 + leaveDistance + (6*frameCount)
    y1 = ystart + 50*cos( .05*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave4=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 5
    x1 = x1 + leaveDistance + (4*frameCount)
    y1 = ystart + 50*sin( .06*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave5=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 6   
    x1 = x1 + leaveDistance + (6*frameCount)
    y1 = ystart + 50*cos( .05*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave6=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 7
    x1 = x1 + leaveDistance + (4*frameCount)
    y1 = ystart + 50*sin( .06*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave7=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 8  
    x1 = x1 + leaveDistance + (6*frameCount)
    y1 = ystart + 50*cos( .05*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave8=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    

    #Leave 9
    x1 = x1 + leaveDistance + (4*frameCount)
    y1 = ystart + 50*sin( .06*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave9=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="Black", smooth="true")
   

    #Leave 10   
    x1 = x1 + leaveDistance + (6*frameCount)
    y1 = ystart + 50*cos( .05*frameCount )
    x2 = x1 + (leaveWidth/3)
    y2 = y1 + (leaveHeight/2)
    x3 = x2 + (leaveWidth/3)
    y3 = y2
    x4 = x1 + leaveWidth
    y4 = y1
    x5 = x3
    y5 = y1 - (leaveHeight/2)
    x6 = x2
    y6 = y5
    leave10=screen.create_polygon(x1,y1,x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x1, y1, fill="Forest Green", outline="black", smooth="true")
    
    screen.update()
    sleep(0.05)
    screen.delete(leave1, leave2, leave3, leave4, leave5, leave6, leave7, leave8, leave9, leave10)


##THE END











    
    
    
