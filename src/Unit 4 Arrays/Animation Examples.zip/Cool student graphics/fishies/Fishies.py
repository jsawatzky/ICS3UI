# Title:  Under the sea
# Programmer:  Samatar Abukar
# Last modified:  14/4/2014
# Purpose: This program has a number of fish under the ocean swimming
#  calmly but are then confronted with a shark and react accordingly.
#  The fish turn around and swim rapidly away. 
############################################################################
from tkinter import *
from math import *
from time import *
from random import *

master = Tk()
screen = Canvas( master, width = 800, height = 800)
screen.pack()
Sea = PhotoImage(file = "SEA.gif")
screen.create_image(600,400, image = Sea)
shark = PhotoImage (file = "shark copy.gif")

Frames = 250

numfish = 100

numBubbles = 100

size = []
bubblesize = []
BubX = []
BubY= []
x = []
y = []
xSpeed = []
fish = []

#Give the speed for the shark to move
swimspeed = 10
colors = ["red", "lightblue", "green", "violet", "orange"]

#Create random bubbles in the animation at random points
for i in range (0,numBubbles):
    xBub = randint(0, 800)
    yBub = randint(0, 800)
    BubSize = randint(10,20)
    
    screen.create_oval(xBub, yBub, xBub+BubSize, yBub+BubSize, outline="lightblue")

#Give the fish random sizes and places on canvas as well as assigns them given x speeds
for i in range(0,numfish):
    newSize = randint(15,20)
    newX = randint(650,700)
    newY = randint(100,700)
    newXspeed = randint(-5,-3)

    size.append( newSize )
    x.append( newX )
    y.append( newY )
    xSpeed.append( newXspeed )
    fish.append ( [0,0,0,0] )


#Loop animation until all frames have been accounted for    
for frameCount in range( 1, Frames + 1 ):
    
    #Creating the fish and giving them their speesd and colours 
    for i in range(0,numfish):
        
        #When frame count is below 45, the fish are swimming slowly to the left
        if frameCount < 40:                                                                                                                                                                                                                                                                                                     
            x[i] = x[i] + xSpeed[i]
            y[i] = y[i]
            color = colors[i%len(colors)]
            
            fish[i][0]= screen.create_oval( x[i], y[i], x[i] +size[i]+20, y[i] +size[i], fill = color )
            fish[i][1]= screen.create_polygon(x[i]+size[i]+20,(2*y[i] + size[i])/2,x[i]+size[i]+30, y[i], x[i]+size[i]+30, y[i]+size[i], outline = "black", fill= color)
            fish[i][2]= screen.create_oval( x[i]+size[i]-10, y[i]+size[i]-13, x[i]+size[i]-2, y[i]+size[i]-5, fill = "white")
            fish[i][3]= screen.create_oval( x[i]+size[i]-8, y[i]+size[i]-11, x[i]+size[i]-4, y[i]+size[i]-7, fill = "black")

        #When frame count exceeds 45, the fish turn around and rapidly swim away after seeing the shark
        else:
            color = colors[i%len(colors)]
            xSpeed = 18
            x[i] = x[i] + xSpeed
            y[i] = y[i]
            fish[i][1]= screen.create_polygon(x[i]-size[i]+20,(2*y[i] + size[i])/2,x[i]+size[i]-30, y[i], x[i]+size[i]-30, y[i]+size[i], outline = "black", fill=color)
            fish[i][0]= screen.create_oval( x[i], y[i], x[i] +size[i]+20, y[i] +size[i], fill = color)
            fish[i][2]= screen.create_oval( x[i]+size[i]+10, y[i]+size[i]-13, x[i]+size[i]+2, y[i]+size[i]-5, fill = "white")
            fish[i][3]= screen.create_oval( x[i]+size[i]+8, y[i]+size[i]-11, x[i]+size[i]+4, y[i]+size[i]-7, fill = "black")

    #Shark is placed off screen and moves quickly to the right and comes into view when framecount = 40
    xshark = swimspeed*frameCount - 600
    Shark = screen.create_image( xshark, 300,image = shark )
    screen.update()  
    sleep(0.02)
    screen.delete(Shark)

    
    #Delete the previous fish after the next is created give the illusion it is moving
    for i in range(0,numfish):
        screen.delete( fish[i][0])
        screen.delete( fish[i][1])
        screen.delete( fish[i][2])
        screen.delete( fish[i][3])





