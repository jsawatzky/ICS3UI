from tkinter import *
from time import *
from math import *
from random import *


#made it a couple assignments ago, adds ending to a number ie: 1 become 1st
def addending(number): 
    if 11<=int(number)<=20: 
        ending="th"
    else: 
        if number.endswith("1"): 
            ending = "st"
        elif number.endswith("2"): 
            ending="nd"
        elif number.endswith("3"): 
            ending="rd"
        else: 
            ending = "th"
    return (number+ending) 

#function will return a shout with a smaller index in cheering more often than that with a larger index
def randomShout():
    for i in range(2, len(cheering)+2):
        x=randint(1, i)
        if x==1:
            break
    shout=cheering[i-2]
    return (shout)



#set up variables
dimension=800
numLaps=5
crashLikelyhood=30
scoreSize=30
carSpeed=5
numCars=10
numSpectators=100
headsize=15
bleacherRows=8
cheering=["YAY!","*applause*", "BOOOOO!", "*whistles*!", "I DATED THE DRIVER IN GRADE 11!", "SOO CALLED IT!", "NOOOO!", "THAT'S MY SON!!!!",  "YAY! I WON 10 GRAND!!!", "NOOO! I BET MY LIFE SAVINGS!"]
numShouts=10

#draw canvas
tk = Tk()
me = Canvas(tk, width=dimension,height=dimension+200,background="black")
me.pack()

#Don't change anything here
scoreSpacing=((dimension/numCars)-scoreSize)/2
bluecar=PhotoImage(file="bluecar.gif")
greencar=PhotoImage(file="greencar.gif")
redcar=PhotoImage(file="redcar.gif")
yellowcar=PhotoImage(file="yellowcar.gif")
orangecar=PhotoImage(file="orangecar.gif")
purplecar=PhotoImage(file="purplecar.gif")

fire=PhotoImage(file="fire.gif")
colorChoices=[bluecar, redcar, yellowcar, greencar, orangecar, purplecar]

#Set up arrays
cars=[]
xSpeeds=[]
carLaps=[]
displayLaps=[]
xPos=[]
yPos=[]
topBorder=[]
carColor=[]
draw=[]

suiciders=[]
direction=[0, 0] #will be popped later
crashLap=[]

dead=[]
finishline=[]
winners=[]
failures=[]

shouts=[]

#set each car's variables
prevcrash="f"
for i in range (0, numCars):
    cars.append(i)
    xSpeeds.append(carSpeed)
    carLaps.append(0)
    displayLaps.append(0)
    xPos.append(-40)
    topBorder.append(int(dimension/numCars)*i+200)
    carColor.append(colorChoices[randint(0, len(colorChoices)-1)])
    draw.append(1)
    yPos.append(int(topBorder[i]+(dimension/(numCars*2))))
    dead.append(0)
    finishline.append(0)
    a=randint(1, 100)
    
#set crashing variable based on generator, car number, and previous car info. 
    if a<crashLikelyhood and i!=numCars-1 and prevcrash=="f":
        suiciders.append(1)
        prevcrash="t"
        #car will crash down if it's the upmost car
        if i==0 or direction[-2]==1:
            direction.append(1)
        #car will crash up if it's the downmost car
        elif i==numCars-2:
            direction.append(-1)
        #generate direction, up or down if car is in the middle   
        else:
            direction.append(choice([-1, 1]))
            
        #cars will only crash if it has enough time to complete the crash
        if numLaps<2:
            crashLap.append(500)
        else:
            crashLap.append(randint(0, numLaps-2))
    #conditions make it so car does not crash        
    else:
        prevcrash="f"
        suiciders.append(0)
        direction.append(0)
        crashLap.append("x")
        
#removes variables previously written
direction.pop(0)
direction.pop(0)



#Draw Racetrack, scoreboard, cars
for i in range (0, numCars):
    me.create_line(0, topBorder[i], dimension, topBorder[i],  fill="white")
    me.create_rectangle(dimension-scoreSize-scoreSpacing, topBorder[i]+scoreSpacing, dimension-scoreSpacing, topBorder[i]+scoreSize+scoreSpacing, fill="red" )
    displayLaps[i]=me.create_text(dimension-scoreSize/2-scoreSpacing, topBorder[i]+scoreSize/2+scoreSpacing, text=carLaps[i], font="times 25 bold" )
    cars[i]=me.create_image(xPos[i], yPos[i], image=carColor[i])

#draw bleachers
me.create_rectangle(0, 0, dimension, 200, fill="grey")
rowSize=200/bleacherRows
for i in range(0, bleacherRows):
    me.create_line(0, i*rowSize, dimension, i*rowSize, fill="white")
    
#Draw crowd
for i in range(0, numSpectators):
    audienceRow=randint(0, bleacherRows)
    xHead=randint(0, dimension-headsize)
    me.create_oval(xHead, audienceRow*rowSize-headsize, xHead+headsize, audienceRow*rowSize, fill="white")

#let the crowd shout at the end of the show
for i in range(0, numShouts):
    shouts.append(0)

#animations
#each while loop is 1 frame
while True:
    
    #do this for every car in each frame
    for i in range (0, numCars):
        
        #delete previous car
        if draw[i]==1:
            me.delete(cars[i], displayLaps[i])
        
        #move car right x pixiels if it's supposed to
        if xSpeeds[i]!= 0:
            #xPos[i]=xPos[i]+xSpeeds[i]
            xPos[i]=xPos[i]+randint(int(xSpeeds[i]/8), xSpeeds[i]*3)

        #if car is crashing, or crashed on, make move speed constant 
        elif suiciders[i]==2 or suiciders[i]==3:
            xPos[i]=xPos[i]+xSpeeds[i]
            
        #bring car to beginning if it's at the end
        if xPos[i]>=dimension+40:
            xPos[i]=xPos[i]-dimension-80
            carLaps[i]=carLaps[i]+1
            
        #if the lap is the last lap, draw finish line
        if carLaps[i]==numLaps-1:
            finishline[i]=me.create_line(dimension-10,topBorder[i], dimension-10, topBorder[i]+(topBorder[1]-topBorder[0]), fill="yellow", width=5)
            
        #stop the car if it's past the finish line
        if (carLaps[i]==numLaps-1 and xPos[i]>dimension+30) or carLaps[i]>numLaps-1:
            if i not in winners:
                winners.append(i)
            xSpeeds[i]=0
            xPos[i]=dimension+30
            carLaps[i]=numLaps
            
        #car will shift down if: it's allowed to crash, the lap is correct or the car is already crashing, it's close(left right wise) to the car it's crashing, and it's not at the finish line
        if (suiciders[i]==2 or suiciders[i]==1) and (crashLap[i]==carLaps[i] or yPos[i]+(topBorder[1]-topBorder[0])!=yPos[i+1]) and xPos[i]-80<xPos[i+direction[i]] and xPos[i]+80>xPos[i+direction[i]] and xPos[i]!=dimension+30:
            yPos[i]=yPos[i]+direction[i]
            suiciders[i]=2 #suicider
            suiciders[i+direction[i]]=3 #suicided on

        #draw car and update displayboard
        if draw[i]==1:
            cars[i]=me.create_image(xPos[i],  yPos[i], image=carColor[i])
            displayLaps[i]=me.create_text(dimension-scoreSize/2-scoreSpacing, topBorder[i]+scoreSize/2+scoreSpacing, text=carLaps[i], font="times 25 bold")

        #if cars are very close to each other, stop the cars and draw a fire
        if direction[i]!=0 and (yPos[i]+30==yPos[i+direction[i]] or  yPos[i]-30 ==yPos[i+direction[i]]):
                suiciders[i]=0
                xPos[i+direction[i]]=xPos[i]
                xSpeeds[i]=0
                xSpeeds[i+direction[i]]=0
                me.delete(cars[i], cars[i+direction[i]])
                cars[i]=me.create_image(xPos[i],  yPos[i], image=carColor[i])
                cars[i+direction[i]]=me.create_image(xPos[i+direction[i]],  yPos[i+direction[i]], image=carColor[i+direction[i]])
                me.create_image((xPos[i]+xPos[i+direction[i]])/2, (yPos[i]+yPos[i+direction[i]])/2, image=fire)
                draw[i]=0
                draw[i+direction[i]]=0
                if i not in failures:
                    failures.extend([i, i+direction[i]])

    sleep(0.01)
    me.update()
    
    #stops the loop if all cars have stopped moving
    if max(xSpeeds)==0:
            break

#Set up the after race show

me.create_rectangle(dimension-(dimension-(dimension/10)), 100+dimension/6, dimension-(dimension/10), dimension-(dimension/12), fill="white")
#set up the losers
losers=""
for i in range(0, len(failures)):
    if i != len(failures)-1:
        losers=losers+str(failures[i]+1)+", "
    else:
        losers=losers+"and "+str(failures[i]+1)


    
banner1y=dimension/7*3
banner2y=dimension/7*4



#display losers
if losers!="":
    banner1=me.create_text(dimension/2, banner1y, text="Thanks for trying,", font="times 35 bold", fill="black")
    banner2=me.create_text(dimension/2, banner2y, text="cars "+losers, font="times 35 bold", fill="black")

    #crowd shouts some stuff, but half of what they normally do
    for i in range(0, int(numShouts/2)):
        shoutx=randint(50, dimension-50)
        shouty=randint(50, 150)
        popup=randomShout()
        shouts[i]=me.create_text(shoutx, shouty, text=popup, font="times 12 bold")
        me.update()
        sleep(0.01)
    sleep(5)
    
    #delete shouts, then banners
    for i in range(0, int(numShouts/2)):
        me.delete(shouts[i])
    me.delete(banner1, banner2)
    me.update()

#display winners individually
for i in range(min(3, len(winners))-1, -1, -1):
    #Congratulate winners, show car
    banner1=me.create_text(dimension/2, banner1y, text="Congratulations to car ", font="times 35 bold", fill="black")
    banner2=me.create_text(dimension/2, banner2y, text=str(winners[i]+1) +" on "+ addending(str(i+1)) +" place", font="times 35 bold", fill="black")
    displaycar=me.create_image(dimension/2, dimension/2+100, image=carColor[winners[i]])
    #crowd shouts some stuff
    for i in range(0, numShouts):
        shoutx=randint(50, dimension-50)
        shouty=randint(50, 150)
        popup=randomShout()
        shouts[i]=me.create_text(shoutx, shouty, text=popup, font="times 12 bold")
        me.update()
        sleep(0.01)
    sleep(5)
    #delete shouts, banners, and cars
    for i in range(0, numShouts):
        me.delete(shouts[i])
    me.delete(banner1, banner2, displaycar)
    me.update()

