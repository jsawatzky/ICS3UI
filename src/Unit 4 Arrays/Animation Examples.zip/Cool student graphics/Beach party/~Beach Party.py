####################################################################
# Program: Simple Animation of a Cartoon Beach Party
# Programmer:  Jennifer Shu
# Created on:  April 10, 2014
#####################################################################

#=======================================================
#                       Imports
#=======================================================

from tkinter import *
from time import *
import random

#=======================================================
#                   Create the Canvas
#=======================================================

root = Tk()
screen = Canvas( root, width=1000, height=530, background = "yellow" )
screen.pack()

#=======================================================
#                  Importing GIFs
#=======================================================
backgroundImage = PhotoImage(file = "Picture1.gif")
Stitch1 = PhotoImage(file = "stitch1.gif")
Stitch2 = PhotoImage(file = "stitch2.gif")
Stitch3 = PhotoImage(file = "stitch3.gif")
Stitch4 = PhotoImage(file = "stitch4.gif")
Stitch5 = PhotoImage(file = "stitch5.gif")
Stitch7 = PhotoImage(file = "stitch7.gif")
Stitch8 = PhotoImage(file = "stitch8.gif")
Stitch9 = PhotoImage(file = "stitch9.gif")
Stitch10 = PhotoImage(file = "stitch10.gif")
birdImage = PhotoImage(file = "bird.gif")
boatImage = PhotoImage(file = "boat.gif")
doraemonImage1 = PhotoImage(file = "doraemon2.gif")
minionImage1 = PhotoImage(file = "minion1.gif")
minionImage2 = PhotoImage(file = "minion2.gif")
minionImage3 = PhotoImage(file = "minion3.gif")
minionImage4 = PhotoImage(file = "minion4.gif")
tweetyImage = PhotoImage(file = "tweety.gif")
balloonImage1 = PhotoImage(file = "balloon1.gif")
balloonImage2 = PhotoImage(file = "balloon2.gif")
balloonImage3 = PhotoImage(file = "balloon3.gif")
balloonImage4 = PhotoImage(file = "balloon4.gif")
balloonImage5 = PhotoImage(file = "balloon5.gif")
balloonImage6 = PhotoImage(file = "balloon6.gif")
balloonImage7 = PhotoImage(file = "balloon7.gif")
balloonImage8 = PhotoImage(file = "balloon8.gif")
balloonImage9 = PhotoImage(file = "balloon9.gif")
balloonImage10 = PhotoImage(file = "balloon10.gif")
balloonImage11 = PhotoImage(file = "pooh.gif")
patrick1 = PhotoImage(file = "patrick1.gif")
patrick2 = PhotoImage(file = "patrick2.gif")
patrick3 = PhotoImage(file = "patrick3.gif")
patrick4 = PhotoImage(file = "patrick4.gif")
patrick5 = PhotoImage(file = "patrick5.gif")
patrick6 = PhotoImage(file = "patrick6.gif")
patrick7 = PhotoImage(file = "patrick7.gif")
patrick8 = PhotoImage(file = "patrick8.gif")
arielImage = PhotoImage(file = "ariel.gif")
bannerImage = PhotoImage(file = "banner.gif")
hballoon = PhotoImage(file = "haballoon.gif")
turtleImage = PhotoImage(file = "turtle.gif")
pikachuImage = PhotoImage(file = "pikachu.gif")


#=======================================================
#                 Creating Background
#=======================================================

#Background Image
background = screen.create_image(500,280, image = backgroundImage)

#Creating Sand by Random
sandsize = 1
for a in range(0,950):
    x = random.randint (0,1000)
    y = random.randint (460,550)
    sand = screen.create_oval(x,y,x+sandsize,y+sandsize, outline="goldenrod", fill = "goldenrod")
screen.update()

#Finding Nemo
seagull = screen.create_image(640, 450, image = birdImage)
turtle = screen.create_image(940,500, image = turtleImage)

#Hot air balloon
haballoon = screen.create_image(430,310, image = hballoon)

#Pikachu
pikachu = screen.create_image(120, 470, image = pikachuImage)

#Little Mermaid
ariel = screen.create_image(530,370, image = arielImage)

#Despicable Me:  Minions
Minions = [minionImage4, minionImage1, minionImage2, minionImage3]
minionX = [280,380,480,550]
minionY = 460
for minionNum in range (0,len(Minions)):
    screen.create_image(minionX[minionNum], minionY, image = Minions[minionNum])


#=======================================================
#           Determine Parameters for Animation
#=======================================================

#Frame number
numFrames = 6

#Balloons
balloon = [balloonImage1,balloonImage2,balloonImage3,balloonImage4,balloonImage5, balloonImage7, balloonImage8, balloonImage9,balloonImage10, balloonImage11]
numBalloons = 10

#Patrick Star
xpatrick = 780
ypatrick = 480
patrick = [patrick1, patrick2, patrick3, patrick4, patrick5, patrick6, patrick7, patrick8]

#Banner and Doraemon
xBanner = 1350
banner = screen.create_image(xBanner, 100, image = bannerImage)
doraemon = screen.create_image(xBanner-300, 100, image = doraemonImage1)

#Boat
xBoat = 150
yBoat = 350
Boat = 1
boatIncrease = 1

#Lilo and Stitch:  Stitch
xStitch = 850
yStitch = 420
Stitch = [Stitch1, Stitch2, Stitch3, Stitch4, Stitch5, Stitch7, Stitch8, Stitch9, Stitch10]

#Tweety
tweetyRange = 4
xtweety = 100
tweetyShift = 20

#Balloons
balloons = []
xballoon = []
balloonShift = 20


#=======================================================
#                       Animation
#=======================================================

for frames in range(0, numFrames):

    #Re-determined values every time the frame loop runs
    ytweety = 200
    yballoon = 560
    xballoon = []

    #Appending arrays for balloon images
    for flyingB in range(0, len(balloon)):
        xballoon1 = random.randint(180,820)
        xballoon.append(xballoon1)
        B = 0
        balloons.append(B)


    #Ceates continuously dancing Stitch
    #Also incorporates all animation as it is the fastest moving, continuous object
    for dance in range(0,len(Stitch)*2):

        #Makes Stitch repeat same movement in reverse to show he is turning around
        if dance <9:
            number = dance%len(Stitch)
        else:
            number = len(Stitch)-1-dance%len(Stitch)
        StitchImage = screen.create_image(xStitch, yStitch, image = Stitch[number])


        #Only update Boat location every other frame
        if frames%2 == 0:
            xBoat = xBoat + boatIncrease
        boat = screen.create_image(xBoat,yBoat,image = boatImage) #Not in if statement for pausing effects


        #Only update Banner until the fourth frame
        if frames <4:
            xBanner = xBanner-12
            banner = screen.create_image(xBanner, 100, image = bannerImage)
            doraemon = screen.create_image(xBanner-300, 100, image = doraemonImage1)
        else:
            banner = screen.create_image(xBanner-5, 100, image = bannerImage)
            doraemon = screen.create_image(xBanner-5-300, 100, image = doraemonImage1)

        #Only update Patrick Star during second frame for all 7 images
        if frames == 1 and dance < 7:
            xpatrick = xpatrick-10
            ypatrick = ypatrick-10
            patrickstar1 = screen.create_image(xpatrick, ypatrick, image = patrick[dance])
        elif frames ==1 and dance == 7:   #Keeps last image on screen
            patrickstar2 = screen.create_image(xpatrick, ypatrick, image = patrick[dance])


        #Creates an array of 11 balloons
        for i in range(0, len(balloon)):
            b = i%len(balloon)
            yballoon = yballoon -5

            #Make different balloons float in different directions
            if b < 5:
                xballoon[i] = xballoon[i]+20
            else:
                xballoon[i] = xballoon[i]-20

            balloons[i] = screen.create_image(xballoon[i], yballoon, image = balloon[b])

        
        #Makes Tweety float up and down
        for floating in range(0, tweetyRange):
            if dance%4 == 1:
                ytweety = ytweety+2
            elif dance%4 == 3:
                ytweety = ytweety-2
        tweety = screen.create_image(xtweety, ytweety, image = tweetyImage)


        screen.update()  #Update screen
        sleep(0.05)   
        
        #Deletes objects according to the original formulas
        if frames < 4:
            screen.delete(banner, doraemon)
        
        if frames ==1 and dance < 7:
            screen.delete(patrickstar1)
        
        screen.delete(boat)
        
        for floating in range(0, tweetyRange):
            screen.delete(tweety)
        for i in range(0, len(balloon)):
            screen.delete(balloons[i])
        
        screen.delete(StitchImage)


#Recreate existing images for final stopping scene
        
StitchImage = screen.create_image(xStitch,yStitch,image = Stitch[0])
banner = screen.create_image(xBanner-5, 100, image = bannerImage)
doraemon = screen.create_image(xBanner-5-300, 100, image = doraemonImage1)
tweety = screen.create_image(xtweety,ytweety, image = tweetyImage)
xballoon = [651,227,395,618,480,573,326,397,763,320]
boat = screen.create_image(xBoat,yBoat,image = boatImage)
for i in range(0,len(balloon)):
    a = i%len(balloons)
    yballoon = 200 +i*3
    screen.create_image(xballoon[i], yballoon, image = balloon[a])
