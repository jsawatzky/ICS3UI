#LOADS PYTHON'S GRAPHICS PACKAGE
from tkinter import *
import math
import time
import random

#SETS UP THE DRAWING SCREEN
root = Tk()
screen = Canvas(root, width=800, height=800, background="midnight blue")
screen.pack()

##ANIMATION PARAMETERS!!!!!!!!!!!!!!!!!!!
paraX = 0
paraY = 0

shipmover = 0
drown = 0;
x = 0;

smokecount = 10
smoketrak = 0

xtcount = 0;
EN = 0;
TWOen = 0;
wavescal = 0;

lifemover = 0
wavestrength = 6 #Depicts the Water and Lifeboats bopping

###########################################
print ("Please Note in Current Settings (e.g. The Sleep and the Wave) The Best number to pick is 6 (which causes \n most fluid Motion") 
numboats = 5
if numboats > 9:
    numboats = 9;
    print ("That was invalid - I have Picked 9 by default")
if numboats < 1:
    numboats = 1;
    print ("That was invalid - I have Picked 1 by default")
                
counter = numboats
boatloc = 0;

sinboat = 0;
############################
#For water and Moon
screen.create_oval(50,50,150,150, fill = "pale goldenrod")
screen.create_rectangle(0,600,800,800, fill = "steel blue")


for i in range (0,300):
      
    shipmover = shipmover - 2;
    if shipmover < -150:
        shipmover = -150;
        x = 2
        
    if x != 2:
        #For water and Moon
        screen.create_oval(50,50,150,150, fill = "pale goldenrod")
        screen.create_rectangle(0,600,800,800, fill = "steel blue")
        for watersteaks in range (0,100):
            wX = random.randint (0,800)
            wY = random.randint (600,800)

            wX2 = random.randint (0,800)
            wY2 = random.randint (600,800)
            
            waterstreak = screen.create_line(wX,wY,wX2,wY2,fill = "#56A0D3") 

        #Creating the Iceberg
        iceberg = screen.create_polygon(50, 650, 100, 500, 223,500,300,650, fill = "gray")
            
        ##FOR THE SHIP
        hull = screen.create_polygon(1200 + shipmover,450,300+ shipmover,450, 450+ shipmover, 675,1200+ shipmover,675,fill ="dim gray")

        whiteband = screen.create_polygon(300+ shipmover,450, 315+ shipmover, 475, 1200+ shipmover ,475,1200+ shipmover, 450, fill = "white")
        name = screen.create_text(450+ shipmover, 525, text = "Titanic",font="Tahoma 20")
        whitePART = screen.create_rectangle(675+ shipmover,325,1200+ shipmover,450, fill = "white")
        ##For the Main Deck
        mdeck = screen.create_polygon(300+ shipmover,450,375+ shipmover,425,675+ shipmover,425,675+ shipmover,450, fill = "chocolate4")

        ##For the Top Deck Roof
        tdeck = screen.create_polygon(675+ shipmover,325,750+ shipmover,300,1200+ shipmover,300,1200+ shipmover,325, fill = "chocolate4")
        #Smoke Stack1
        s1 = screen.create_rectangle(750+ shipmover,112,850+ shipmover,175, fill = "black")
        s2 = screen.create_oval(750+ shipmover,100,850+ shipmover,125, fill = "grey") 
        s3 = screen.create_oval(750+ shipmover,287,850+ shipmover,312, fill = "orange")
        s4 = screen.create_oval(750+ shipmover,287,850+ shipmover,312, fill = "orange")
        s5 = screen.create_rectangle(750+ shipmover,150,850+ shipmover,300, fill = "orange") 
        s6 = screen.create_oval(750+ shipmover,137.5,850+ shipmover,162.5,fill = "black")

        #SMOKE EFFECT
        for smoky in range (0,smokecount):
            
            smokex = random.randint (750, 775)
            smokey = random.randint (0 ,100)
            
            smokex2 = random.randint (780, 900)
            smokey2 = random.randint (101 ,135)
            
            smokecloud = screen.create_oval (smokex+ shipmover, smokey,smokex2+ shipmover,smokey2, fill = "grey") 


        ##For the Support Line
        screen.create_line (300 + shipmover,450,550+shipmover,300,750+shipmover,125,smooth = "true")
        
        ###SHIP___END####################################################################################################################
        
        ##For the Lifeboats

        for ty in range (0,counter):
        #if xtcount < counter:
            boatloc = boatloc - 40;
            xtcount = xtcount + 1;
            boat = screen.create_rectangle(685 + boatloc + shipmover, 450, 705 + boatloc + shipmover, 455,  fill = "brown")

        boatloc = 0; #Reseting the Placement Offset

        screen.update()
        time.sleep (0.05)
        screen.delete ("all")
  

    else:
        counter = numboats
        screen.delete ("all")
        
        break 

for iz in range (0,1000):
    ##FOR THE Inertia EFFECT
    EN = EN + 0.5;
    if EN > 12:
        EN = 12;


    #For water and Moon
    screen.create_oval(50,50,150,150, fill = "pale goldenrod")
    screen.create_rectangle(0,600,800,800, fill = "steel blue")
    #Creating The Water that changes in length every frame
    for watersteaks in range (0,100):
            wX = random.randint (0,800)
            wY = random.randint (600,800)

            wX2 = random.randint (0,800)
            wY2 = random.randint (600,800)
            
            waterstreak = screen.create_line(wX,wY,wX2,wY2,fill = "#56A0D3")

    #Creating the Iceberg ANimation with Inertia 

    iceberg = screen.create_polygon(50 - EN , 650, 100- EN, 500, 223- EN,500,300- EN,650, fill = "gray")

    #These are for the smoke lines and smoke stakes to go in a gradually increasing way
    paraX = 0.1 * iz**2;
    paraY = 1* iz**2;
    #to inrease motion of acceleration of the funnel
       
######FOR THE SMOKE TOWER EXPLODING
    s1 = screen.create_rectangle(750+ shipmover + paraX,112 + paraY,850+ shipmover + paraX,175+paraY, fill = "black")
    s2 = screen.create_oval(750+ shipmover+ paraX,100+ paraY,850+ shipmover+ paraX,125+ paraY, fill = "grey") 
    s3 = screen.create_oval(750+ shipmover+ paraX,287+ paraY,850+ shipmover+ paraX,312+ paraY, fill = "orange")
    s4 = screen.create_oval(750+ shipmover+ paraX,287+ paraY,850+ shipmover+ paraX,312+ paraY, fill = "orange")
    s5 = screen.create_rectangle(750+ shipmover+ paraX,150+ paraY,850+ shipmover+ paraX,300+ paraY, fill = "orange") 
    s6 = screen.create_oval(750+ shipmover+ paraX,137.5+ paraY,850+ shipmover+ paraX,162.5+ paraY,fill = "black")

    #For the line falling
    screen.create_line (300 + shipmover ,450 + drown,550+shipmover + paraY,300+paraY)

    ####################
        
    
    drown = drown + 0.25
    #iceberg = screen.create_polygon(50, 650+drown, 100, 500+drown, 223,500+drown,300,650+drown, fill = "gray")
    ##FOR THE SHIP
    hull = screen.create_polygon(1200+ shipmover,450+drown,300+ shipmover,450+drown, 450+ shipmover, 675+drown,1200,675+drown,fill ="dim gray")

    whiteband = screen.create_polygon(300+ shipmover,450+drown, 315+ shipmover, 475+drown, 1200+ shipmover ,475+drown,1200+ shipmover, 450+drown, fill = "white")
    name = screen.create_text(450+ shipmover, 525+drown, text = "Titanic",font="Tahoma 20")
    whitePART = screen.create_rectangle(675+ shipmover,325+drown,1200+ shipmover,450+drown, fill = "white")
    ##For the Main Deck
    mdeck = screen.create_polygon(300+ shipmover,450+drown,375+ shipmover,425+drown,675+ shipmover,425+drown,675+ shipmover,450+drown, fill = "chocolate4")

    ##For the Top Deck Roof
    tdeck = screen.create_polygon(675+ shipmover,325+drown,750+ shipmover,300+drown,1200+ shipmover,300+drown,1200+ shipmover,325+drown, fill = "chocolate4")


    waterover = screen.create_rectangle(0,675,800,800, fill = "steel blue",outline ="steel blue")
    #Creating the WAter Streak Overlay
    for watersteaks2 in range (0,100):
            wX = random.randint (0,800)
            wY = random.randint (675,800)

            wX2 = random.randint (0,800)
            wY2 = random.randint (675,800)
            
            waterstreak = screen.create_line(wX,wY,wX2,wY2,fill = "#56A0D3") 
    
    TWOen = TWOen + 2
    if TWOen > 280:
        TWOen = 280;
        sinboat = 1;


    #SMOKE EFFECT
    
    for smoky in range (0,smokecount):
        
        smokex = random.randint (750, 775)
        smokey = random.randint (0 ,100)
        
        smokex2 = random.randint (780, 900)
        smokey2 = random.randint (101 ,135)

        
        smokecloud = screen.create_oval (smokex+ shipmover, smokey,smokex2+ shipmover,smokey2, fill = "grey")
        #Gradually Decreasing the AMount of Smoke
        if smoketrak == 5:
            smokecount = smokecount - 1
        if smoketrak == 20:
            smokecount = smokecount - 1
        if smoketrak == 50:
            smokecount = smokecount - 1
        if smoketrak == 100:
            smokecount = smokecount - 2
        if smoketrak == 140:
            smokecount = smokecount - 1
        if smoketrak == 180:
            smokecount = smokecount - 2
        if smoketrak == 200:
            smokecount = smokecount - 1
            
    smoketrak = smoketrak + 1    
#Moving The lifeboats away
    for ty in range (0,counter):
        #if xtcount < counter:
            boatloc = boatloc - 40;
            xtcount = xtcount + 1;
            if sinboat != 1:
                #heads = screen.create_oval(689+ boatloc + shipmover + lifemover,450 + TWOen, 687 + boatloc + shipmover, 451+ TWOen, fill = "yellow") 
                boat = screen.create_rectangle(685 + boatloc + shipmover, 450 + TWOen, 705 + boatloc + shipmover, 455+ TWOen,  fill = "brown")
                
            if sinboat == 1:
                lifemover = lifemover - 0.25
                wavescal = wavescal + 1
                waves = math.cos (wavescal) * wavestrength; #Simulating the waves in the water
                boat = screen.create_rectangle(685 + boatloc + shipmover + lifemover, 450 + TWOen + waves, 705 + boatloc + shipmover + lifemover, 455+ TWOen + waves,  fill = "brown")
        
    boatloc = 0; #Reseting the Placement Offset
    
    


        #########
    

    
   
    
    #DRAWS GRID LINES TO HELP YOU PLAN YOUR SCENE
##    spacing = 50
##    for x in range(0, 800, spacing): 
##            screen.create_line(x, 10, x, 800, fill="white")
##            screen.create_text(x, 0, text=str(x), font="Times 8", anchor = N)
##
##    for y in range(0, 800, spacing):
##            screen.create_line(20, y, 800, y, fill="blue")
##            screen.create_text(0, y, text=str(y), font="Times 8", anchor = W)
##
##
  
    
    screen.update()
    time.sleep (0.05)
    screen.delete ("all")

##print ("coming now")
##for failship in range (0,600):
##    screen.create_oval(50,50,150,150, fill = "pale goldenrod")
##    screen.create_rectangle(0,600,800,800, fill = "steel blue")
##    
##    if failship > 40:
##        failship = 40
##    screen.create_rectangle(350-failship*2,680-failship*2,350+failship*2,680+failship*2,fill = "black")
##    
##    iceberg = screen.create_polygon(50 - EN , 650, 100- EN, 500, 223- EN,500,300- EN,650, fill = "gray")
##    
##    screen.update()
##    time.sleep (0.05)
##    screen.delete ("all")


#Closing Remarks and Facts
text1 = screen.create_text (400,400, text = "Titanic - April 15, 1912", font = "Tahoma 18", fill = "white")
screen.update() 
time.sleep(5)
screen.delete(text1)

text2 = screen.create_text (400,400, text = "1517 People Died on that Day   RIP", font = "Tahoma 18", fill = "white")
screen.update() 
time.sleep(5)
screen.delete(text2)

text3= screen.create_text (400,400, text = "Great Lessons were Learned", font = "Tahoma 18", fill = "white")
screen.update() 
time.sleep(3)
screen.delete(text3)

text4 = screen.create_text(400,400,text = "By Toby",font = "Tahoma 12", fill = "white")
time.sleep(12) 


print ("I am Finished")


