#############################################################################
# Title:  Mario Kart Animation
# Programmer:  Saad Haq
# Last modified:  13/04/2014
# Purpose:  This program is an animation of characters from the classic 
#           children's game, Mario Kart. 3 characters have a race and the
#           winner is printed on the screen once all racers have passed
#           the finish line. There are randomized clouds in natural
#           colours to add an asthetic appeal to the program. 
#############################################################################

from tkinter import *
from random import *
from time import *

root = Tk()
screen = Canvas( root, width=1199, height=800, background = "forest green" )
screen.pack()

#RACERS
marioImageFile = PhotoImage( file = "mario.gif" )
toadImageFile = PhotoImage( file = "toad.gif" )
donkeyKongImageFile = PhotoImage( file = "donkeyKong.gif" )


#SKY
sky= screen.create_rectangle( 0,0, 1200,400,  fill= "sky blue" )

#ROAD   
road = screen.create_polygon( 0,600, 50,400, 1400,400, 1400,600, fill="grey", outline= "gold", width= 6 )


#FINISH LINE
flagImageFile = PhotoImage( file = "finishline2.gif" )

finishLine= screen.create_image ( 50,300,  image= flagImageFile )
endLine= screen.create_line (0,600, 50, 400, fill= "black", width= 15)
endLine2= screen.create_line (0,600, 50, 400, fill= "white", width= 5)


#CLOUDS 

numClouds = 400

size = []
x = []
y = []
xSpeed = []
ySpeed = []
cloud = []
colours = ["white" , "white smoke" , "grey"]

#DETERMINING VALUES FOR PREVIOUSLY STATED ARRAYS
for i in range(0,numClouds):
    newSize = randint(50,80) #GENERATING RANDOM INTEGERS FOR CLOUD POSITION
    newX = randint(-1500,1200) 
    newY = randint (-100,100)
    

    size.append( newSize )
    x.append( newX )
    y.append( newY )
    xSpeed.append( 1 )
    ySpeed.append( 0 )  #KEEPS CLOUDS FROM FALLING ONTO GROUND
    cloud.append ( 0 )



#LOOP TO CREATE ANIMATIONS OF CLOUDS AND RACERS
for i in range (0, 340):
    
    carSpeed = 4
    
    #DETERMINES MARIO'S SPEED
    xMario= 1800 - (carSpeed+2.5)*i 
    mario = screen.create_image( xMario, 360, image=marioImageFile )

    #DETERMINES TOAD'S SPEED
    xToad= 1400 - (carSpeed-0.2)*i 
    toad= screen.create_image( xToad, 420, image=toadImageFile )

    #DETERMINES DONKEY KONG'S SPEED
    xDonkeyKong= 1600 - (carSpeed+1)*i
    donkeyKong= screen.create_image( xDonkeyKong, 470, image= donkeyKongImageFile)

    #DETERMINING SPEED 
    for i in range(0,numClouds):
        x[i] = x[i] + xSpeed[i]
        y[i] = y[i] + ySpeed[i]

        #WIDENS CIRCLE INTO A CLOUD-LIKE SHAPE
        cloud[i] = screen.create_oval( x[i], y[i], (x[i] +size[i]) + 50, y[i] +size[i], fill = colours [i%len(colours)], outline = colours [i%len(colours)] ) 

    screen.update()
    sleep(0.01) 
    screen.delete(  toad, donkeyKong, mario) #DELETES PREVIOUS IMAGE OF RACERS TO PRODUCE ANIMATION EFFECT


    #DELETE PREVIOUS CLOUD FOR ANIMATION EFFECT
    for i in range(0,numClouds):
        screen.delete( cloud[i] )



#PRINT WINNER
screen.create_text (400, 270, text= "The WINNER is...", font= "helvetica 40")

winnerTextImageFile= PhotoImage (file = "marioFont.gif")
winnerText= screen.create_image (800, 250, image= winnerTextImageFile)

winnerImageFile = PhotoImage( file = "marioWinner.gif" )
winner= screen.create_image (600, 450, image=winnerImageFile)



#MAINTAINS ANIMATED CLOUDS AFTER RACE IS OVER AND WINNER IS SHOWN
for i in range (0, 1000):
    for i in range(0,numClouds):
        x[i] = x[i] + xSpeed[i]
        y[i] = y[i] + ySpeed[i]
        cloud[i] = screen.create_oval( x[i], y[i], (x[i] +size[i]) + 50, y[i] +size[i], fill = colours [i%len(colours)], outline = colours [i%len(colours)] ) 

    screen.update()
    sleep(0.01) 
    for i in range(0,numClouds):
        screen.delete( cloud[i] )
        
