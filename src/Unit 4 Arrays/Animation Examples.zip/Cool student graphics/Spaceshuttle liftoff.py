###############################################################
#import the Tkinter module, which has functions for making Graphical
#user interfaces
from tkinter import *
from random import*
from time import*
from math import*
myInterface = Tk()
screen = Canvas(myInterface, width=800, height=800, background="light blue")
screen.pack()

#DRAWS A GRID OVERLAY TO HELP YOU PLAN THE SCENE
##spacing = 50
##for x in range(0, 800, spacing): 
##    screen.create_line(x, 10, x, 800, fill="blue")
##    screen.create_text(x, 0, text=str(x), font="Times 8", anchor = N)
##
##for y in range(0, 800, spacing):
##    screen.create_line(20, y, 800, y, fill="blue")
##    screen.create_text(0, y, text=str(y), font="Times 8", anchor = W)


#Launch Platform
screen.create_rectangle(0,700,800,800,fill="black")

#Launch Tower
LaunchTower=screen.create_rectangle(0,100,100,700,fill="dark slate grey")

x1=400
y1=200

MainBooster=screen.create_polygon(x1,y1,x1,y1-0.1,x1+22.5,y1+50,x1+45,y1+100,x1+45,y1+125,
                                  x1+45,y1+349.9,x1+45,y1+350,x1-45,y1+350,x1-45,y1+349.9,
                                  x1-45,y1+125,x1-45,y1+100,x1-22.5,y1+50,x1,y1-0.1,
                                  smooth="true",fill="orange",outline="black")

#Left Booster
Lx1=x1-67.5
Ly1=y1+50
LeftBooster=screen.create_polygon(Lx1,Ly1,Lx1+11.25,Ly1+50,Lx1+22.5,Ly1+100,Lx1+22.5,Ly1+125,
                                  Lx1+22.5,Ly1+349.9,Lx1+22.5,Ly1+350,Lx1-22.5,Ly1+350,Lx1-22.5,
                                  Ly1+349.9,Lx1-22.5,Ly1+125,Lx1-22.5,Ly1+100,Lx1-11.25,Ly1+50,
                                  smooth="true",fill="white",outline="black")

LeftBoosterSkirt=screen.create_polygon(Lx1,Ly1+400,Lx1+22.5,Ly1+400,Lx1+12.25,Ly1+437.5,Lx1-12.25,Ly1+437.5,Lx1-22.5,Ly1+400,
                                       fill="white",outline="black")
    
#Right Booster
Rx1=x1+67.5
Ry1=y1+50
RightBooster=screen.create_polygon(Rx1,Ry1,Rx1+11.25,Ry1+50,Rx1+22.5,Ry1+100,Rx1+22.5,Ry1+125,Rx1+22.5,Ry1+349.9,Rx1+22.5,Ry1+350,Rx1-22.5,Ry1+350,Rx1-22.5,Ry1+349.9,Rx1-22.5,Ry1+125,Rx1-22.5,Ry1+100,Rx1-11.25,Ry1+50,smooth="true",fill="white",outline="black")
RightBoosterSkirt=screen.create_polygon(Rx1,Ry1+400,Rx1+22.5,Ry1+400,Rx1+12.25,Ry1+437.5,Rx1-12.25,Ry1+437.5,Rx1-22.5,Ry1+400,fill="white",outline="black")

#Shuttle
Sx1=x1
Sy1=y1+125

Shuttle=screen.create_polygon(Sx1,Sy1,Sx1+25,Sy1+25,Sx1+45,Sy1+200,Sx1+90,Sy1+235,Sx1+140,Sy1+275,Sx1+140,Sy1+324.9,Sx1+140,Sy1+325,Sx1-140,Sy1+325,Sx1-140,Sy1+324.9,Sx1-140,Sy1+275,Sx1-90,Sy1+235,Sx1-45,Sy1+200,Sx1-25,Sy1+25,smooth="true",fill="white",outline="black")

#Shuttle Decals
#Nose
DECNose=screen.create_polygon(Sx1,Sy1,Sx1+25,Sy1+25,Sx1-25,Sy1+25,smooth="true",fill="black")
#Body
DECBody1=screen.create_line(Sx1+30,Sy1+75,Sx1+30,Sy1+300,fill="black")
DECBody2=screen.create_line(Sx1-30,Sy1+75,Sx1-30,Sy1+300,fill="black")
DECBodyR1=screen.create_line(Sx1+30,Sy1+131.25,Sx1,Sy1+133.75,Sx1-30,Sy1+131.25,smooth="true",fill="black")
DECBodyR2=screen.create_line(Sx1+30,Sy1+187.5,Sx1-30,Sy1+187.5,smooth="true",fill="black")
DECBodyR3=screen.create_line(Sx1+30,Sy1+243.75,Sx1,Sy1+241.25,Sx1-30,Sy1+243.75,smooth="true",fill="black")
DECBodyR4=screen.create_line(Sx1+30,Sy1+75,Sx1,Sy1+80,Sx1-30,Sy1+75,smooth="true",fill="black")
DECBodyText1=screen.create_text(x1+85,y1+425,text="Discovery",font="Arial 10")
DECBodyText2=screen.create_text(x1-85,y1+425,text="NASA",font="Arial 10")





#Shuttle Engine

Ex1=x1
Ey1=y1+410

ShuttleEngine=screen.create_polygon(Ex1,Ey1,Ex1+30,Ey1,Ex1+45,Ey1+10,Ex1+45,Ey1+60,Ex1-45,Ey1+60,Ex1-45,Ey1+10,Ex1-30,Ey1,fill="white",outline="black")

#Shuttle Engine Left
LEx1=x1-20
LEy1=y1+470

ShuttleEngineLeft=screen.create_polygon(LEx1,LEy1,LEx1+20,LEy1,LEx1+15,LEy1+20,LEx1-15,LEy1+20,LEx1-20,LEy1,fill="black")

#Shuttle Engine Right
REx1=x1+20
REy1=y1+470

ShuttleEngineRight=screen.create_polygon(REx1,REy1,REx1+20,REy1,REx1+15,REy1+20,REx1-15,REy1+20,REx1-20,REy1,fill="black")

#Left Wing Clip
LCx1=400-75
LCy1=200+425

LeftWingClip=screen.create_polygon(LCx1,LCy1,LCx1+12.5,LCy1,LCx1+25,LCy1+25,LCx1+25,LCy1+74.9,LCx1+25,LCy1+75,LCx1-25,LCy1+74.9,LCx1-25,LCy1+75,LCx1-25,LCy1+25,LCx1-12.5,LCy1,smooth="true",fill="dark slate grey")

#Right Wing Clip
RCx1=400+75
RCy1=200+425

RightWingClip=screen.create_polygon(RCx1,RCy1,RCx1+12.5,RCy1,RCx1+25,RCy1+25,RCx1+25,RCy1+74.9,RCx1+25,RCy1+75,RCx1-25,RCy1+74.9,RCx1-25,RCy1+75,RCx1-25,RCy1+25,RCx1-12.5,RCy1,smooth="true",fill="dark slate grey")

#Left Spark Nozzle
screen.create_rectangle(350,692.5,362.5,697.5,fill="black")

#Right Spark Nozzle
screen.create_rectangle(450,692.5,437.5,697.5,fill="black")

NAx1=100
NAy1=187.5
NAx2=NAx1+275
NAy2=NAy1+25
Arm=screen.create_polygon(NAx1,NAy1,NAx2,NAy1,NAx2,NAy2,NAx1,NAy2,fill="dark slate grey")
Cup=screen.create_polygon(NAx2,NAy2-12.5,NAx2,NAy2-0.1,NAx2,NAy2,NAx2+25,NAy2,NAx2+50,NAy2-12.5,NAx2+25,NAy2-25,NAx2,NAy2-25,NAx2,NAy2-24.9,smooth="true",fill="dark slate grey")

screen.update()
for sun in range(-150,150):
    Mx1=400+sun*5
    My1=0.01*(sun**2)+25
    sun=screen.create_oval(Mx1,My1,Mx1+50,My1+50,fill="yellow")
    LaunchTower=screen.create_rectangle(0,100,100,700,fill="dark slate grey")


    screen.update()
    sleep(0.05)
    screen.delete(sun)

screen.delete(Arm,Cup)

for x in range(0,170):
    #Nose Arm
    NAx1=100-x
    NAy1=187.5
    NAx2=NAx1+275
    NAy2=NAy1+25
    ##NCx1=NAx2
    ##NCy1=NAy2-25
    ##NCx2=NCx1+50
    ##NCy2=NCy1+25

    Arm=screen.create_polygon(NAx1,NAy1,NAx2,NAy1,NAx2,NAy2,NAx1,NAy2,fill="dark slate grey")
    Cup=screen.create_polygon(NAx2,NAy2-12.5,NAx2,NAy2-0.1,NAx2,NAy2,NAx2+25,NAy2,NAx2+50,NAy2-12.5,NAx2+25,NAy2-25,NAx2,NAy2-25,NAx2,NAy2-24.9,smooth="true",fill="dark slate grey")
    ##screen.create_oval(NCx1,NCy1,NCx2,NCy2,fill="red")
    screen.update()
    sleep(0.05)
    if x<169:
        screen.delete(Arm,Cup)
    else:
        ()

SEA1=0

#Ignition
for ig in range(0,100):
    for FiveSparks in range(0,1):
        x=randint(364,438)
        y=randint(690,720)
        xs1=randint(364,438)
        ys1=randint(690,720)
        xs2=randint(364,438)
        ys2=randint(690,720)
        xs3=randint(364,438)
        ys3=randint(690,720)
        xs4=randint(364,438)
        ys4=randint(690,720)
        Length=5
        Spark=screen.create_line(x,y,x+Length,y+Length,fill="yellow")
        Spark1=screen.create_line(xs1,ys1,xs1+Length,ys1+Length,fill="yellow")
        Spark2=screen.create_line(xs2,ys2,xs2+Length,ys2+Length,fill="yellow")
        Spark3=screen.create_line(xs3,ys3,xs3+Length,ys3+Length,fill="yellow")
        Spark4=screen.create_line(xs4,ys4,xs4+Length,ys4+Length,fill="yellow")

        SEA1x1=x1-20
        SEA1y1=y1+490
        SEA2x1=x1+20
        SEA2y1=y1+490
        
        if ig>=25 and ig<56:
            SEA1=SEA1+1
            #Shuttle Engine Left And Right Afterburners
            AfterBurner1=screen.create_polygon(SEA1x1,SEA1y1,SEA1x1+15,SEA1y1,SEA1x1,SEA1y1+SEA1,SEA1x1-15,SEA1y1,smooth="true",fill="orange")
            AfterBurner2=screen.create_polygon(SEA2x1,SEA2y1,SEA2x1+15,SEA2y1,SEA2x1,SEA2y1+SEA1,SEA2x1-15,SEA2y1,smooth="true",fill="orange")  

            screen.update()
            sleep(0.05)
            if ig<55:
                screen.delete(Spark,Spark1,Spark2,Spark3,Spark4,AfterBurner1,AfterBurner2)

            else:
                screen.delete(Spark,Spark1,Spark2,Spark3,Spark4)

            

        else:
            screen.update()
            sleep(0.05)
            screen.delete(Spark,Spark1,Spark2,Spark3,Spark4)
    
    
    





        
screen.delete(MainBooster,LeftBooster,RightBooster,Shuttle,ShuttleEngine,ShuttleEngineLeft,ShuttleEngineRight,LeftWingClip,RightWingClip,LeftBoosterSkirt,RightBoosterSkirt,AfterBurner1,AfterBurner2,DECNose,DECBody1,DECBody2,DECBodyR1,DECBodyR2,DECBodyR3,DECBodyR4,DECBodyText1,DECBodyText2)


for NumFrames in range(0,200):
    
    #Main Booster
    x1=400
    y1=200-(0.05*(NumFrames**2))

    MainBooster=screen.create_polygon(x1,y1,x1,y1-0.1,x1+22.5,y1+50,x1+45,y1+100,x1+45,y1+125,x1+45,y1+349.9,x1+45,y1+350,x1-45,y1+350,x1-45,y1+349.9,x1-45,y1+125,x1-45,y1+100,x1-22.5,y1+50,x1,y1-0.1,smooth="true",fill="orange",outline="black")

    #Left Booster
    Lx1=x1-67.5
    Ly1=y1+50
    LeftBooster=screen.create_polygon(Lx1,Ly1,Lx1+11.25,Ly1+50,Lx1+22.5,Ly1+100,Lx1+22.5,Ly1+125,Lx1+22.5,Ly1+349.9,Lx1+22.5,Ly1+350,Lx1-22.5,Ly1+350,Lx1-22.5,Ly1+349.9,Lx1-22.5,Ly1+125,Lx1-22.5,Ly1+100,Lx1-11.25,Ly1+50,smooth="true",fill="white",outline="black")
    LeftBoosterSkirt=screen.create_polygon(Lx1,Ly1+400,Lx1+22.5,Ly1+400,Lx1+12.25,Ly1+437.5,Lx1-12.25,Ly1+437.5,Lx1-22.5,Ly1+400,fill="white",outline="black")

    LBAx1=x1-67.5
    LBAy1=y1+490
    LBAColour=choice(["orange","dark orange","orange red",])
    LeftBoosterAfterburner=screen.create_polygon(LBAx1,LBAy1,LBAx1+12.25,LBAy1,LBAx1+20,LBAy1+400,LBAx1-20,LBAy1+400,LBAx1-12.25,LBAy1,fill=LBAColour)

    #Booster Smoke Clouds
##    LBAx1=LBAx1+(25*(sin(0.5*NumFrames)))
    speed=0.5
    multiplier=0.01*NumFrames
    pwidth=5
    nwidth=-5
    CloudLeft=screen.create_polygon(LBAx1,LBAy1+400,(LBAx1+45+pwidth)+(10*(sin(speed*NumFrames))),LBAy1+400,(LBAx1+70+2*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+430,(LBAx1+46+3*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+460,(LBAx1+71+4*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+490,
                                    (LBAx1+47+5*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+520,(LBAx1+72+6*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+550,(LBAx1+48+7*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+580,(LBAx1+74+8*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+610,
                                    (LBAx1+49+9*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+640,(LBAx1+74+10*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+670,(LBAx1+50+11*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+700,(LBAx1+75+12*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+730,
                                    (LBAx1+51+13*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+760,(LBAx1-51-13*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+760,(LBAx1-75-12*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+730,(LBAx1-50-11*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+700,(LBAx1-74-10*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+670,(LBAx1-49-9*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+640,(LBAx1-73-8*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+610,(LBAx1-48-7*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+580,(LBAx1-72-6*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+550,(LBAx1-47-5*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+520,(LBAx1-71-4*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+490,(LBAx1-46-3*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    LBAy1+460,(LBAx1-70-2*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),LBAy1+430,(LBAx1-45-multiplier*pwidth)-(10*(sin(speed*NumFrames))),
                                    LBAy1+400,smooth="true",fill="white",outline="black")
    
    #Right Booster
    Rx1=x1+67.5
    Ry1=y1+50
    RightBooster=screen.create_polygon(Rx1,Ry1,Rx1+11.25,Ry1+50,Rx1+22.5,Ry1+100,Rx1+22.5,Ry1+125,Rx1+22.5,Ry1+349.9,Rx1+22.5,Ry1+350,Rx1-22.5,Ry1+350,Rx1-22.5,Ry1+349.9,Rx1-22.5,Ry1+125,Rx1-22.5,Ry1+100,Rx1-11.25,Ry1+50,smooth="true",fill="white",outline="black")
    RightBoosterSkirt=screen.create_polygon(Rx1,Ry1+400,Rx1+22.5,Ry1+400,Rx1+12.25,Ry1+437.5,Rx1-12.25,Ry1+437.5,Rx1-22.5,Ry1+400,fill="white",outline="black")

    RBAx1=x1+67.5
    RBAy1=y1+490
    RBAColour=choice(["orange","dark orange","orange red",])
    RightBoosterAfterburner=screen.create_polygon(RBAx1,RBAy1,RBAx1+12.25,RBAy1,RBAx1+20,RBAy1+400,RBAx1-20,RBAy1+400,RBAx1-12.25,RBAy1,fill=LBAColour)

    #Booster Smoke Clouds
##    CloudRight=screen.create_polygon(RBAx1,RBAy1+400,RBAx1+45,RBAy1+400,RBAx1+70,RBAy1+430,RBAx1+46,RBAy1+460,RBAx1+71,RBAy1+490,RBAx1+47,RBAy1+520,RBAx1+72,RBAy1+550,RBAx1+48,RBAy1+580,RBAx1+74,RBAy1+610,RBAx1+49,RBAy1+640,RBAx1+74,RBAy1+670,RBAx1+50,RBAy1+700,RBAx1+75,RBAy1+730,RBAx1+51,RBAy1+760,RBAx1-51,RBAy1+760,RBAx1-75,RBAy1+730,RBAx1-50,RBAy1+700,RBAx1-74,RBAy1+670,RBAx1-49,RBAy1+640,RBAx1-73,RBAy1+610,RBAx1-48,RBAy1+580,RBAx1-72,RBAy1+550,RBAx1-47,RBAy1+520,RBAx1-71,RBAy1+490,RBAx1-46,RBAy1+460,RBAx1-70,RBAy1+430,RBAx1-45,RBAy1+400,smooth="true",fill="white")
##    CloudRight=screen.create_polygon(RBAx1,RBAy1+400,(RBAx1+45)+(10*(sin(0.25*NumFrames))),RBAy1+400,(RBAx1+70)-(10*(sin(0.25*NumFrames))),RBAy1+430,(RBAx1+46)+(10*(sin(0.25*NumFrames))),RBAy1+460,(RBAx1+71)-(10*(sin(0.25*NumFrames))),RBAy1+490,(RBAx1+47)+(10*(sin(0.25*NumFrames))),RBAy1+520,(RBAx1+72)-(10*(sin(0.25*NumFrames))),RBAy1+550,(RBAx1+48)+(10*(sin(0.25*NumFrames))),RBAy1+580,(RBAx1+74)-(10*(sin(0.25*NumFrames))),RBAy1+610,(RBAx1+49)+(10*(sin(0.25*NumFrames))),RBAy1+640,(RBAx1+74)-(10*(sin(0.25*NumFrames))),RBAy1+670,(RBAx1+50)+(10*(sin(0.25*NumFrames))),RBAy1+700,(RBAx1+75)-(10*(sin(0.25*NumFrames))),RBAy1+730,(RBAx1+51)+(10*(sin(0.25*NumFrames))),RBAy1+760,(RBAx1-51)-(10*(sin(0.25*NumFrames))),RBAy1+760,(RBAx1-75)+(10*(sin(0.25*NumFrames))),RBAy1+730,(RBAx1-50)-(10*(sin(0.25*NumFrames))),RBAy1+700,(RBAx1-74)+(10*(sin(0.25*NumFrames))),RBAy1+670,(RBAx1-49)-(10*(sin(0.25*NumFrames))),RBAy1+640,(RBAx1-73)+(10*(sin(0.25*NumFrames))),RBAy1+610,(RBAx1-48)-(10*(sin(0.25*NumFrames))),RBAy1+580,(RBAx1-72)+(10*(sin(0.25*NumFrames))),RBAy1+550,(RBAx1-47)-(10*(sin(0.25*NumFrames))),RBAy1+520,(RBAx1-71)+(10*(sin(0.25*NumFrames))),RBAy1+490,(RBAx1-46)-(10*(sin(0.25*NumFrames))),RBAy1+460,(RBAx1-70)+(10*(sin(0.25*NumFrames))),RBAy1+430,(RBAx1-45)-(10*(sin(0.25*NumFrames))),RBAy1+400,smooth="true",fill="white")

    CloudRight=screen.create_polygon(RBAx1,RBAy1+400,(RBAx1+45+pwidth)+(10*(sin(speed*NumFrames))),RBAy1+400,(RBAx1+70+2*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+430,(RBAx1+46+3*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+460,(RBAx1+71+4*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+490,
                                    (RBAx1+47+5*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+520,(RBAx1+72+6*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+550,(RBAx1+48+7*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+580,(RBAx1+74+8*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+610,
                                    (RBAx1+49+9*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+640,(RBAx1+74+10*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+670,(RBAx1+50+11*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+700,(RBAx1+75+12*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),LBAy1+730,
                                    (RBAx1+51+13*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+760,(RBAx1-51-13*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+760,(RBAx1-75-12*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+730,(RBAx1-50-11*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+700,(RBAx1-74-10*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+670,(RBAx1-49-9*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+640,(RBAx1-73-8*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+610,(RBAx1-48-7*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+580,(RBAx1-72-6*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+550,(RBAx1-47-5*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+520,(RBAx1-71-4*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+490,(RBAx1-46-3*(multiplier*pwidth))-(10*(sin(speed*NumFrames))),
                                    RBAy1+460,(RBAx1-70-2*(multiplier*pwidth))+(10*(sin(speed*NumFrames))),RBAy1+430,(RBAx1-45-multiplier*pwidth)-(10*(sin(speed*NumFrames))),
                                    RBAy1+400,smooth="true",fill="white",outline="black")

    #Shuttle
    Sx1=x1
    Sy1=y1+125

    Shuttle=screen.create_polygon(Sx1,Sy1,Sx1+25,Sy1+25,Sx1+45,Sy1+200,Sx1+90,Sy1+235,Sx1+140,Sy1+275,Sx1+140,Sy1+324.9,Sx1+140,Sy1+325,Sx1-140,Sy1+325,Sx1-140,Sy1+324.9,Sx1-140,Sy1+275,Sx1-90,Sy1+235,Sx1-45,Sy1+200,Sx1-25,Sy1+25,smooth="true",fill="white",outline="black")

    #Shuttle Decals
    #Nose
    DECNose=screen.create_polygon(Sx1,Sy1,Sx1+25,Sy1+25,Sx1-25,Sy1+25,smooth="true",fill="black")
    #Body
    DECBody1=screen.create_line(Sx1+30,Sy1+75,Sx1+30,Sy1+300,fill="black")
    DECBody2=screen.create_line(Sx1-30,Sy1+75,Sx1-30,Sy1+300,fill="black")
    DECBodyR1=screen.create_line(Sx1+30,Sy1+131.25,Sx1,Sy1+133.75,Sx1-30,Sy1+131.25,smooth="true",fill="black")
    DECBodyR2=screen.create_line(Sx1+30,Sy1+187.5,Sx1-30,Sy1+187.5,smooth="true",fill="black")
    DECBodyR3=screen.create_line(Sx1+30,Sy1+243.75,Sx1,Sy1+241.25,Sx1-30,Sy1+243.75,smooth="true",fill="black")
    DECBodyR4=screen.create_line(Sx1+30,Sy1+75,Sx1,Sy1+80,Sx1-30,Sy1+75,smooth="true",fill="black")
    DECBodyText1=screen.create_text(x1+85,y1+425,text="Discovery",font="Arial 10")
    DECBodyText2=screen.create_text(x1-85,y1+425,text="NASA",font="Arial 10")




    #Shuttle Engine

    Ex1=x1
    Ey1=y1+410

    ShuttleEngine=screen.create_polygon(Ex1,Ey1,Ex1+30,Ey1,Ex1+45,Ey1+10,Ex1+45,Ey1+60,Ex1-45,Ey1+60,Ex1-45,Ey1+10,Ex1-30,Ey1,fill="white",outline="black")

    #Shuttle Engine Left
    LEx1=x1-20
    LEy1=y1+470

    ShuttleEngineLeft=screen.create_polygon(LEx1,LEy1,LEx1+20,LEy1,LEx1+15,LEy1+20,LEx1-15,LEy1+20,LEx1-20,LEy1,fill="black")
    
    #Shuttle Engine Right
    REx1=x1+20
    REy1=y1+470

    ShuttleEngineRight=screen.create_polygon(REx1,REy1,REx1+20,REy1,REx1+15,REy1+20,REx1-15,REy1+20,REx1-20,REy1,fill="black")

    #Left Wing Clip
    LCx1=400-75
    LCy1=200+425

    LeftWingClip=screen.create_polygon(LCx1,LCy1,LCx1+12.5,LCy1,LCx1+25,LCy1+25,LCx1+25,LCy1+74.9,LCx1+25,LCy1+75,LCx1-25,LCy1+74.9,LCx1-25,LCy1+75,LCx1-25,LCy1+25,LCx1-12.5,LCy1,smooth="true",fill="dark slate grey")

    #Right Wing Clip
    RCx1=400+75
    RCy1=200+425

    RightWingClip=screen.create_polygon(RCx1,RCy1,RCx1+12.5,RCy1,RCx1+25,RCy1+25,RCx1+25,RCy1+74.9,RCx1+25,RCy1+75,RCx1-25,RCy1+74.9,RCx1-25,RCy1+75,RCx1-25,RCy1+25,RCx1-12.5,RCy1,smooth="true",fill="dark slate grey")

    #Launch Platform
    screen.create_rectangle(0,700,800,800,fill="black")

    #Shuttle Engine Left And Right Afterburners
    SEA1x1=x1-20
    SEA1y1=y1+490
    SEA2x1=x1+20
    SEA2y1=y1+490
    
    AfterBurner1=screen.create_polygon(SEA1x1,SEA1y1,SEA1x1+15,SEA1y1,SEA1x1,SEA1y1+SEA1,SEA1x1-15,SEA1y1,smooth="true",fill="orange")
    AfterBurner2=screen.create_polygon(SEA2x1,SEA2y1,SEA2x1+15,SEA2y1,SEA2x1,SEA2y1+SEA1,SEA2x1-15,SEA2y1,smooth="true",fill="orange")

    #Giant Smoke Cloud
    GSCx1=400
    GSCy1=1000-(NumFrames*2.5)
    
    GiantSmokeCloud=screen.create_polygon(GSCx1,GSCy1-60,GSCx1+68,GSCy1-87,GSCx1+124,GSCy1-48,GSCx1+200,GSCy1-103,GSCx1+278,GSCy1-134,GSCx1+366,GSCy1-44,GSCx1+444,GSCy1-123,GSCx1+444,GSCy1+400,GSCx1-444,GSCy1+400,GSCx1-444,GSCy1-138,GSCx1-366,GSCy1-55,GSCx1-270,GSCy1-201,GSCx1-200,GSCy1-130,GSCx1-124,GSCy1-80,GSCx1-75,GSCy1-117,smooth="true",fill="white")
    
    screen.update()
    sleep(0.05)
    screen.delete(MainBooster,LeftBooster,RightBooster,Shuttle,ShuttleEngine,ShuttleEngineLeft,ShuttleEngineRight,LeftBoosterSkirt,RightBoosterSkirt,AfterBurner1,AfterBurner2,LeftBoosterAfterburner,RightBoosterAfterburner,CloudLeft,CloudRight,GiantSmokeCloud,DECNose,DECBody1,DECBody2,DECBodyR1,DECBodyR2,DECBodyR3,DECBodyR4,DECBodyText1,DECBodyText2)
    
    





#DRAWS A GRID OVERLAY TO HELP YOU PLAN THE SCENE
spacing = 50
for x in range(0, 800, spacing): 
    screen.create_line(x, 10, x, 800, fill="blue")
    screen.create_text(x, 0, text=str(x), font="Times 8", anchor = N)

for y in range(0, 800, spacing):
    screen.create_line(20, y, 800, y, fill="blue")
    screen.create_text(0, y, text=str(y), font="Times 8", anchor = W)





screen.update()
