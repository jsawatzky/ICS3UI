from tkinter import *
import math
from time import *
from random import*


#SET UP THE DRAWING CANVAS
screenHeight = 700
screenWidth = 1000
root = Tk()
screen = Canvas( root, width=screenWidth, height=screenHeight, background = "blue" )
screen.pack()


for numclouds in range(0,11):  #CREATING RANDOMIZED CLOUDS
    x=randint(0,1000)
    y=randint(0,350)
    screen.create_oval(x,y,x+randint(40,90),y+50,fill="white",outline="white")
    screen.create_oval(x+20,y,x+randint(50,100),y+50,fill="white",outline="white")
    screen.create_oval(x+40,y,x+randint(60,110),y+50,fill="white",outline="white")
    



screen.create_rectangle( 0,screenHeight/1.5, screenWidth,screenHeight, fill = "light grey")

stripeX = 0                                                                                          #BACKGROUND 
for roadStripes in range(0,5):
    
    stripeY = screenHeight*3/4
    screen.create_rectangle(stripeX +50,stripeY,stripeX +250,stripeY + 10, fill = "yellow", outline = "yellow")
    stripeX = stripeX + 300


car1 = [0,0,0,0]   #CARS PARAMETERS AND CALCULATED VALUES
car2 = [0,0,0,0]
carX = 0
carY = 2/3*screenHeight
carWidth = 60
carLength = 250
carSpace = screenWidth
wheelSize = carLength/5
speed = 1


carX2 = carX + carLength
carY2 = carY + carWidth

car2X = carX + carSpace

car2Y = carY
car2X2 = car2X - carLength
car2Y2 = car2Y + carWidth

framecount = 1
while carX2 < car2X2-50:               #ANIMATING CARS
    for delete in range(0,len(car1)):
        screen.delete(car1[delete], car2[delete])

    framecount = framecount*speed
    speed = speed + 0.009
    carX = carX + framecount
    carX2 = carX2 + framecount
    car2X = car2X - framecount
    car2X2 = car2X2 - framecount

    #CREATING AND UPDATING CARS
    car1[0] = screen.create_rectangle(carX,carY,carX2,carY2, fill = "blue",outline = "red")
    car1[1] = screen.create_polygon((carX+carLength/6,carY),  (carX + carLength/3,carY-carWidth/2),(carX+carLength*2/3),(carY-carWidth/2),   (carX2-carLength/6),(carY), fill = "red")
    car1[2] = screen.create_oval((carX2 - carLength/6),(carY2 - carWidth/2),(carX2 - carLength/6 - wheelSize),(carY2 - carWidth/2+wheelSize),fill = "black")
    car1[3] = screen.create_oval((carX + carLength/6),(carY2 - carWidth/2),(carX + carLength/6 + wheelSize),(carY2 - carWidth/2+wheelSize),fill = "black")

    car2[0]= screen.create_rectangle(car2X,car2Y,car2X2,car2Y2, fill = "green",outline = "green")
    car2[1] = screen.create_polygon((car2X - carLength/6),(car2Y),(car2X - carLength/3),(car2Y - carWidth/2),(car2X-carLength*2/3),(car2Y-carWidth/2),(car2X2+carLength/6),(car2Y), fill = "green")
    car2[2] = screen.create_oval((car2X - carLength/6),(car2Y2 - carWidth/2),(car2X - carLength/6 - wheelSize),(car2Y2 - carWidth/2 + wheelSize),fill = "black")
    car2[3] = screen.create_oval((car2X2 + carLength/6),(car2Y2 - carWidth/2),(car2X2 + carLength/6 + wheelSize),(car2Y2 - carWidth/2 + wheelSize),fill = "black")

    screen.update()
    sleep(0.05)

#CREATING THE SCREEN WHEN THE CARS CRASH
for pauseScreen in range(0,40):
    
    colour = ["red","black","white","gray","cyan"]
    pause = screen.create_rectangle(0,0,1000,1000,fill = colour[pauseScreen%len(colour)])
 #   pauseText = screen.create_image(500,350, image = KaboomImageFile)
    screen.update()
        
    sleep(0.05)
    screen.delete(pause)

#SETTING UP ARRAYS FOR THE FIRE
fireNum = 25            
fireWidthx = []
fireWidthy = []
fireX = []
fireY = []
Fire = []
for i in range(0,fireNum):
    Fire.append(0)
   
fireColour = ["red","yellow","orange","dark red", "gold", "orange red"]

#FILLING IN THE ARRAYS
for fireSetup in range(0,fireNum):
    newfireWidthx = randint(25,75)
    newfireWidthy = randint(100,150)

    newfireX = randint(375,600)
    newfireY = randint(475,500)

    fireWidthx.append(newfireWidthx)
    fireWidthy.append(newfireWidthy)

    fireX.append(newfireX)
    fireY.append(newfireY)

#ANIMATING THE FIRE
while True:

    for fire in range (0, fireNum):
        movement = randint(20,100)
        fireY2 = fireY[fire] - fireWidthy[fire] + fire*math.sin(movement*framecount)
        fireX2 = fireX[fire] + fireWidthx[fire]  
        Fire[fire] = screen.create_oval(fireX[fire],fireY[fire],fireX2,fireY2, fill = fireColour[fire%len(fireColour)],outline = fireColour[fire%len(fireColour)] )
    
    screen.update()
    sleep(0.05)
    for delete in range(0,fireNum):
            screen.delete(Fire[delete])

    
          

    


    




